STM8S Std. Peripheral Library for SDCC.
