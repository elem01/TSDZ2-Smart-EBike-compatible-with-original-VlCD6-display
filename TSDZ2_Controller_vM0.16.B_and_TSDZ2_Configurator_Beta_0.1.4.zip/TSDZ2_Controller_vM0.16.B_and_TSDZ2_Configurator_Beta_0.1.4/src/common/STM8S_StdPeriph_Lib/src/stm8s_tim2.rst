                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 3.8.0 #10562 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module stm8s_tim2
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _TIM2_DeInit
                                     12 	.globl _TIM2_TimeBaseInit
                                     13 	.globl _TIM2_OC1Init
                                     14 	.globl _TIM2_OC2Init
                                     15 	.globl _TIM2_OC3Init
                                     16 	.globl _TIM2_ICInit
                                     17 	.globl _TIM2_PWMIConfig
                                     18 	.globl _TIM2_Cmd
                                     19 	.globl _TIM2_ITConfig
                                     20 	.globl _TIM2_UpdateDisableConfig
                                     21 	.globl _TIM2_UpdateRequestConfig
                                     22 	.globl _TIM2_SelectOnePulseMode
                                     23 	.globl _TIM2_PrescalerConfig
                                     24 	.globl _TIM2_ForcedOC1Config
                                     25 	.globl _TIM2_ForcedOC2Config
                                     26 	.globl _TIM2_ForcedOC3Config
                                     27 	.globl _TIM2_ARRPreloadConfig
                                     28 	.globl _TIM2_OC1PreloadConfig
                                     29 	.globl _TIM2_OC2PreloadConfig
                                     30 	.globl _TIM2_OC3PreloadConfig
                                     31 	.globl _TIM2_GenerateEvent
                                     32 	.globl _TIM2_OC1PolarityConfig
                                     33 	.globl _TIM2_OC2PolarityConfig
                                     34 	.globl _TIM2_OC3PolarityConfig
                                     35 	.globl _TIM2_CCxCmd
                                     36 	.globl _TIM2_SelectOCxM
                                     37 	.globl _TIM2_SetCounter
                                     38 	.globl _TIM2_SetAutoreload
                                     39 	.globl _TIM2_SetCompare1
                                     40 	.globl _TIM2_SetCompare2
                                     41 	.globl _TIM2_SetCompare3
                                     42 	.globl _TIM2_SetIC1Prescaler
                                     43 	.globl _TIM2_SetIC2Prescaler
                                     44 	.globl _TIM2_SetIC3Prescaler
                                     45 	.globl _TIM2_GetCapture1
                                     46 	.globl _TIM2_GetCapture2
                                     47 	.globl _TIM2_GetCapture3
                                     48 	.globl _TIM2_GetCounter
                                     49 	.globl _TIM2_GetPrescaler
                                     50 	.globl _TIM2_GetFlagStatus
                                     51 	.globl _TIM2_ClearFlag
                                     52 	.globl _TIM2_GetITStatus
                                     53 	.globl _TIM2_ClearITPendingBit
                                     54 ;--------------------------------------------------------
                                     55 ; ram data
                                     56 ;--------------------------------------------------------
                                     57 	.area DATA
                                     58 ;--------------------------------------------------------
                                     59 ; ram data
                                     60 ;--------------------------------------------------------
                                     61 	.area INITIALIZED
                                     62 ;--------------------------------------------------------
                                     63 ; absolute external ram data
                                     64 ;--------------------------------------------------------
                                     65 	.area DABS (ABS)
                                     66 
                                     67 ; default segment ordering for linker
                                     68 	.area HOME
                                     69 	.area GSINIT
                                     70 	.area GSFINAL
                                     71 	.area CONST
                                     72 	.area INITIALIZER
                                     73 	.area CODE
                                     74 
                                     75 ;--------------------------------------------------------
                                     76 ; global & static initialisations
                                     77 ;--------------------------------------------------------
                                     78 	.area HOME
                                     79 	.area GSINIT
                                     80 	.area GSFINAL
                                     81 	.area GSINIT
                                     82 ;--------------------------------------------------------
                                     83 ; Home
                                     84 ;--------------------------------------------------------
                                     85 	.area HOME
                                     86 	.area HOME
                                     87 ;--------------------------------------------------------
                                     88 ; code
                                     89 ;--------------------------------------------------------
                                     90 	.area CODE
                           000000    91 	G$TIM2_DeInit$0$0 ==.
                           000000    92 	C$stm8s_tim2.c$52$0_0$349 ==.
                                     93 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 52: void TIM2_DeInit(void)
                                     94 ;	-----------------------------------------
                                     95 ;	 function TIM2_DeInit
                                     96 ;	-----------------------------------------
      00965E                         97 _TIM2_DeInit:
                           000000    98 	C$stm8s_tim2.c$54$1_0$349 ==.
                                     99 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 54: TIM2->CR1 = (uint8_t)TIM2_CR1_RESET_VALUE;
      00965E 35 00 53 00      [ 1]  100 	mov	0x5300+0, #0x00
                           000004   101 	C$stm8s_tim2.c$55$1_0$349 ==.
                                    102 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 55: TIM2->IER = (uint8_t)TIM2_IER_RESET_VALUE;
      009662 35 00 53 01      [ 1]  103 	mov	0x5301+0, #0x00
                           000008   104 	C$stm8s_tim2.c$56$1_0$349 ==.
                                    105 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 56: TIM2->SR2 = (uint8_t)TIM2_SR2_RESET_VALUE;
      009666 35 00 53 03      [ 1]  106 	mov	0x5303+0, #0x00
                           00000C   107 	C$stm8s_tim2.c$59$1_0$349 ==.
                                    108 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 59: TIM2->CCER1 = (uint8_t)TIM2_CCER1_RESET_VALUE;
      00966A 35 00 53 08      [ 1]  109 	mov	0x5308+0, #0x00
                           000010   110 	C$stm8s_tim2.c$60$1_0$349 ==.
                                    111 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 60: TIM2->CCER2 = (uint8_t)TIM2_CCER2_RESET_VALUE;
      00966E 35 00 53 09      [ 1]  112 	mov	0x5309+0, #0x00
                           000014   113 	C$stm8s_tim2.c$64$1_0$349 ==.
                                    114 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 64: TIM2->CCER1 = (uint8_t)TIM2_CCER1_RESET_VALUE;
      009672 35 00 53 08      [ 1]  115 	mov	0x5308+0, #0x00
                           000018   116 	C$stm8s_tim2.c$65$1_0$349 ==.
                                    117 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 65: TIM2->CCER2 = (uint8_t)TIM2_CCER2_RESET_VALUE;
      009676 35 00 53 09      [ 1]  118 	mov	0x5309+0, #0x00
                           00001C   119 	C$stm8s_tim2.c$66$1_0$349 ==.
                                    120 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 66: TIM2->CCMR1 = (uint8_t)TIM2_CCMR1_RESET_VALUE;
      00967A 35 00 53 05      [ 1]  121 	mov	0x5305+0, #0x00
                           000020   122 	C$stm8s_tim2.c$67$1_0$349 ==.
                                    123 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 67: TIM2->CCMR2 = (uint8_t)TIM2_CCMR2_RESET_VALUE;
      00967E 35 00 53 06      [ 1]  124 	mov	0x5306+0, #0x00
                           000024   125 	C$stm8s_tim2.c$68$1_0$349 ==.
                                    126 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 68: TIM2->CCMR3 = (uint8_t)TIM2_CCMR3_RESET_VALUE;
      009682 35 00 53 07      [ 1]  127 	mov	0x5307+0, #0x00
                           000028   128 	C$stm8s_tim2.c$69$1_0$349 ==.
                                    129 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 69: TIM2->CNTRH = (uint8_t)TIM2_CNTRH_RESET_VALUE;
      009686 35 00 53 0A      [ 1]  130 	mov	0x530a+0, #0x00
                           00002C   131 	C$stm8s_tim2.c$70$1_0$349 ==.
                                    132 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 70: TIM2->CNTRL = (uint8_t)TIM2_CNTRL_RESET_VALUE;
      00968A 35 00 53 0B      [ 1]  133 	mov	0x530b+0, #0x00
                           000030   134 	C$stm8s_tim2.c$71$1_0$349 ==.
                                    135 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 71: TIM2->PSCR = (uint8_t)TIM2_PSCR_RESET_VALUE;
      00968E 35 00 53 0C      [ 1]  136 	mov	0x530c+0, #0x00
                           000034   137 	C$stm8s_tim2.c$72$1_0$349 ==.
                                    138 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 72: TIM2->ARRH  = (uint8_t)TIM2_ARRH_RESET_VALUE;
      009692 35 FF 53 0D      [ 1]  139 	mov	0x530d+0, #0xff
                           000038   140 	C$stm8s_tim2.c$73$1_0$349 ==.
                                    141 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 73: TIM2->ARRL  = (uint8_t)TIM2_ARRL_RESET_VALUE;
      009696 35 FF 53 0E      [ 1]  142 	mov	0x530e+0, #0xff
                           00003C   143 	C$stm8s_tim2.c$74$1_0$349 ==.
                                    144 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 74: TIM2->CCR1H = (uint8_t)TIM2_CCR1H_RESET_VALUE;
      00969A 35 00 53 0F      [ 1]  145 	mov	0x530f+0, #0x00
                           000040   146 	C$stm8s_tim2.c$75$1_0$349 ==.
                                    147 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 75: TIM2->CCR1L = (uint8_t)TIM2_CCR1L_RESET_VALUE;
      00969E 35 00 53 10      [ 1]  148 	mov	0x5310+0, #0x00
                           000044   149 	C$stm8s_tim2.c$76$1_0$349 ==.
                                    150 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 76: TIM2->CCR2H = (uint8_t)TIM2_CCR2H_RESET_VALUE;
      0096A2 35 00 53 11      [ 1]  151 	mov	0x5311+0, #0x00
                           000048   152 	C$stm8s_tim2.c$77$1_0$349 ==.
                                    153 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 77: TIM2->CCR2L = (uint8_t)TIM2_CCR2L_RESET_VALUE;
      0096A6 35 00 53 12      [ 1]  154 	mov	0x5312+0, #0x00
                           00004C   155 	C$stm8s_tim2.c$78$1_0$349 ==.
                                    156 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 78: TIM2->CCR3H = (uint8_t)TIM2_CCR3H_RESET_VALUE;
      0096AA 35 00 53 13      [ 1]  157 	mov	0x5313+0, #0x00
                           000050   158 	C$stm8s_tim2.c$79$1_0$349 ==.
                                    159 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 79: TIM2->CCR3L = (uint8_t)TIM2_CCR3L_RESET_VALUE;
      0096AE 35 00 53 14      [ 1]  160 	mov	0x5314+0, #0x00
                           000054   161 	C$stm8s_tim2.c$80$1_0$349 ==.
                                    162 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 80: TIM2->SR1 = (uint8_t)TIM2_SR1_RESET_VALUE;
      0096B2 35 00 53 02      [ 1]  163 	mov	0x5302+0, #0x00
                           000058   164 	C$stm8s_tim2.c$81$1_0$349 ==.
                                    165 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 81: }
                           000058   166 	C$stm8s_tim2.c$81$1_0$349 ==.
                           000058   167 	XG$TIM2_DeInit$0$0 ==.
      0096B6 81               [ 4]  168 	ret
                           000059   169 	G$TIM2_TimeBaseInit$0$0 ==.
                           000059   170 	C$stm8s_tim2.c$89$1_0$351 ==.
                                    171 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 89: void TIM2_TimeBaseInit( TIM2_Prescaler_TypeDef TIM2_Prescaler,
                                    172 ;	-----------------------------------------
                                    173 ;	 function TIM2_TimeBaseInit
                                    174 ;	-----------------------------------------
      0096B7                        175 _TIM2_TimeBaseInit:
      0096B7 52 02            [ 2]  176 	sub	sp, #2
                           00005B   177 	C$stm8s_tim2.c$93$1_0$351 ==.
                                    178 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 93: TIM2->PSCR = (uint8_t)(TIM2_Prescaler);
      0096B9 AE 53 0C         [ 2]  179 	ldw	x, #0x530c
      0096BC 7B 05            [ 1]  180 	ld	a, (0x05, sp)
      0096BE F7               [ 1]  181 	ld	(x), a
                           000061   182 	C$stm8s_tim2.c$95$1_0$351 ==.
                                    183 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 95: TIM2->ARRH = (uint8_t)(TIM2_Period >> 8);
      0096BF 7B 06            [ 1]  184 	ld	a, (0x06, sp)
      0096C1 0F 01            [ 1]  185 	clr	(0x01, sp)
      0096C3 C7 53 0D         [ 1]  186 	ld	0x530d, a
                           000068   187 	C$stm8s_tim2.c$96$1_0$351 ==.
                                    188 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 96: TIM2->ARRL = (uint8_t)(TIM2_Period);
      0096C6 7B 07            [ 1]  189 	ld	a, (0x07, sp)
      0096C8 C7 53 0E         [ 1]  190 	ld	0x530e, a
                           00006D   191 	C$stm8s_tim2.c$97$1_0$351 ==.
                                    192 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 97: }
      0096CB 5B 02            [ 2]  193 	addw	sp, #2
                           00006F   194 	C$stm8s_tim2.c$97$1_0$351 ==.
                           00006F   195 	XG$TIM2_TimeBaseInit$0$0 ==.
      0096CD 81               [ 4]  196 	ret
                           000070   197 	G$TIM2_OC1Init$0$0 ==.
                           000070   198 	C$stm8s_tim2.c$108$1_0$353 ==.
                                    199 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 108: void TIM2_OC1Init(TIM2_OCMode_TypeDef TIM2_OCMode,
                                    200 ;	-----------------------------------------
                                    201 ;	 function TIM2_OC1Init
                                    202 ;	-----------------------------------------
      0096CE                        203 _TIM2_OC1Init:
      0096CE 52 02            [ 2]  204 	sub	sp, #2
                           000072   205 	C$stm8s_tim2.c$119$1_0$353 ==.
                                    206 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 119: TIM2->CCER1 &= (uint8_t)(~( TIM2_CCER1_CC1E | TIM2_CCER1_CC1P));
      0096D0 C6 53 08         [ 1]  207 	ld	a, 0x5308
      0096D3 A4 FC            [ 1]  208 	and	a, #0xfc
      0096D5 C7 53 08         [ 1]  209 	ld	0x5308, a
                           00007A   210 	C$stm8s_tim2.c$121$1_0$353 ==.
                                    211 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 121: TIM2->CCER1 |= (uint8_t)((uint8_t)(TIM2_OutputState & TIM2_CCER1_CC1E ) |
      0096D8 C6 53 08         [ 1]  212 	ld	a, 0x5308
      0096DB 6B 01            [ 1]  213 	ld	(0x01, sp), a
      0096DD 7B 06            [ 1]  214 	ld	a, (0x06, sp)
      0096DF A4 01            [ 1]  215 	and	a, #0x01
      0096E1 6B 02            [ 1]  216 	ld	(0x02, sp), a
                           000085   217 	C$stm8s_tim2.c$122$1_0$353 ==.
                                    218 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 122: (uint8_t)(TIM2_OCPolarity & TIM2_CCER1_CC1P));
      0096E3 7B 09            [ 1]  219 	ld	a, (0x09, sp)
      0096E5 A4 02            [ 1]  220 	and	a, #0x02
      0096E7 1A 02            [ 1]  221 	or	a, (0x02, sp)
      0096E9 1A 01            [ 1]  222 	or	a, (0x01, sp)
      0096EB C7 53 08         [ 1]  223 	ld	0x5308, a
                           000090   224 	C$stm8s_tim2.c$125$1_0$353 ==.
                                    225 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 125: TIM2->CCMR1 = (uint8_t)((uint8_t)(TIM2->CCMR1 & (uint8_t)(~TIM2_CCMR_OCM)) |
      0096EE C6 53 05         [ 1]  226 	ld	a, 0x5305
      0096F1 A4 8F            [ 1]  227 	and	a, #0x8f
                           000095   228 	C$stm8s_tim2.c$126$1_0$353 ==.
                                    229 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 126: (uint8_t)TIM2_OCMode);
      0096F3 1A 05            [ 1]  230 	or	a, (0x05, sp)
      0096F5 C7 53 05         [ 1]  231 	ld	0x5305, a
                           00009A   232 	C$stm8s_tim2.c$129$1_0$353 ==.
                                    233 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 129: TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
      0096F8 7B 07            [ 1]  234 	ld	a, (0x07, sp)
      0096FA C7 53 0F         [ 1]  235 	ld	0x530f, a
                           00009F   236 	C$stm8s_tim2.c$130$1_0$353 ==.
                                    237 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 130: TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
      0096FD 7B 08            [ 1]  238 	ld	a, (0x08, sp)
      0096FF C7 53 10         [ 1]  239 	ld	0x5310, a
                           0000A4   240 	C$stm8s_tim2.c$131$1_0$353 ==.
                                    241 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 131: }
      009702 5B 02            [ 2]  242 	addw	sp, #2
                           0000A6   243 	C$stm8s_tim2.c$131$1_0$353 ==.
                           0000A6   244 	XG$TIM2_OC1Init$0$0 ==.
      009704 81               [ 4]  245 	ret
                           0000A7   246 	G$TIM2_OC2Init$0$0 ==.
                           0000A7   247 	C$stm8s_tim2.c$142$1_0$355 ==.
                                    248 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 142: void TIM2_OC2Init(TIM2_OCMode_TypeDef TIM2_OCMode,
                                    249 ;	-----------------------------------------
                                    250 ;	 function TIM2_OC2Init
                                    251 ;	-----------------------------------------
      009705                        252 _TIM2_OC2Init:
      009705 52 02            [ 2]  253 	sub	sp, #2
                           0000A9   254 	C$stm8s_tim2.c$154$1_0$355 ==.
                                    255 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 154: TIM2->CCER1 &= (uint8_t)(~( TIM2_CCER1_CC2E |  TIM2_CCER1_CC2P ));
      009707 C6 53 08         [ 1]  256 	ld	a, 0x5308
      00970A A4 CF            [ 1]  257 	and	a, #0xcf
      00970C C7 53 08         [ 1]  258 	ld	0x5308, a
                           0000B1   259 	C$stm8s_tim2.c$156$1_0$355 ==.
                                    260 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 156: TIM2->CCER1 |= (uint8_t)((uint8_t)(TIM2_OutputState  & TIM2_CCER1_CC2E ) |
      00970F C6 53 08         [ 1]  261 	ld	a, 0x5308
      009712 6B 02            [ 1]  262 	ld	(0x02, sp), a
      009714 7B 06            [ 1]  263 	ld	a, (0x06, sp)
      009716 A4 10            [ 1]  264 	and	a, #0x10
      009718 6B 01            [ 1]  265 	ld	(0x01, sp), a
                           0000BC   266 	C$stm8s_tim2.c$157$1_0$355 ==.
                                    267 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 157: (uint8_t)(TIM2_OCPolarity & TIM2_CCER1_CC2P));
      00971A 7B 09            [ 1]  268 	ld	a, (0x09, sp)
      00971C A4 20            [ 1]  269 	and	a, #0x20
      00971E 1A 01            [ 1]  270 	or	a, (0x01, sp)
      009720 1A 02            [ 1]  271 	or	a, (0x02, sp)
      009722 C7 53 08         [ 1]  272 	ld	0x5308, a
                           0000C7   273 	C$stm8s_tim2.c$161$1_0$355 ==.
                                    274 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 161: TIM2->CCMR2 = (uint8_t)((uint8_t)(TIM2->CCMR2 & (uint8_t)(~TIM2_CCMR_OCM)) |
      009725 C6 53 06         [ 1]  275 	ld	a, 0x5306
      009728 A4 8F            [ 1]  276 	and	a, #0x8f
                           0000CC   277 	C$stm8s_tim2.c$162$1_0$355 ==.
                                    278 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 162: (uint8_t)TIM2_OCMode);
      00972A 1A 05            [ 1]  279 	or	a, (0x05, sp)
      00972C C7 53 06         [ 1]  280 	ld	0x5306, a
                           0000D1   281 	C$stm8s_tim2.c$166$1_0$355 ==.
                                    282 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 166: TIM2->CCR2H = (uint8_t)(TIM2_Pulse >> 8);
      00972F 7B 07            [ 1]  283 	ld	a, (0x07, sp)
      009731 C7 53 11         [ 1]  284 	ld	0x5311, a
                           0000D6   285 	C$stm8s_tim2.c$167$1_0$355 ==.
                                    286 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 167: TIM2->CCR2L = (uint8_t)(TIM2_Pulse);
      009734 7B 08            [ 1]  287 	ld	a, (0x08, sp)
      009736 C7 53 12         [ 1]  288 	ld	0x5312, a
                           0000DB   289 	C$stm8s_tim2.c$168$1_0$355 ==.
                                    290 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 168: }
      009739 5B 02            [ 2]  291 	addw	sp, #2
                           0000DD   292 	C$stm8s_tim2.c$168$1_0$355 ==.
                           0000DD   293 	XG$TIM2_OC2Init$0$0 ==.
      00973B 81               [ 4]  294 	ret
                           0000DE   295 	G$TIM2_OC3Init$0$0 ==.
                           0000DE   296 	C$stm8s_tim2.c$179$1_0$357 ==.
                                    297 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 179: void TIM2_OC3Init(TIM2_OCMode_TypeDef TIM2_OCMode,
                                    298 ;	-----------------------------------------
                                    299 ;	 function TIM2_OC3Init
                                    300 ;	-----------------------------------------
      00973C                        301 _TIM2_OC3Init:
      00973C 52 02            [ 2]  302 	sub	sp, #2
                           0000E0   303 	C$stm8s_tim2.c$189$1_0$357 ==.
                                    304 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 189: TIM2->CCER2 &= (uint8_t)(~( TIM2_CCER2_CC3E  | TIM2_CCER2_CC3P));
      00973E C6 53 09         [ 1]  305 	ld	a, 0x5309
      009741 A4 FC            [ 1]  306 	and	a, #0xfc
      009743 C7 53 09         [ 1]  307 	ld	0x5309, a
                           0000E8   308 	C$stm8s_tim2.c$191$1_0$357 ==.
                                    309 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 191: TIM2->CCER2 |= (uint8_t)((uint8_t)(TIM2_OutputState & TIM2_CCER2_CC3E) |
      009746 C6 53 09         [ 1]  310 	ld	a, 0x5309
      009749 6B 01            [ 1]  311 	ld	(0x01, sp), a
      00974B 7B 06            [ 1]  312 	ld	a, (0x06, sp)
      00974D A4 01            [ 1]  313 	and	a, #0x01
      00974F 6B 02            [ 1]  314 	ld	(0x02, sp), a
                           0000F3   315 	C$stm8s_tim2.c$192$1_0$357 ==.
                                    316 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 192: (uint8_t)(TIM2_OCPolarity & TIM2_CCER2_CC3P));
      009751 7B 09            [ 1]  317 	ld	a, (0x09, sp)
      009753 A4 02            [ 1]  318 	and	a, #0x02
      009755 1A 02            [ 1]  319 	or	a, (0x02, sp)
      009757 1A 01            [ 1]  320 	or	a, (0x01, sp)
      009759 C7 53 09         [ 1]  321 	ld	0x5309, a
                           0000FE   322 	C$stm8s_tim2.c$195$1_0$357 ==.
                                    323 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 195: TIM2->CCMR3 = (uint8_t)((uint8_t)(TIM2->CCMR3 & (uint8_t)(~TIM2_CCMR_OCM)) |
      00975C C6 53 07         [ 1]  324 	ld	a, 0x5307
      00975F A4 8F            [ 1]  325 	and	a, #0x8f
                           000103   326 	C$stm8s_tim2.c$196$1_0$357 ==.
                                    327 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 196: (uint8_t)TIM2_OCMode);
      009761 1A 05            [ 1]  328 	or	a, (0x05, sp)
      009763 C7 53 07         [ 1]  329 	ld	0x5307, a
                           000108   330 	C$stm8s_tim2.c$199$1_0$357 ==.
                                    331 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 199: TIM2->CCR3H = (uint8_t)(TIM2_Pulse >> 8);
      009766 7B 07            [ 1]  332 	ld	a, (0x07, sp)
      009768 C7 53 13         [ 1]  333 	ld	0x5313, a
                           00010D   334 	C$stm8s_tim2.c$200$1_0$357 ==.
                                    335 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 200: TIM2->CCR3L = (uint8_t)(TIM2_Pulse);
      00976B 7B 08            [ 1]  336 	ld	a, (0x08, sp)
      00976D C7 53 14         [ 1]  337 	ld	0x5314, a
                           000112   338 	C$stm8s_tim2.c$201$1_0$357 ==.
                                    339 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 201: }
      009770 5B 02            [ 2]  340 	addw	sp, #2
                           000114   341 	C$stm8s_tim2.c$201$1_0$357 ==.
                           000114   342 	XG$TIM2_OC3Init$0$0 ==.
      009772 81               [ 4]  343 	ret
                           000115   344 	G$TIM2_ICInit$0$0 ==.
                           000115   345 	C$stm8s_tim2.c$212$1_0$359 ==.
                                    346 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 212: void TIM2_ICInit(TIM2_Channel_TypeDef TIM2_Channel,
                                    347 ;	-----------------------------------------
                                    348 ;	 function TIM2_ICInit
                                    349 ;	-----------------------------------------
      009773                        350 _TIM2_ICInit:
                           000115   351 	C$stm8s_tim2.c$225$1_0$359 ==.
                                    352 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 225: if (TIM2_Channel == TIM2_CHANNEL_1)
      009773 0D 03            [ 1]  353 	tnz	(0x03, sp)
      009775 26 17            [ 1]  354 	jrne	00105$
                           000119   355 	C$stm8s_tim2.c$228$2_0$360 ==.
                                    356 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 228: TI1_Config((uint8_t)TIM2_ICPolarity,
      009777 7B 07            [ 1]  357 	ld	a, (0x07, sp)
      009779 88               [ 1]  358 	push	a
      00977A 7B 06            [ 1]  359 	ld	a, (0x06, sp)
      00977C 88               [ 1]  360 	push	a
      00977D 7B 06            [ 1]  361 	ld	a, (0x06, sp)
      00977F 88               [ 1]  362 	push	a
      009780 CD 9A D7         [ 4]  363 	call	_TI1_Config
      009783 5B 03            [ 2]  364 	addw	sp, #3
                           000127   365 	C$stm8s_tim2.c$233$2_0$360 ==.
                                    366 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 233: TIM2_SetIC1Prescaler(TIM2_ICPrescaler);
      009785 7B 06            [ 1]  367 	ld	a, (0x06, sp)
      009787 88               [ 1]  368 	push	a
      009788 CD 99 F9         [ 4]  369 	call	_TIM2_SetIC1Prescaler
      00978B 84               [ 1]  370 	pop	a
      00978C 20 31            [ 2]  371 	jra	00107$
      00978E                        372 00105$:
                           000130   373 	C$stm8s_tim2.c$235$1_0$359 ==.
                                    374 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 235: else if (TIM2_Channel == TIM2_CHANNEL_2)
      00978E 7B 03            [ 1]  375 	ld	a, (0x03, sp)
      009790 4A               [ 1]  376 	dec	a
      009791 26 17            [ 1]  377 	jrne	00102$
                           000135   378 	C$stm8s_tim2.c$238$2_0$361 ==.
                                    379 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 238: TI2_Config((uint8_t)TIM2_ICPolarity,
      009793 7B 07            [ 1]  380 	ld	a, (0x07, sp)
      009795 88               [ 1]  381 	push	a
      009796 7B 06            [ 1]  382 	ld	a, (0x06, sp)
      009798 88               [ 1]  383 	push	a
      009799 7B 06            [ 1]  384 	ld	a, (0x06, sp)
      00979B 88               [ 1]  385 	push	a
      00979C CD 9B 03         [ 4]  386 	call	_TI2_Config
      00979F 5B 03            [ 2]  387 	addw	sp, #3
                           000143   388 	C$stm8s_tim2.c$243$2_0$361 ==.
                                    389 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 243: TIM2_SetIC2Prescaler(TIM2_ICPrescaler);
      0097A1 7B 06            [ 1]  390 	ld	a, (0x06, sp)
      0097A3 88               [ 1]  391 	push	a
      0097A4 CD 9A 04         [ 4]  392 	call	_TIM2_SetIC2Prescaler
      0097A7 84               [ 1]  393 	pop	a
      0097A8 20 15            [ 2]  394 	jra	00107$
      0097AA                        395 00102$:
                           00014C   396 	C$stm8s_tim2.c$248$2_0$362 ==.
                                    397 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 248: TI3_Config((uint8_t)TIM2_ICPolarity,
      0097AA 7B 07            [ 1]  398 	ld	a, (0x07, sp)
      0097AC 88               [ 1]  399 	push	a
      0097AD 7B 06            [ 1]  400 	ld	a, (0x06, sp)
      0097AF 88               [ 1]  401 	push	a
      0097B0 7B 06            [ 1]  402 	ld	a, (0x06, sp)
      0097B2 88               [ 1]  403 	push	a
      0097B3 CD 9B 2F         [ 4]  404 	call	_TI3_Config
      0097B6 5B 03            [ 2]  405 	addw	sp, #3
                           00015A   406 	C$stm8s_tim2.c$253$2_0$362 ==.
                                    407 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 253: TIM2_SetIC3Prescaler(TIM2_ICPrescaler);
      0097B8 7B 06            [ 1]  408 	ld	a, (0x06, sp)
      0097BA 88               [ 1]  409 	push	a
      0097BB CD 9A 0F         [ 4]  410 	call	_TIM2_SetIC3Prescaler
      0097BE 84               [ 1]  411 	pop	a
      0097BF                        412 00107$:
                           000161   413 	C$stm8s_tim2.c$255$1_0$359 ==.
                                    414 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 255: }
                           000161   415 	C$stm8s_tim2.c$255$1_0$359 ==.
                           000161   416 	XG$TIM2_ICInit$0$0 ==.
      0097BF 81               [ 4]  417 	ret
                           000162   418 	G$TIM2_PWMIConfig$0$0 ==.
                           000162   419 	C$stm8s_tim2.c$266$1_0$364 ==.
                                    420 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 266: void TIM2_PWMIConfig(TIM2_Channel_TypeDef TIM2_Channel,
                                    421 ;	-----------------------------------------
                                    422 ;	 function TIM2_PWMIConfig
                                    423 ;	-----------------------------------------
      0097C0                        424 _TIM2_PWMIConfig:
      0097C0 52 02            [ 2]  425 	sub	sp, #2
                           000164   426 	C$stm8s_tim2.c$282$1_0$364 ==.
                                    427 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 282: if (TIM2_ICPolarity != TIM2_ICPOLARITY_FALLING)
      0097C2 7B 06            [ 1]  428 	ld	a, (0x06, sp)
      0097C4 A1 44            [ 1]  429 	cp	a, #0x44
      0097C6 27 06            [ 1]  430 	jreq	00102$
                           00016A   431 	C$stm8s_tim2.c$284$2_0$365 ==.
                                    432 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 284: icpolarity = (uint8_t)TIM2_ICPOLARITY_FALLING;
      0097C8 A6 44            [ 1]  433 	ld	a, #0x44
      0097CA 6B 01            [ 1]  434 	ld	(0x01, sp), a
      0097CC 20 02            [ 2]  435 	jra	00103$
      0097CE                        436 00102$:
                           000170   437 	C$stm8s_tim2.c$288$2_0$366 ==.
                                    438 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 288: icpolarity = (uint8_t)TIM2_ICPOLARITY_RISING;
      0097CE 0F 01            [ 1]  439 	clr	(0x01, sp)
      0097D0                        440 00103$:
                           000172   441 	C$stm8s_tim2.c$292$1_0$364 ==.
                                    442 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 292: if (TIM2_ICSelection == TIM2_ICSELECTION_DIRECTTI)
      0097D0 7B 07            [ 1]  443 	ld	a, (0x07, sp)
      0097D2 4A               [ 1]  444 	dec	a
      0097D3 26 06            [ 1]  445 	jrne	00105$
                           000177   446 	C$stm8s_tim2.c$294$2_0$367 ==.
                                    447 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 294: icselection = (uint8_t)TIM2_ICSELECTION_INDIRECTTI;
      0097D5 A6 02            [ 1]  448 	ld	a, #0x02
      0097D7 6B 02            [ 1]  449 	ld	(0x02, sp), a
      0097D9 20 04            [ 2]  450 	jra	00106$
      0097DB                        451 00105$:
                           00017D   452 	C$stm8s_tim2.c$298$2_0$368 ==.
                                    453 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 298: icselection = (uint8_t)TIM2_ICSELECTION_DIRECTTI;
      0097DB A6 01            [ 1]  454 	ld	a, #0x01
      0097DD 6B 02            [ 1]  455 	ld	(0x02, sp), a
      0097DF                        456 00106$:
                           000181   457 	C$stm8s_tim2.c$301$1_0$364 ==.
                                    458 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 301: if (TIM2_Channel == TIM2_CHANNEL_1)
      0097DF 0D 05            [ 1]  459 	tnz	(0x05, sp)
      0097E1 26 2C            [ 1]  460 	jrne	00108$
                           000185   461 	C$stm8s_tim2.c$304$2_0$369 ==.
                                    462 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 304: TI1_Config((uint8_t)TIM2_ICPolarity, (uint8_t)TIM2_ICSelection,
      0097E3 7B 09            [ 1]  463 	ld	a, (0x09, sp)
      0097E5 88               [ 1]  464 	push	a
      0097E6 7B 08            [ 1]  465 	ld	a, (0x08, sp)
      0097E8 88               [ 1]  466 	push	a
      0097E9 7B 08            [ 1]  467 	ld	a, (0x08, sp)
      0097EB 88               [ 1]  468 	push	a
      0097EC CD 9A D7         [ 4]  469 	call	_TI1_Config
      0097EF 5B 03            [ 2]  470 	addw	sp, #3
                           000193   471 	C$stm8s_tim2.c$308$2_0$369 ==.
                                    472 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 308: TIM2_SetIC1Prescaler(TIM2_ICPrescaler);
      0097F1 7B 08            [ 1]  473 	ld	a, (0x08, sp)
      0097F3 88               [ 1]  474 	push	a
      0097F4 CD 99 F9         [ 4]  475 	call	_TIM2_SetIC1Prescaler
      0097F7 84               [ 1]  476 	pop	a
                           00019A   477 	C$stm8s_tim2.c$311$2_0$369 ==.
                                    478 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 311: TI2_Config(icpolarity, icselection, TIM2_ICFilter);
      0097F8 7B 09            [ 1]  479 	ld	a, (0x09, sp)
      0097FA 88               [ 1]  480 	push	a
      0097FB 7B 03            [ 1]  481 	ld	a, (0x03, sp)
      0097FD 88               [ 1]  482 	push	a
      0097FE 7B 03            [ 1]  483 	ld	a, (0x03, sp)
      009800 88               [ 1]  484 	push	a
      009801 CD 9B 03         [ 4]  485 	call	_TI2_Config
      009804 5B 03            [ 2]  486 	addw	sp, #3
                           0001A8   487 	C$stm8s_tim2.c$314$2_0$369 ==.
                                    488 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 314: TIM2_SetIC2Prescaler(TIM2_ICPrescaler);
      009806 7B 08            [ 1]  489 	ld	a, (0x08, sp)
      009808 88               [ 1]  490 	push	a
      009809 CD 9A 04         [ 4]  491 	call	_TIM2_SetIC2Prescaler
      00980C 84               [ 1]  492 	pop	a
      00980D 20 2A            [ 2]  493 	jra	00110$
      00980F                        494 00108$:
                           0001B1   495 	C$stm8s_tim2.c$319$2_0$370 ==.
                                    496 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 319: TI2_Config((uint8_t)TIM2_ICPolarity, (uint8_t)TIM2_ICSelection,
      00980F 7B 09            [ 1]  497 	ld	a, (0x09, sp)
      009811 88               [ 1]  498 	push	a
      009812 7B 08            [ 1]  499 	ld	a, (0x08, sp)
      009814 88               [ 1]  500 	push	a
      009815 7B 08            [ 1]  501 	ld	a, (0x08, sp)
      009817 88               [ 1]  502 	push	a
      009818 CD 9B 03         [ 4]  503 	call	_TI2_Config
      00981B 5B 03            [ 2]  504 	addw	sp, #3
                           0001BF   505 	C$stm8s_tim2.c$323$2_0$370 ==.
                                    506 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 323: TIM2_SetIC2Prescaler(TIM2_ICPrescaler);
      00981D 7B 08            [ 1]  507 	ld	a, (0x08, sp)
      00981F 88               [ 1]  508 	push	a
      009820 CD 9A 04         [ 4]  509 	call	_TIM2_SetIC2Prescaler
      009823 84               [ 1]  510 	pop	a
                           0001C6   511 	C$stm8s_tim2.c$326$2_0$370 ==.
                                    512 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 326: TI1_Config((uint8_t)icpolarity, icselection, (uint8_t)TIM2_ICFilter);
      009824 7B 09            [ 1]  513 	ld	a, (0x09, sp)
      009826 88               [ 1]  514 	push	a
      009827 7B 03            [ 1]  515 	ld	a, (0x03, sp)
      009829 88               [ 1]  516 	push	a
      00982A 7B 03            [ 1]  517 	ld	a, (0x03, sp)
      00982C 88               [ 1]  518 	push	a
      00982D CD 9A D7         [ 4]  519 	call	_TI1_Config
      009830 5B 03            [ 2]  520 	addw	sp, #3
                           0001D4   521 	C$stm8s_tim2.c$329$2_0$370 ==.
                                    522 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 329: TIM2_SetIC1Prescaler(TIM2_ICPrescaler);
      009832 7B 08            [ 1]  523 	ld	a, (0x08, sp)
      009834 88               [ 1]  524 	push	a
      009835 CD 99 F9         [ 4]  525 	call	_TIM2_SetIC1Prescaler
      009838 84               [ 1]  526 	pop	a
      009839                        527 00110$:
                           0001DB   528 	C$stm8s_tim2.c$331$1_0$364 ==.
                                    529 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 331: }
      009839 5B 02            [ 2]  530 	addw	sp, #2
                           0001DD   531 	C$stm8s_tim2.c$331$1_0$364 ==.
                           0001DD   532 	XG$TIM2_PWMIConfig$0$0 ==.
      00983B 81               [ 4]  533 	ret
                           0001DE   534 	G$TIM2_Cmd$0$0 ==.
                           0001DE   535 	C$stm8s_tim2.c$339$1_0$372 ==.
                                    536 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 339: void TIM2_Cmd(FunctionalState NewState)
                                    537 ;	-----------------------------------------
                                    538 ;	 function TIM2_Cmd
                                    539 ;	-----------------------------------------
      00983C                        540 _TIM2_Cmd:
                           0001DE   541 	C$stm8s_tim2.c$345$1_0$372 ==.
                                    542 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 345: if (NewState != DISABLE)
      00983C 0D 03            [ 1]  543 	tnz	(0x03, sp)
      00983E 27 06            [ 1]  544 	jreq	00102$
                           0001E2   545 	C$stm8s_tim2.c$347$2_0$373 ==.
                                    546 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 347: TIM2->CR1 |= (uint8_t)TIM2_CR1_CEN;
      009840 72 10 53 00      [ 1]  547 	bset	21248, #0
      009844 20 04            [ 2]  548 	jra	00104$
      009846                        549 00102$:
                           0001E8   550 	C$stm8s_tim2.c$351$2_0$374 ==.
                                    551 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 351: TIM2->CR1 &= (uint8_t)(~TIM2_CR1_CEN);
      009846 72 11 53 00      [ 1]  552 	bres	21248, #0
      00984A                        553 00104$:
                           0001EC   554 	C$stm8s_tim2.c$353$1_0$372 ==.
                                    555 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 353: }
                           0001EC   556 	C$stm8s_tim2.c$353$1_0$372 ==.
                           0001EC   557 	XG$TIM2_Cmd$0$0 ==.
      00984A 81               [ 4]  558 	ret
                           0001ED   559 	G$TIM2_ITConfig$0$0 ==.
                           0001ED   560 	C$stm8s_tim2.c$368$1_0$376 ==.
                                    561 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 368: void TIM2_ITConfig(TIM2_IT_TypeDef TIM2_IT, FunctionalState NewState)
                                    562 ;	-----------------------------------------
                                    563 ;	 function TIM2_ITConfig
                                    564 ;	-----------------------------------------
      00984B                        565 _TIM2_ITConfig:
      00984B 88               [ 1]  566 	push	a
                           0001EE   567 	C$stm8s_tim2.c$374$1_0$376 ==.
                                    568 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 374: if (NewState != DISABLE)
      00984C 0D 05            [ 1]  569 	tnz	(0x05, sp)
      00984E 27 0A            [ 1]  570 	jreq	00102$
                           0001F2   571 	C$stm8s_tim2.c$377$2_0$377 ==.
                                    572 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 377: TIM2->IER |= (uint8_t)TIM2_IT;
      009850 C6 53 01         [ 1]  573 	ld	a, 0x5301
      009853 1A 04            [ 1]  574 	or	a, (0x04, sp)
      009855 C7 53 01         [ 1]  575 	ld	0x5301, a
      009858 20 0D            [ 2]  576 	jra	00104$
      00985A                        577 00102$:
                           0001FC   578 	C$stm8s_tim2.c$382$2_0$378 ==.
                                    579 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 382: TIM2->IER &= (uint8_t)(~TIM2_IT);
      00985A C6 53 01         [ 1]  580 	ld	a, 0x5301
      00985D 6B 01            [ 1]  581 	ld	(0x01, sp), a
      00985F 7B 04            [ 1]  582 	ld	a, (0x04, sp)
      009861 43               [ 1]  583 	cpl	a
      009862 14 01            [ 1]  584 	and	a, (0x01, sp)
      009864 C7 53 01         [ 1]  585 	ld	0x5301, a
      009867                        586 00104$:
                           000209   587 	C$stm8s_tim2.c$384$1_0$376 ==.
                                    588 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 384: }
      009867 84               [ 1]  589 	pop	a
                           00020A   590 	C$stm8s_tim2.c$384$1_0$376 ==.
                           00020A   591 	XG$TIM2_ITConfig$0$0 ==.
      009868 81               [ 4]  592 	ret
                           00020B   593 	G$TIM2_UpdateDisableConfig$0$0 ==.
                           00020B   594 	C$stm8s_tim2.c$392$1_0$380 ==.
                                    595 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 392: void TIM2_UpdateDisableConfig(FunctionalState NewState)
                                    596 ;	-----------------------------------------
                                    597 ;	 function TIM2_UpdateDisableConfig
                                    598 ;	-----------------------------------------
      009869                        599 _TIM2_UpdateDisableConfig:
                           00020B   600 	C$stm8s_tim2.c$398$1_0$380 ==.
                                    601 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 398: if (NewState != DISABLE)
      009869 0D 03            [ 1]  602 	tnz	(0x03, sp)
      00986B 27 06            [ 1]  603 	jreq	00102$
                           00020F   604 	C$stm8s_tim2.c$400$2_0$381 ==.
                                    605 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 400: TIM2->CR1 |= (uint8_t)TIM2_CR1_UDIS;
      00986D 72 12 53 00      [ 1]  606 	bset	21248, #1
      009871 20 04            [ 2]  607 	jra	00104$
      009873                        608 00102$:
                           000215   609 	C$stm8s_tim2.c$404$2_0$382 ==.
                                    610 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 404: TIM2->CR1 &= (uint8_t)(~TIM2_CR1_UDIS);
      009873 72 13 53 00      [ 1]  611 	bres	21248, #1
      009877                        612 00104$:
                           000219   613 	C$stm8s_tim2.c$406$1_0$380 ==.
                                    614 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 406: }
                           000219   615 	C$stm8s_tim2.c$406$1_0$380 ==.
                           000219   616 	XG$TIM2_UpdateDisableConfig$0$0 ==.
      009877 81               [ 4]  617 	ret
                           00021A   618 	G$TIM2_UpdateRequestConfig$0$0 ==.
                           00021A   619 	C$stm8s_tim2.c$416$1_0$384 ==.
                                    620 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 416: void TIM2_UpdateRequestConfig(TIM2_UpdateSource_TypeDef TIM2_UpdateSource)
                                    621 ;	-----------------------------------------
                                    622 ;	 function TIM2_UpdateRequestConfig
                                    623 ;	-----------------------------------------
      009878                        624 _TIM2_UpdateRequestConfig:
                           00021A   625 	C$stm8s_tim2.c$422$1_0$384 ==.
                                    626 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 422: if (TIM2_UpdateSource != TIM2_UPDATESOURCE_GLOBAL)
      009878 0D 03            [ 1]  627 	tnz	(0x03, sp)
      00987A 27 06            [ 1]  628 	jreq	00102$
                           00021E   629 	C$stm8s_tim2.c$424$2_0$385 ==.
                                    630 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 424: TIM2->CR1 |= (uint8_t)TIM2_CR1_URS;
      00987C 72 14 53 00      [ 1]  631 	bset	21248, #2
      009880 20 04            [ 2]  632 	jra	00104$
      009882                        633 00102$:
                           000224   634 	C$stm8s_tim2.c$428$2_0$386 ==.
                                    635 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 428: TIM2->CR1 &= (uint8_t)(~TIM2_CR1_URS);
      009882 72 15 53 00      [ 1]  636 	bres	21248, #2
      009886                        637 00104$:
                           000228   638 	C$stm8s_tim2.c$430$1_0$384 ==.
                                    639 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 430: }
                           000228   640 	C$stm8s_tim2.c$430$1_0$384 ==.
                           000228   641 	XG$TIM2_UpdateRequestConfig$0$0 ==.
      009886 81               [ 4]  642 	ret
                           000229   643 	G$TIM2_SelectOnePulseMode$0$0 ==.
                           000229   644 	C$stm8s_tim2.c$440$1_0$388 ==.
                                    645 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 440: void TIM2_SelectOnePulseMode(TIM2_OPMode_TypeDef TIM2_OPMode)
                                    646 ;	-----------------------------------------
                                    647 ;	 function TIM2_SelectOnePulseMode
                                    648 ;	-----------------------------------------
      009887                        649 _TIM2_SelectOnePulseMode:
                           000229   650 	C$stm8s_tim2.c$446$1_0$388 ==.
                                    651 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 446: if (TIM2_OPMode != TIM2_OPMODE_REPETITIVE)
      009887 0D 03            [ 1]  652 	tnz	(0x03, sp)
      009889 27 06            [ 1]  653 	jreq	00102$
                           00022D   654 	C$stm8s_tim2.c$448$2_0$389 ==.
                                    655 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 448: TIM2->CR1 |= (uint8_t)TIM2_CR1_OPM;
      00988B 72 16 53 00      [ 1]  656 	bset	21248, #3
      00988F 20 04            [ 2]  657 	jra	00104$
      009891                        658 00102$:
                           000233   659 	C$stm8s_tim2.c$452$2_0$390 ==.
                                    660 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 452: TIM2->CR1 &= (uint8_t)(~TIM2_CR1_OPM);
      009891 72 17 53 00      [ 1]  661 	bres	21248, #3
      009895                        662 00104$:
                           000237   663 	C$stm8s_tim2.c$454$1_0$388 ==.
                                    664 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 454: }
                           000237   665 	C$stm8s_tim2.c$454$1_0$388 ==.
                           000237   666 	XG$TIM2_SelectOnePulseMode$0$0 ==.
      009895 81               [ 4]  667 	ret
                           000238   668 	G$TIM2_PrescalerConfig$0$0 ==.
                           000238   669 	C$stm8s_tim2.c$484$1_0$392 ==.
                                    670 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 484: void TIM2_PrescalerConfig(TIM2_Prescaler_TypeDef Prescaler,
                                    671 ;	-----------------------------------------
                                    672 ;	 function TIM2_PrescalerConfig
                                    673 ;	-----------------------------------------
      009896                        674 _TIM2_PrescalerConfig:
                           000238   675 	C$stm8s_tim2.c$492$1_0$392 ==.
                                    676 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 492: TIM2->PSCR = (uint8_t)Prescaler;
      009896 AE 53 0C         [ 2]  677 	ldw	x, #0x530c
      009899 7B 03            [ 1]  678 	ld	a, (0x03, sp)
      00989B F7               [ 1]  679 	ld	(x), a
                           00023E   680 	C$stm8s_tim2.c$495$1_0$392 ==.
                                    681 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 495: TIM2->EGR = (uint8_t)TIM2_PSCReloadMode;
      00989C AE 53 04         [ 2]  682 	ldw	x, #0x5304
      00989F 7B 04            [ 1]  683 	ld	a, (0x04, sp)
      0098A1 F7               [ 1]  684 	ld	(x), a
                           000244   685 	C$stm8s_tim2.c$496$1_0$392 ==.
                                    686 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 496: }
                           000244   687 	C$stm8s_tim2.c$496$1_0$392 ==.
                           000244   688 	XG$TIM2_PrescalerConfig$0$0 ==.
      0098A2 81               [ 4]  689 	ret
                           000245   690 	G$TIM2_ForcedOC1Config$0$0 ==.
                           000245   691 	C$stm8s_tim2.c$507$1_0$394 ==.
                                    692 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 507: void TIM2_ForcedOC1Config(TIM2_ForcedAction_TypeDef TIM2_ForcedAction)
                                    693 ;	-----------------------------------------
                                    694 ;	 function TIM2_ForcedOC1Config
                                    695 ;	-----------------------------------------
      0098A3                        696 _TIM2_ForcedOC1Config:
                           000245   697 	C$stm8s_tim2.c$513$1_0$394 ==.
                                    698 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 513: TIM2->CCMR1  =  (uint8_t)((uint8_t)(TIM2->CCMR1 & (uint8_t)(~TIM2_CCMR_OCM))
      0098A3 C6 53 05         [ 1]  699 	ld	a, 0x5305
      0098A6 A4 8F            [ 1]  700 	and	a, #0x8f
                           00024A   701 	C$stm8s_tim2.c$514$1_0$394 ==.
                                    702 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 514: | (uint8_t)TIM2_ForcedAction);
      0098A8 1A 03            [ 1]  703 	or	a, (0x03, sp)
      0098AA C7 53 05         [ 1]  704 	ld	0x5305, a
                           00024F   705 	C$stm8s_tim2.c$515$1_0$394 ==.
                                    706 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 515: }
                           00024F   707 	C$stm8s_tim2.c$515$1_0$394 ==.
                           00024F   708 	XG$TIM2_ForcedOC1Config$0$0 ==.
      0098AD 81               [ 4]  709 	ret
                           000250   710 	G$TIM2_ForcedOC2Config$0$0 ==.
                           000250   711 	C$stm8s_tim2.c$526$1_0$396 ==.
                                    712 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 526: void TIM2_ForcedOC2Config(TIM2_ForcedAction_TypeDef TIM2_ForcedAction)
                                    713 ;	-----------------------------------------
                                    714 ;	 function TIM2_ForcedOC2Config
                                    715 ;	-----------------------------------------
      0098AE                        716 _TIM2_ForcedOC2Config:
                           000250   717 	C$stm8s_tim2.c$532$1_0$396 ==.
                                    718 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 532: TIM2->CCMR2 = (uint8_t)((uint8_t)(TIM2->CCMR2 & (uint8_t)(~TIM2_CCMR_OCM))
      0098AE C6 53 06         [ 1]  719 	ld	a, 0x5306
      0098B1 A4 8F            [ 1]  720 	and	a, #0x8f
                           000255   721 	C$stm8s_tim2.c$533$1_0$396 ==.
                                    722 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 533: | (uint8_t)TIM2_ForcedAction);
      0098B3 1A 03            [ 1]  723 	or	a, (0x03, sp)
      0098B5 C7 53 06         [ 1]  724 	ld	0x5306, a
                           00025A   725 	C$stm8s_tim2.c$534$1_0$396 ==.
                                    726 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 534: }
                           00025A   727 	C$stm8s_tim2.c$534$1_0$396 ==.
                           00025A   728 	XG$TIM2_ForcedOC2Config$0$0 ==.
      0098B8 81               [ 4]  729 	ret
                           00025B   730 	G$TIM2_ForcedOC3Config$0$0 ==.
                           00025B   731 	C$stm8s_tim2.c$545$1_0$398 ==.
                                    732 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 545: void TIM2_ForcedOC3Config(TIM2_ForcedAction_TypeDef TIM2_ForcedAction)
                                    733 ;	-----------------------------------------
                                    734 ;	 function TIM2_ForcedOC3Config
                                    735 ;	-----------------------------------------
      0098B9                        736 _TIM2_ForcedOC3Config:
                           00025B   737 	C$stm8s_tim2.c$551$1_0$398 ==.
                                    738 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 551: TIM2->CCMR3  =  (uint8_t)((uint8_t)(TIM2->CCMR3 & (uint8_t)(~TIM2_CCMR_OCM))
      0098B9 C6 53 07         [ 1]  739 	ld	a, 0x5307
      0098BC A4 8F            [ 1]  740 	and	a, #0x8f
                           000260   741 	C$stm8s_tim2.c$552$1_0$398 ==.
                                    742 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 552: | (uint8_t)TIM2_ForcedAction);
      0098BE 1A 03            [ 1]  743 	or	a, (0x03, sp)
      0098C0 C7 53 07         [ 1]  744 	ld	0x5307, a
                           000265   745 	C$stm8s_tim2.c$553$1_0$398 ==.
                                    746 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 553: }
                           000265   747 	C$stm8s_tim2.c$553$1_0$398 ==.
                           000265   748 	XG$TIM2_ForcedOC3Config$0$0 ==.
      0098C3 81               [ 4]  749 	ret
                           000266   750 	G$TIM2_ARRPreloadConfig$0$0 ==.
                           000266   751 	C$stm8s_tim2.c$561$1_0$400 ==.
                                    752 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 561: void TIM2_ARRPreloadConfig(FunctionalState NewState)
                                    753 ;	-----------------------------------------
                                    754 ;	 function TIM2_ARRPreloadConfig
                                    755 ;	-----------------------------------------
      0098C4                        756 _TIM2_ARRPreloadConfig:
                           000266   757 	C$stm8s_tim2.c$567$1_0$400 ==.
                                    758 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 567: if (NewState != DISABLE)
      0098C4 0D 03            [ 1]  759 	tnz	(0x03, sp)
      0098C6 27 06            [ 1]  760 	jreq	00102$
                           00026A   761 	C$stm8s_tim2.c$569$2_0$401 ==.
                                    762 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 569: TIM2->CR1 |= (uint8_t)TIM2_CR1_ARPE;
      0098C8 72 1E 53 00      [ 1]  763 	bset	21248, #7
      0098CC 20 04            [ 2]  764 	jra	00104$
      0098CE                        765 00102$:
                           000270   766 	C$stm8s_tim2.c$573$2_0$402 ==.
                                    767 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 573: TIM2->CR1 &= (uint8_t)(~TIM2_CR1_ARPE);
      0098CE 72 1F 53 00      [ 1]  768 	bres	21248, #7
      0098D2                        769 00104$:
                           000274   770 	C$stm8s_tim2.c$575$1_0$400 ==.
                                    771 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 575: }
                           000274   772 	C$stm8s_tim2.c$575$1_0$400 ==.
                           000274   773 	XG$TIM2_ARRPreloadConfig$0$0 ==.
      0098D2 81               [ 4]  774 	ret
                           000275   775 	G$TIM2_OC1PreloadConfig$0$0 ==.
                           000275   776 	C$stm8s_tim2.c$583$1_0$404 ==.
                                    777 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 583: void TIM2_OC1PreloadConfig(FunctionalState NewState)
                                    778 ;	-----------------------------------------
                                    779 ;	 function TIM2_OC1PreloadConfig
                                    780 ;	-----------------------------------------
      0098D3                        781 _TIM2_OC1PreloadConfig:
                           000275   782 	C$stm8s_tim2.c$589$1_0$404 ==.
                                    783 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 589: if (NewState != DISABLE)
      0098D3 0D 03            [ 1]  784 	tnz	(0x03, sp)
      0098D5 27 06            [ 1]  785 	jreq	00102$
                           000279   786 	C$stm8s_tim2.c$591$2_0$405 ==.
                                    787 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 591: TIM2->CCMR1 |= (uint8_t)TIM2_CCMR_OCxPE;
      0098D7 72 16 53 05      [ 1]  788 	bset	21253, #3
      0098DB 20 04            [ 2]  789 	jra	00104$
      0098DD                        790 00102$:
                           00027F   791 	C$stm8s_tim2.c$595$2_0$406 ==.
                                    792 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 595: TIM2->CCMR1 &= (uint8_t)(~TIM2_CCMR_OCxPE);
      0098DD 72 17 53 05      [ 1]  793 	bres	21253, #3
      0098E1                        794 00104$:
                           000283   795 	C$stm8s_tim2.c$597$1_0$404 ==.
                                    796 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 597: }
                           000283   797 	C$stm8s_tim2.c$597$1_0$404 ==.
                           000283   798 	XG$TIM2_OC1PreloadConfig$0$0 ==.
      0098E1 81               [ 4]  799 	ret
                           000284   800 	G$TIM2_OC2PreloadConfig$0$0 ==.
                           000284   801 	C$stm8s_tim2.c$605$1_0$408 ==.
                                    802 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 605: void TIM2_OC2PreloadConfig(FunctionalState NewState)
                                    803 ;	-----------------------------------------
                                    804 ;	 function TIM2_OC2PreloadConfig
                                    805 ;	-----------------------------------------
      0098E2                        806 _TIM2_OC2PreloadConfig:
                           000284   807 	C$stm8s_tim2.c$611$1_0$408 ==.
                                    808 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 611: if (NewState != DISABLE)
      0098E2 0D 03            [ 1]  809 	tnz	(0x03, sp)
      0098E4 27 06            [ 1]  810 	jreq	00102$
                           000288   811 	C$stm8s_tim2.c$613$2_0$409 ==.
                                    812 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 613: TIM2->CCMR2 |= (uint8_t)TIM2_CCMR_OCxPE;
      0098E6 72 16 53 06      [ 1]  813 	bset	21254, #3
      0098EA 20 04            [ 2]  814 	jra	00104$
      0098EC                        815 00102$:
                           00028E   816 	C$stm8s_tim2.c$617$2_0$410 ==.
                                    817 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 617: TIM2->CCMR2 &= (uint8_t)(~TIM2_CCMR_OCxPE);
      0098EC 72 17 53 06      [ 1]  818 	bres	21254, #3
      0098F0                        819 00104$:
                           000292   820 	C$stm8s_tim2.c$619$1_0$408 ==.
                                    821 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 619: }
                           000292   822 	C$stm8s_tim2.c$619$1_0$408 ==.
                           000292   823 	XG$TIM2_OC2PreloadConfig$0$0 ==.
      0098F0 81               [ 4]  824 	ret
                           000293   825 	G$TIM2_OC3PreloadConfig$0$0 ==.
                           000293   826 	C$stm8s_tim2.c$627$1_0$412 ==.
                                    827 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 627: void TIM2_OC3PreloadConfig(FunctionalState NewState)
                                    828 ;	-----------------------------------------
                                    829 ;	 function TIM2_OC3PreloadConfig
                                    830 ;	-----------------------------------------
      0098F1                        831 _TIM2_OC3PreloadConfig:
                           000293   832 	C$stm8s_tim2.c$633$1_0$412 ==.
                                    833 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 633: if (NewState != DISABLE)
      0098F1 0D 03            [ 1]  834 	tnz	(0x03, sp)
      0098F3 27 06            [ 1]  835 	jreq	00102$
                           000297   836 	C$stm8s_tim2.c$635$2_0$413 ==.
                                    837 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 635: TIM2->CCMR3 |= (uint8_t)TIM2_CCMR_OCxPE;
      0098F5 72 16 53 07      [ 1]  838 	bset	21255, #3
      0098F9 20 04            [ 2]  839 	jra	00104$
      0098FB                        840 00102$:
                           00029D   841 	C$stm8s_tim2.c$639$2_0$414 ==.
                                    842 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 639: TIM2->CCMR3 &= (uint8_t)(~TIM2_CCMR_OCxPE);
      0098FB 72 17 53 07      [ 1]  843 	bres	21255, #3
      0098FF                        844 00104$:
                           0002A1   845 	C$stm8s_tim2.c$641$1_0$412 ==.
                                    846 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 641: }
                           0002A1   847 	C$stm8s_tim2.c$641$1_0$412 ==.
                           0002A1   848 	XG$TIM2_OC3PreloadConfig$0$0 ==.
      0098FF 81               [ 4]  849 	ret
                           0002A2   850 	G$TIM2_GenerateEvent$0$0 ==.
                           0002A2   851 	C$stm8s_tim2.c$653$1_0$416 ==.
                                    852 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 653: void TIM2_GenerateEvent(TIM2_EventSource_TypeDef TIM2_EventSource)
                                    853 ;	-----------------------------------------
                                    854 ;	 function TIM2_GenerateEvent
                                    855 ;	-----------------------------------------
      009900                        856 _TIM2_GenerateEvent:
                           0002A2   857 	C$stm8s_tim2.c$659$1_0$416 ==.
                                    858 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 659: TIM2->EGR = (uint8_t)TIM2_EventSource;
      009900 AE 53 04         [ 2]  859 	ldw	x, #0x5304
      009903 7B 03            [ 1]  860 	ld	a, (0x03, sp)
      009905 F7               [ 1]  861 	ld	(x), a
                           0002A8   862 	C$stm8s_tim2.c$660$1_0$416 ==.
                                    863 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 660: }
                           0002A8   864 	C$stm8s_tim2.c$660$1_0$416 ==.
                           0002A8   865 	XG$TIM2_GenerateEvent$0$0 ==.
      009906 81               [ 4]  866 	ret
                           0002A9   867 	G$TIM2_OC1PolarityConfig$0$0 ==.
                           0002A9   868 	C$stm8s_tim2.c$670$1_0$418 ==.
                                    869 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 670: void TIM2_OC1PolarityConfig(TIM2_OCPolarity_TypeDef TIM2_OCPolarity)
                                    870 ;	-----------------------------------------
                                    871 ;	 function TIM2_OC1PolarityConfig
                                    872 ;	-----------------------------------------
      009907                        873 _TIM2_OC1PolarityConfig:
                           0002A9   874 	C$stm8s_tim2.c$676$1_0$418 ==.
                                    875 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 676: if (TIM2_OCPolarity != TIM2_OCPOLARITY_HIGH)
      009907 0D 03            [ 1]  876 	tnz	(0x03, sp)
      009909 27 06            [ 1]  877 	jreq	00102$
                           0002AD   878 	C$stm8s_tim2.c$678$2_0$419 ==.
                                    879 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 678: TIM2->CCER1 |= (uint8_t)TIM2_CCER1_CC1P;
      00990B 72 12 53 08      [ 1]  880 	bset	21256, #1
      00990F 20 04            [ 2]  881 	jra	00104$
      009911                        882 00102$:
                           0002B3   883 	C$stm8s_tim2.c$682$2_0$420 ==.
                                    884 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 682: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC1P);
      009911 72 13 53 08      [ 1]  885 	bres	21256, #1
      009915                        886 00104$:
                           0002B7   887 	C$stm8s_tim2.c$684$1_0$418 ==.
                                    888 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 684: }
                           0002B7   889 	C$stm8s_tim2.c$684$1_0$418 ==.
                           0002B7   890 	XG$TIM2_OC1PolarityConfig$0$0 ==.
      009915 81               [ 4]  891 	ret
                           0002B8   892 	G$TIM2_OC2PolarityConfig$0$0 ==.
                           0002B8   893 	C$stm8s_tim2.c$694$1_0$422 ==.
                                    894 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 694: void TIM2_OC2PolarityConfig(TIM2_OCPolarity_TypeDef TIM2_OCPolarity)
                                    895 ;	-----------------------------------------
                                    896 ;	 function TIM2_OC2PolarityConfig
                                    897 ;	-----------------------------------------
      009916                        898 _TIM2_OC2PolarityConfig:
                           0002B8   899 	C$stm8s_tim2.c$700$1_0$422 ==.
                                    900 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 700: if (TIM2_OCPolarity != TIM2_OCPOLARITY_HIGH)
      009916 0D 03            [ 1]  901 	tnz	(0x03, sp)
      009918 27 06            [ 1]  902 	jreq	00102$
                           0002BC   903 	C$stm8s_tim2.c$702$2_0$423 ==.
                                    904 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 702: TIM2->CCER1 |= TIM2_CCER1_CC2P;
      00991A 72 1A 53 08      [ 1]  905 	bset	21256, #5
      00991E 20 04            [ 2]  906 	jra	00104$
      009920                        907 00102$:
                           0002C2   908 	C$stm8s_tim2.c$706$2_0$424 ==.
                                    909 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 706: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC2P);
      009920 72 1B 53 08      [ 1]  910 	bres	21256, #5
      009924                        911 00104$:
                           0002C6   912 	C$stm8s_tim2.c$708$1_0$422 ==.
                                    913 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 708: }
                           0002C6   914 	C$stm8s_tim2.c$708$1_0$422 ==.
                           0002C6   915 	XG$TIM2_OC2PolarityConfig$0$0 ==.
      009924 81               [ 4]  916 	ret
                           0002C7   917 	G$TIM2_OC3PolarityConfig$0$0 ==.
                           0002C7   918 	C$stm8s_tim2.c$718$1_0$426 ==.
                                    919 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 718: void TIM2_OC3PolarityConfig(TIM2_OCPolarity_TypeDef TIM2_OCPolarity)
                                    920 ;	-----------------------------------------
                                    921 ;	 function TIM2_OC3PolarityConfig
                                    922 ;	-----------------------------------------
      009925                        923 _TIM2_OC3PolarityConfig:
                           0002C7   924 	C$stm8s_tim2.c$724$1_0$426 ==.
                                    925 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 724: if (TIM2_OCPolarity != TIM2_OCPOLARITY_HIGH)
      009925 0D 03            [ 1]  926 	tnz	(0x03, sp)
      009927 27 06            [ 1]  927 	jreq	00102$
                           0002CB   928 	C$stm8s_tim2.c$726$2_0$427 ==.
                                    929 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 726: TIM2->CCER2 |= (uint8_t)TIM2_CCER2_CC3P;
      009929 72 12 53 09      [ 1]  930 	bset	21257, #1
      00992D 20 04            [ 2]  931 	jra	00104$
      00992F                        932 00102$:
                           0002D1   933 	C$stm8s_tim2.c$730$2_0$428 ==.
                                    934 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 730: TIM2->CCER2 &= (uint8_t)(~TIM2_CCER2_CC3P);
      00992F 72 13 53 09      [ 1]  935 	bres	21257, #1
      009933                        936 00104$:
                           0002D5   937 	C$stm8s_tim2.c$732$1_0$426 ==.
                                    938 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 732: }
                           0002D5   939 	C$stm8s_tim2.c$732$1_0$426 ==.
                           0002D5   940 	XG$TIM2_OC3PolarityConfig$0$0 ==.
      009933 81               [ 4]  941 	ret
                           0002D6   942 	G$TIM2_CCxCmd$0$0 ==.
                           0002D6   943 	C$stm8s_tim2.c$745$1_0$430 ==.
                                    944 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 745: void TIM2_CCxCmd(TIM2_Channel_TypeDef TIM2_Channel, FunctionalState NewState)
                                    945 ;	-----------------------------------------
                                    946 ;	 function TIM2_CCxCmd
                                    947 ;	-----------------------------------------
      009934                        948 _TIM2_CCxCmd:
                           0002D6   949 	C$stm8s_tim2.c$751$1_0$430 ==.
                                    950 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 751: if (TIM2_Channel == TIM2_CHANNEL_1)
      009934 0D 03            [ 1]  951 	tnz	(0x03, sp)
      009936 26 10            [ 1]  952 	jrne	00114$
                           0002DA   953 	C$stm8s_tim2.c$754$2_0$431 ==.
                                    954 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 754: if (NewState != DISABLE)
      009938 0D 04            [ 1]  955 	tnz	(0x04, sp)
      00993A 27 06            [ 1]  956 	jreq	00102$
                           0002DE   957 	C$stm8s_tim2.c$756$3_0$432 ==.
                                    958 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 756: TIM2->CCER1 |= (uint8_t)TIM2_CCER1_CC1E;
      00993C 72 10 53 08      [ 1]  959 	bset	21256, #0
      009940 20 29            [ 2]  960 	jra	00116$
      009942                        961 00102$:
                           0002E4   962 	C$stm8s_tim2.c$760$3_0$433 ==.
                                    963 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 760: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC1E);
      009942 72 11 53 08      [ 1]  964 	bres	21256, #0
      009946 20 23            [ 2]  965 	jra	00116$
      009948                        966 00114$:
                           0002EA   967 	C$stm8s_tim2.c$764$1_0$430 ==.
                                    968 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 764: else if (TIM2_Channel == TIM2_CHANNEL_2)
      009948 7B 03            [ 1]  969 	ld	a, (0x03, sp)
      00994A 4A               [ 1]  970 	dec	a
      00994B 26 10            [ 1]  971 	jrne	00111$
                           0002EF   972 	C$stm8s_tim2.c$767$2_0$434 ==.
                                    973 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 767: if (NewState != DISABLE)
      00994D 0D 04            [ 1]  974 	tnz	(0x04, sp)
      00994F 27 06            [ 1]  975 	jreq	00105$
                           0002F3   976 	C$stm8s_tim2.c$769$3_0$435 ==.
                                    977 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 769: TIM2->CCER1 |= (uint8_t)TIM2_CCER1_CC2E;
      009951 72 18 53 08      [ 1]  978 	bset	21256, #4
      009955 20 14            [ 2]  979 	jra	00116$
      009957                        980 00105$:
                           0002F9   981 	C$stm8s_tim2.c$773$3_0$436 ==.
                                    982 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 773: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC2E);
      009957 72 19 53 08      [ 1]  983 	bres	21256, #4
      00995B 20 0E            [ 2]  984 	jra	00116$
      00995D                        985 00111$:
                           0002FF   986 	C$stm8s_tim2.c$779$2_0$437 ==.
                                    987 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 779: if (NewState != DISABLE)
      00995D 0D 04            [ 1]  988 	tnz	(0x04, sp)
      00995F 27 06            [ 1]  989 	jreq	00108$
                           000303   990 	C$stm8s_tim2.c$781$3_0$438 ==.
                                    991 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 781: TIM2->CCER2 |= (uint8_t)TIM2_CCER2_CC3E;
      009961 72 10 53 09      [ 1]  992 	bset	21257, #0
      009965 20 04            [ 2]  993 	jra	00116$
      009967                        994 00108$:
                           000309   995 	C$stm8s_tim2.c$785$3_0$439 ==.
                                    996 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 785: TIM2->CCER2 &= (uint8_t)(~TIM2_CCER2_CC3E);
      009967 72 11 53 09      [ 1]  997 	bres	21257, #0
      00996B                        998 00116$:
                           00030D   999 	C$stm8s_tim2.c$788$1_0$430 ==.
                                   1000 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 788: }
                           00030D  1001 	C$stm8s_tim2.c$788$1_0$430 ==.
                           00030D  1002 	XG$TIM2_CCxCmd$0$0 ==.
      00996B 81               [ 4] 1003 	ret
                           00030E  1004 	G$TIM2_SelectOCxM$0$0 ==.
                           00030E  1005 	C$stm8s_tim2.c$810$1_0$441 ==.
                                   1006 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 810: void TIM2_SelectOCxM(TIM2_Channel_TypeDef TIM2_Channel, TIM2_OCMode_TypeDef TIM2_OCMode)
                                   1007 ;	-----------------------------------------
                                   1008 ;	 function TIM2_SelectOCxM
                                   1009 ;	-----------------------------------------
      00996C                       1010 _TIM2_SelectOCxM:
                           00030E  1011 	C$stm8s_tim2.c$816$1_0$441 ==.
                                   1012 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 816: if (TIM2_Channel == TIM2_CHANNEL_1)
      00996C 0D 03            [ 1] 1013 	tnz	(0x03, sp)
      00996E 26 10            [ 1] 1014 	jrne	00105$
                           000312  1015 	C$stm8s_tim2.c$819$2_0$442 ==.
                                   1016 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 819: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC1E);
      009970 72 11 53 08      [ 1] 1017 	bres	21256, #0
                           000316  1018 	C$stm8s_tim2.c$822$2_0$442 ==.
                                   1019 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 822: TIM2->CCMR1 = (uint8_t)((uint8_t)(TIM2->CCMR1 & (uint8_t)(~TIM2_CCMR_OCM))
      009974 C6 53 05         [ 1] 1020 	ld	a, 0x5305
      009977 A4 8F            [ 1] 1021 	and	a, #0x8f
                           00031B  1022 	C$stm8s_tim2.c$823$2_0$442 ==.
                                   1023 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 823: | (uint8_t)TIM2_OCMode);
      009979 1A 04            [ 1] 1024 	or	a, (0x04, sp)
      00997B C7 53 05         [ 1] 1025 	ld	0x5305, a
      00997E 20 23            [ 2] 1026 	jra	00107$
      009980                       1027 00105$:
                           000322  1028 	C$stm8s_tim2.c$825$1_0$441 ==.
                                   1029 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 825: else if (TIM2_Channel == TIM2_CHANNEL_2)
      009980 7B 03            [ 1] 1030 	ld	a, (0x03, sp)
      009982 4A               [ 1] 1031 	dec	a
      009983 26 10            [ 1] 1032 	jrne	00102$
                           000327  1033 	C$stm8s_tim2.c$828$2_0$443 ==.
                                   1034 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 828: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC2E);
      009985 72 19 53 08      [ 1] 1035 	bres	21256, #4
                           00032B  1036 	C$stm8s_tim2.c$831$2_0$443 ==.
                                   1037 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 831: TIM2->CCMR2 = (uint8_t)((uint8_t)(TIM2->CCMR2 & (uint8_t)(~TIM2_CCMR_OCM))
      009989 C6 53 06         [ 1] 1038 	ld	a, 0x5306
      00998C A4 8F            [ 1] 1039 	and	a, #0x8f
                           000330  1040 	C$stm8s_tim2.c$832$2_0$443 ==.
                                   1041 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 832: | (uint8_t)TIM2_OCMode);
      00998E 1A 04            [ 1] 1042 	or	a, (0x04, sp)
      009990 C7 53 06         [ 1] 1043 	ld	0x5306, a
      009993 20 0E            [ 2] 1044 	jra	00107$
      009995                       1045 00102$:
                           000337  1046 	C$stm8s_tim2.c$837$2_0$444 ==.
                                   1047 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 837: TIM2->CCER2 &= (uint8_t)(~TIM2_CCER2_CC3E);
      009995 72 11 53 09      [ 1] 1048 	bres	21257, #0
                           00033B  1049 	C$stm8s_tim2.c$840$2_0$444 ==.
                                   1050 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 840: TIM2->CCMR3 = (uint8_t)((uint8_t)(TIM2->CCMR3 & (uint8_t)(~TIM2_CCMR_OCM))
      009999 C6 53 07         [ 1] 1051 	ld	a, 0x5307
      00999C A4 8F            [ 1] 1052 	and	a, #0x8f
                           000340  1053 	C$stm8s_tim2.c$841$2_0$444 ==.
                                   1054 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 841: | (uint8_t)TIM2_OCMode);
      00999E 1A 04            [ 1] 1055 	or	a, (0x04, sp)
      0099A0 C7 53 07         [ 1] 1056 	ld	0x5307, a
      0099A3                       1057 00107$:
                           000345  1058 	C$stm8s_tim2.c$843$1_0$441 ==.
                                   1059 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 843: }
                           000345  1060 	C$stm8s_tim2.c$843$1_0$441 ==.
                           000345  1061 	XG$TIM2_SelectOCxM$0$0 ==.
      0099A3 81               [ 4] 1062 	ret
                           000346  1063 	G$TIM2_SetCounter$0$0 ==.
                           000346  1064 	C$stm8s_tim2.c$851$1_0$446 ==.
                                   1065 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 851: void TIM2_SetCounter(uint16_t Counter)
                                   1066 ;	-----------------------------------------
                                   1067 ;	 function TIM2_SetCounter
                                   1068 ;	-----------------------------------------
      0099A4                       1069 _TIM2_SetCounter:
      0099A4 52 02            [ 2] 1070 	sub	sp, #2
                           000348  1071 	C$stm8s_tim2.c$854$1_0$446 ==.
                                   1072 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 854: TIM2->CNTRH = (uint8_t)(Counter >> 8);
      0099A6 7B 05            [ 1] 1073 	ld	a, (0x05, sp)
      0099A8 0F 01            [ 1] 1074 	clr	(0x01, sp)
      0099AA C7 53 0A         [ 1] 1075 	ld	0x530a, a
                           00034F  1076 	C$stm8s_tim2.c$855$1_0$446 ==.
                                   1077 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 855: TIM2->CNTRL = (uint8_t)(Counter);
      0099AD 7B 06            [ 1] 1078 	ld	a, (0x06, sp)
      0099AF C7 53 0B         [ 1] 1079 	ld	0x530b, a
                           000354  1080 	C$stm8s_tim2.c$856$1_0$446 ==.
                                   1081 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 856: }
      0099B2 5B 02            [ 2] 1082 	addw	sp, #2
                           000356  1083 	C$stm8s_tim2.c$856$1_0$446 ==.
                           000356  1084 	XG$TIM2_SetCounter$0$0 ==.
      0099B4 81               [ 4] 1085 	ret
                           000357  1086 	G$TIM2_SetAutoreload$0$0 ==.
                           000357  1087 	C$stm8s_tim2.c$864$1_0$448 ==.
                                   1088 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 864: void TIM2_SetAutoreload(uint16_t Autoreload)
                                   1089 ;	-----------------------------------------
                                   1090 ;	 function TIM2_SetAutoreload
                                   1091 ;	-----------------------------------------
      0099B5                       1092 _TIM2_SetAutoreload:
      0099B5 52 02            [ 2] 1093 	sub	sp, #2
                           000359  1094 	C$stm8s_tim2.c$867$1_0$448 ==.
                                   1095 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 867: TIM2->ARRH = (uint8_t)(Autoreload >> 8);
      0099B7 7B 05            [ 1] 1096 	ld	a, (0x05, sp)
      0099B9 0F 01            [ 1] 1097 	clr	(0x01, sp)
      0099BB C7 53 0D         [ 1] 1098 	ld	0x530d, a
                           000360  1099 	C$stm8s_tim2.c$868$1_0$448 ==.
                                   1100 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 868: TIM2->ARRL = (uint8_t)(Autoreload);
      0099BE 7B 06            [ 1] 1101 	ld	a, (0x06, sp)
      0099C0 C7 53 0E         [ 1] 1102 	ld	0x530e, a
                           000365  1103 	C$stm8s_tim2.c$869$1_0$448 ==.
                                   1104 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 869: }
      0099C3 5B 02            [ 2] 1105 	addw	sp, #2
                           000367  1106 	C$stm8s_tim2.c$869$1_0$448 ==.
                           000367  1107 	XG$TIM2_SetAutoreload$0$0 ==.
      0099C5 81               [ 4] 1108 	ret
                           000368  1109 	G$TIM2_SetCompare1$0$0 ==.
                           000368  1110 	C$stm8s_tim2.c$877$1_0$450 ==.
                                   1111 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 877: void TIM2_SetCompare1(uint16_t Compare1)
                                   1112 ;	-----------------------------------------
                                   1113 ;	 function TIM2_SetCompare1
                                   1114 ;	-----------------------------------------
      0099C6                       1115 _TIM2_SetCompare1:
      0099C6 52 02            [ 2] 1116 	sub	sp, #2
                           00036A  1117 	C$stm8s_tim2.c$880$1_0$450 ==.
                                   1118 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 880: TIM2->CCR1H = (uint8_t)(Compare1 >> 8);
      0099C8 7B 05            [ 1] 1119 	ld	a, (0x05, sp)
      0099CA 0F 01            [ 1] 1120 	clr	(0x01, sp)
      0099CC C7 53 0F         [ 1] 1121 	ld	0x530f, a
                           000371  1122 	C$stm8s_tim2.c$881$1_0$450 ==.
                                   1123 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 881: TIM2->CCR1L = (uint8_t)(Compare1);
      0099CF 7B 06            [ 1] 1124 	ld	a, (0x06, sp)
      0099D1 C7 53 10         [ 1] 1125 	ld	0x5310, a
                           000376  1126 	C$stm8s_tim2.c$882$1_0$450 ==.
                                   1127 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 882: }
      0099D4 5B 02            [ 2] 1128 	addw	sp, #2
                           000378  1129 	C$stm8s_tim2.c$882$1_0$450 ==.
                           000378  1130 	XG$TIM2_SetCompare1$0$0 ==.
      0099D6 81               [ 4] 1131 	ret
                           000379  1132 	G$TIM2_SetCompare2$0$0 ==.
                           000379  1133 	C$stm8s_tim2.c$890$1_0$452 ==.
                                   1134 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 890: void TIM2_SetCompare2(uint16_t Compare2)
                                   1135 ;	-----------------------------------------
                                   1136 ;	 function TIM2_SetCompare2
                                   1137 ;	-----------------------------------------
      0099D7                       1138 _TIM2_SetCompare2:
      0099D7 52 02            [ 2] 1139 	sub	sp, #2
                           00037B  1140 	C$stm8s_tim2.c$893$1_0$452 ==.
                                   1141 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 893: TIM2->CCR2H = (uint8_t)(Compare2 >> 8);
      0099D9 7B 05            [ 1] 1142 	ld	a, (0x05, sp)
      0099DB 0F 01            [ 1] 1143 	clr	(0x01, sp)
      0099DD C7 53 11         [ 1] 1144 	ld	0x5311, a
                           000382  1145 	C$stm8s_tim2.c$894$1_0$452 ==.
                                   1146 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 894: TIM2->CCR2L = (uint8_t)(Compare2);
      0099E0 7B 06            [ 1] 1147 	ld	a, (0x06, sp)
      0099E2 C7 53 12         [ 1] 1148 	ld	0x5312, a
                           000387  1149 	C$stm8s_tim2.c$895$1_0$452 ==.
                                   1150 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 895: }
      0099E5 5B 02            [ 2] 1151 	addw	sp, #2
                           000389  1152 	C$stm8s_tim2.c$895$1_0$452 ==.
                           000389  1153 	XG$TIM2_SetCompare2$0$0 ==.
      0099E7 81               [ 4] 1154 	ret
                           00038A  1155 	G$TIM2_SetCompare3$0$0 ==.
                           00038A  1156 	C$stm8s_tim2.c$903$1_0$454 ==.
                                   1157 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 903: void TIM2_SetCompare3(uint16_t Compare3)
                                   1158 ;	-----------------------------------------
                                   1159 ;	 function TIM2_SetCompare3
                                   1160 ;	-----------------------------------------
      0099E8                       1161 _TIM2_SetCompare3:
      0099E8 52 02            [ 2] 1162 	sub	sp, #2
                           00038C  1163 	C$stm8s_tim2.c$906$1_0$454 ==.
                                   1164 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 906: TIM2->CCR3H = (uint8_t)(Compare3 >> 8);
      0099EA 7B 05            [ 1] 1165 	ld	a, (0x05, sp)
      0099EC 0F 01            [ 1] 1166 	clr	(0x01, sp)
      0099EE C7 53 13         [ 1] 1167 	ld	0x5313, a
                           000393  1168 	C$stm8s_tim2.c$907$1_0$454 ==.
                                   1169 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 907: TIM2->CCR3L = (uint8_t)(Compare3);
      0099F1 7B 06            [ 1] 1170 	ld	a, (0x06, sp)
      0099F3 C7 53 14         [ 1] 1171 	ld	0x5314, a
                           000398  1172 	C$stm8s_tim2.c$908$1_0$454 ==.
                                   1173 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 908: }
      0099F6 5B 02            [ 2] 1174 	addw	sp, #2
                           00039A  1175 	C$stm8s_tim2.c$908$1_0$454 ==.
                           00039A  1176 	XG$TIM2_SetCompare3$0$0 ==.
      0099F8 81               [ 4] 1177 	ret
                           00039B  1178 	G$TIM2_SetIC1Prescaler$0$0 ==.
                           00039B  1179 	C$stm8s_tim2.c$920$1_0$456 ==.
                                   1180 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 920: void TIM2_SetIC1Prescaler(TIM2_ICPSC_TypeDef TIM2_IC1Prescaler)
                                   1181 ;	-----------------------------------------
                                   1182 ;	 function TIM2_SetIC1Prescaler
                                   1183 ;	-----------------------------------------
      0099F9                       1184 _TIM2_SetIC1Prescaler:
                           00039B  1185 	C$stm8s_tim2.c$926$1_0$456 ==.
                                   1186 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 926: TIM2->CCMR1 = (uint8_t)((uint8_t)(TIM2->CCMR1 & (uint8_t)(~TIM2_CCMR_ICxPSC))
      0099F9 C6 53 05         [ 1] 1187 	ld	a, 0x5305
      0099FC A4 F3            [ 1] 1188 	and	a, #0xf3
                           0003A0  1189 	C$stm8s_tim2.c$927$1_0$456 ==.
                                   1190 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 927: | (uint8_t)TIM2_IC1Prescaler);
      0099FE 1A 03            [ 1] 1191 	or	a, (0x03, sp)
      009A00 C7 53 05         [ 1] 1192 	ld	0x5305, a
                           0003A5  1193 	C$stm8s_tim2.c$928$1_0$456 ==.
                                   1194 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 928: }
                           0003A5  1195 	C$stm8s_tim2.c$928$1_0$456 ==.
                           0003A5  1196 	XG$TIM2_SetIC1Prescaler$0$0 ==.
      009A03 81               [ 4] 1197 	ret
                           0003A6  1198 	G$TIM2_SetIC2Prescaler$0$0 ==.
                           0003A6  1199 	C$stm8s_tim2.c$940$1_0$458 ==.
                                   1200 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 940: void TIM2_SetIC2Prescaler(TIM2_ICPSC_TypeDef TIM2_IC2Prescaler)
                                   1201 ;	-----------------------------------------
                                   1202 ;	 function TIM2_SetIC2Prescaler
                                   1203 ;	-----------------------------------------
      009A04                       1204 _TIM2_SetIC2Prescaler:
                           0003A6  1205 	C$stm8s_tim2.c$946$1_0$458 ==.
                                   1206 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 946: TIM2->CCMR2 = (uint8_t)((uint8_t)(TIM2->CCMR2 & (uint8_t)(~TIM2_CCMR_ICxPSC))
      009A04 C6 53 06         [ 1] 1207 	ld	a, 0x5306
      009A07 A4 F3            [ 1] 1208 	and	a, #0xf3
                           0003AB  1209 	C$stm8s_tim2.c$947$1_0$458 ==.
                                   1210 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 947: | (uint8_t)TIM2_IC2Prescaler);
      009A09 1A 03            [ 1] 1211 	or	a, (0x03, sp)
      009A0B C7 53 06         [ 1] 1212 	ld	0x5306, a
                           0003B0  1213 	C$stm8s_tim2.c$948$1_0$458 ==.
                                   1214 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 948: }
                           0003B0  1215 	C$stm8s_tim2.c$948$1_0$458 ==.
                           0003B0  1216 	XG$TIM2_SetIC2Prescaler$0$0 ==.
      009A0E 81               [ 4] 1217 	ret
                           0003B1  1218 	G$TIM2_SetIC3Prescaler$0$0 ==.
                           0003B1  1219 	C$stm8s_tim2.c$960$1_0$460 ==.
                                   1220 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 960: void TIM2_SetIC3Prescaler(TIM2_ICPSC_TypeDef TIM2_IC3Prescaler)
                                   1221 ;	-----------------------------------------
                                   1222 ;	 function TIM2_SetIC3Prescaler
                                   1223 ;	-----------------------------------------
      009A0F                       1224 _TIM2_SetIC3Prescaler:
                           0003B1  1225 	C$stm8s_tim2.c$966$1_0$460 ==.
                                   1226 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 966: TIM2->CCMR3 = (uint8_t)((uint8_t)(TIM2->CCMR3 & (uint8_t)(~TIM2_CCMR_ICxPSC))
      009A0F C6 53 07         [ 1] 1227 	ld	a, 0x5307
      009A12 A4 F3            [ 1] 1228 	and	a, #0xf3
                           0003B6  1229 	C$stm8s_tim2.c$967$1_0$460 ==.
                                   1230 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 967: | (uint8_t)TIM2_IC3Prescaler);
      009A14 1A 03            [ 1] 1231 	or	a, (0x03, sp)
      009A16 C7 53 07         [ 1] 1232 	ld	0x5307, a
                           0003BB  1233 	C$stm8s_tim2.c$968$1_0$460 ==.
                                   1234 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 968: }
                           0003BB  1235 	C$stm8s_tim2.c$968$1_0$460 ==.
                           0003BB  1236 	XG$TIM2_SetIC3Prescaler$0$0 ==.
      009A19 81               [ 4] 1237 	ret
                           0003BC  1238 	G$TIM2_GetCapture1$0$0 ==.
                           0003BC  1239 	C$stm8s_tim2.c$975$1_0$462 ==.
                                   1240 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 975: uint16_t TIM2_GetCapture1(void)
                                   1241 ;	-----------------------------------------
                                   1242 ;	 function TIM2_GetCapture1
                                   1243 ;	-----------------------------------------
      009A1A                       1244 _TIM2_GetCapture1:
      009A1A 52 02            [ 2] 1245 	sub	sp, #2
                           0003BE  1246 	C$stm8s_tim2.c$981$1_0$462 ==.
                                   1247 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 981: tmpccr1h = TIM2->CCR1H;
      009A1C C6 53 0F         [ 1] 1248 	ld	a, 0x530f
      009A1F 95               [ 1] 1249 	ld	xh, a
                           0003C2  1250 	C$stm8s_tim2.c$982$1_0$462 ==.
                                   1251 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 982: tmpccr1l = TIM2->CCR1L;
      009A20 C6 53 10         [ 1] 1252 	ld	a, 0x5310
                           0003C5  1253 	C$stm8s_tim2.c$984$1_0$462 ==.
                                   1254 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 984: tmpccr1 = (uint16_t)(tmpccr1l);
      009A23 97               [ 1] 1255 	ld	xl, a
      009A24 4F               [ 1] 1256 	clr	a
                           0003C7  1257 	C$stm8s_tim2.c$985$1_0$462 ==.
                                   1258 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 985: tmpccr1 |= (uint16_t)((uint16_t)tmpccr1h << 8);
      009A25 90 5F            [ 1] 1259 	clrw	y
      009A27 0F 02            [ 1] 1260 	clr	(0x02, sp)
      009A29 89               [ 2] 1261 	pushw	x
      009A2A 1A 01            [ 1] 1262 	or	a, (1, sp)
      009A2C 85               [ 2] 1263 	popw	x
      009A2D 01               [ 1] 1264 	rrwa	x
      009A2E 1A 02            [ 1] 1265 	or	a, (0x02, sp)
      009A30 97               [ 1] 1266 	ld	xl, a
                           0003D3  1267 	C$stm8s_tim2.c$987$1_0$462 ==.
                                   1268 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 987: return (uint16_t)tmpccr1;
                           0003D3  1269 	C$stm8s_tim2.c$988$1_0$462 ==.
                                   1270 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 988: }
      009A31 5B 02            [ 2] 1271 	addw	sp, #2
                           0003D5  1272 	C$stm8s_tim2.c$988$1_0$462 ==.
                           0003D5  1273 	XG$TIM2_GetCapture1$0$0 ==.
      009A33 81               [ 4] 1274 	ret
                           0003D6  1275 	G$TIM2_GetCapture2$0$0 ==.
                           0003D6  1276 	C$stm8s_tim2.c$995$1_0$464 ==.
                                   1277 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 995: uint16_t TIM2_GetCapture2(void)
                                   1278 ;	-----------------------------------------
                                   1279 ;	 function TIM2_GetCapture2
                                   1280 ;	-----------------------------------------
      009A34                       1281 _TIM2_GetCapture2:
      009A34 52 02            [ 2] 1282 	sub	sp, #2
                           0003D8  1283 	C$stm8s_tim2.c$1001$1_0$464 ==.
                                   1284 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1001: tmpccr2h = TIM2->CCR2H;
      009A36 C6 53 11         [ 1] 1285 	ld	a, 0x5311
      009A39 95               [ 1] 1286 	ld	xh, a
                           0003DC  1287 	C$stm8s_tim2.c$1002$1_0$464 ==.
                                   1288 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1002: tmpccr2l = TIM2->CCR2L;
      009A3A C6 53 12         [ 1] 1289 	ld	a, 0x5312
                           0003DF  1290 	C$stm8s_tim2.c$1004$1_0$464 ==.
                                   1291 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1004: tmpccr2 = (uint16_t)(tmpccr2l);
      009A3D 97               [ 1] 1292 	ld	xl, a
      009A3E 4F               [ 1] 1293 	clr	a
                           0003E1  1294 	C$stm8s_tim2.c$1005$1_0$464 ==.
                                   1295 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1005: tmpccr2 |= (uint16_t)((uint16_t)tmpccr2h << 8);
      009A3F 90 5F            [ 1] 1296 	clrw	y
      009A41 0F 02            [ 1] 1297 	clr	(0x02, sp)
      009A43 89               [ 2] 1298 	pushw	x
      009A44 1A 01            [ 1] 1299 	or	a, (1, sp)
      009A46 85               [ 2] 1300 	popw	x
      009A47 01               [ 1] 1301 	rrwa	x
      009A48 1A 02            [ 1] 1302 	or	a, (0x02, sp)
      009A4A 97               [ 1] 1303 	ld	xl, a
                           0003ED  1304 	C$stm8s_tim2.c$1007$1_0$464 ==.
                                   1305 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1007: return (uint16_t)tmpccr2;
                           0003ED  1306 	C$stm8s_tim2.c$1008$1_0$464 ==.
                                   1307 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1008: }
      009A4B 5B 02            [ 2] 1308 	addw	sp, #2
                           0003EF  1309 	C$stm8s_tim2.c$1008$1_0$464 ==.
                           0003EF  1310 	XG$TIM2_GetCapture2$0$0 ==.
      009A4D 81               [ 4] 1311 	ret
                           0003F0  1312 	G$TIM2_GetCapture3$0$0 ==.
                           0003F0  1313 	C$stm8s_tim2.c$1015$1_0$466 ==.
                                   1314 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1015: uint16_t TIM2_GetCapture3(void)
                                   1315 ;	-----------------------------------------
                                   1316 ;	 function TIM2_GetCapture3
                                   1317 ;	-----------------------------------------
      009A4E                       1318 _TIM2_GetCapture3:
      009A4E 52 02            [ 2] 1319 	sub	sp, #2
                           0003F2  1320 	C$stm8s_tim2.c$1021$1_0$466 ==.
                                   1321 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1021: tmpccr3h = TIM2->CCR3H;
      009A50 C6 53 13         [ 1] 1322 	ld	a, 0x5313
      009A53 95               [ 1] 1323 	ld	xh, a
                           0003F6  1324 	C$stm8s_tim2.c$1022$1_0$466 ==.
                                   1325 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1022: tmpccr3l = TIM2->CCR3L;
      009A54 C6 53 14         [ 1] 1326 	ld	a, 0x5314
                           0003F9  1327 	C$stm8s_tim2.c$1024$1_0$466 ==.
                                   1328 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1024: tmpccr3 = (uint16_t)(tmpccr3l);
      009A57 97               [ 1] 1329 	ld	xl, a
      009A58 4F               [ 1] 1330 	clr	a
                           0003FB  1331 	C$stm8s_tim2.c$1025$1_0$466 ==.
                                   1332 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1025: tmpccr3 |= (uint16_t)((uint16_t)tmpccr3h << 8);
      009A59 90 5F            [ 1] 1333 	clrw	y
      009A5B 0F 02            [ 1] 1334 	clr	(0x02, sp)
      009A5D 89               [ 2] 1335 	pushw	x
      009A5E 1A 01            [ 1] 1336 	or	a, (1, sp)
      009A60 85               [ 2] 1337 	popw	x
      009A61 01               [ 1] 1338 	rrwa	x
      009A62 1A 02            [ 1] 1339 	or	a, (0x02, sp)
      009A64 97               [ 1] 1340 	ld	xl, a
                           000407  1341 	C$stm8s_tim2.c$1027$1_0$466 ==.
                                   1342 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1027: return (uint16_t)tmpccr3;
                           000407  1343 	C$stm8s_tim2.c$1028$1_0$466 ==.
                                   1344 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1028: }
      009A65 5B 02            [ 2] 1345 	addw	sp, #2
                           000409  1346 	C$stm8s_tim2.c$1028$1_0$466 ==.
                           000409  1347 	XG$TIM2_GetCapture3$0$0 ==.
      009A67 81               [ 4] 1348 	ret
                           00040A  1349 	G$TIM2_GetCounter$0$0 ==.
                           00040A  1350 	C$stm8s_tim2.c$1035$1_0$468 ==.
                                   1351 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1035: uint16_t TIM2_GetCounter(void)
                                   1352 ;	-----------------------------------------
                                   1353 ;	 function TIM2_GetCounter
                                   1354 ;	-----------------------------------------
      009A68                       1355 _TIM2_GetCounter:
      009A68 52 04            [ 2] 1356 	sub	sp, #4
                           00040C  1357 	C$stm8s_tim2.c$1039$1_0$468 ==.
                                   1358 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1039: tmpcntr =  ((uint16_t)TIM2->CNTRH << 8);
      009A6A C6 53 0A         [ 1] 1359 	ld	a, 0x530a
      009A6D 95               [ 1] 1360 	ld	xh, a
      009A6E 4F               [ 1] 1361 	clr	a
      009A6F 6B 04            [ 1] 1362 	ld	(0x04, sp), a
                           000413  1363 	C$stm8s_tim2.c$1041$1_0$468 ==.
                                   1364 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1041: return (uint16_t)( tmpcntr| (uint16_t)(TIM2->CNTRL));
      009A71 C6 53 0B         [ 1] 1365 	ld	a, 0x530b
      009A74 0F 01            [ 1] 1366 	clr	(0x01, sp)
      009A76 1A 04            [ 1] 1367 	or	a, (0x04, sp)
      009A78 02               [ 1] 1368 	rlwa	x
      009A79 1A 01            [ 1] 1369 	or	a, (0x01, sp)
      009A7B 95               [ 1] 1370 	ld	xh, a
                           00041E  1371 	C$stm8s_tim2.c$1042$1_0$468 ==.
                                   1372 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1042: }
      009A7C 5B 04            [ 2] 1373 	addw	sp, #4
                           000420  1374 	C$stm8s_tim2.c$1042$1_0$468 ==.
                           000420  1375 	XG$TIM2_GetCounter$0$0 ==.
      009A7E 81               [ 4] 1376 	ret
                           000421  1377 	G$TIM2_GetPrescaler$0$0 ==.
                           000421  1378 	C$stm8s_tim2.c$1049$1_0$470 ==.
                                   1379 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1049: TIM2_Prescaler_TypeDef TIM2_GetPrescaler(void)
                                   1380 ;	-----------------------------------------
                                   1381 ;	 function TIM2_GetPrescaler
                                   1382 ;	-----------------------------------------
      009A7F                       1383 _TIM2_GetPrescaler:
                           000421  1384 	C$stm8s_tim2.c$1052$1_0$470 ==.
                                   1385 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1052: return (TIM2_Prescaler_TypeDef)(TIM2->PSCR);
      009A7F C6 53 0C         [ 1] 1386 	ld	a, 0x530c
                           000424  1387 	C$stm8s_tim2.c$1053$1_0$470 ==.
                                   1388 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1053: }
                           000424  1389 	C$stm8s_tim2.c$1053$1_0$470 ==.
                           000424  1390 	XG$TIM2_GetPrescaler$0$0 ==.
      009A82 81               [ 4] 1391 	ret
                           000425  1392 	G$TIM2_GetFlagStatus$0$0 ==.
                           000425  1393 	C$stm8s_tim2.c$1068$1_0$472 ==.
                                   1394 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1068: FlagStatus TIM2_GetFlagStatus(TIM2_FLAG_TypeDef TIM2_FLAG)
                                   1395 ;	-----------------------------------------
                                   1396 ;	 function TIM2_GetFlagStatus
                                   1397 ;	-----------------------------------------
      009A83                       1398 _TIM2_GetFlagStatus:
      009A83 52 05            [ 2] 1399 	sub	sp, #5
                           000427  1400 	C$stm8s_tim2.c$1076$1_0$472 ==.
                                   1401 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1076: tim2_flag_l = (uint8_t)(TIM2->SR1 & (uint8_t)TIM2_FLAG);
      009A85 C6 53 02         [ 1] 1402 	ld	a, 0x5302
      009A88 6B 03            [ 1] 1403 	ld	(0x03, sp), a
      009A8A 7B 09            [ 1] 1404 	ld	a, (0x09, sp)
      009A8C 14 03            [ 1] 1405 	and	a, (0x03, sp)
      009A8E 6B 04            [ 1] 1406 	ld	(0x04, sp), a
                           000432  1407 	C$stm8s_tim2.c$1077$1_0$472 ==.
                                   1408 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1077: tim2_flag_h = (uint8_t)((uint16_t)TIM2_FLAG >> 8);
      009A90 7B 08            [ 1] 1409 	ld	a, (0x08, sp)
      009A92 0F 01            [ 1] 1410 	clr	(0x01, sp)
      009A94 6B 05            [ 1] 1411 	ld	(0x05, sp), a
                           000438  1412 	C$stm8s_tim2.c$1079$1_0$472 ==.
                                   1413 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1079: if ((tim2_flag_l | (uint8_t)(TIM2->SR2 & tim2_flag_h)) != (uint8_t)RESET )
      009A96 C6 53 03         [ 1] 1414 	ld	a, 0x5303
      009A99 14 05            [ 1] 1415 	and	a, (0x05, sp)
      009A9B 1A 04            [ 1] 1416 	or	a, (0x04, sp)
      009A9D 27 04            [ 1] 1417 	jreq	00102$
                           000441  1418 	C$stm8s_tim2.c$1081$2_0$473 ==.
                                   1419 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1081: bitstatus = SET;
      009A9F A6 01            [ 1] 1420 	ld	a, #0x01
      009AA1 20 01            [ 2] 1421 	jra	00103$
      009AA3                       1422 00102$:
                           000445  1423 	C$stm8s_tim2.c$1085$2_0$474 ==.
                                   1424 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1085: bitstatus = RESET;
      009AA3 4F               [ 1] 1425 	clr	a
      009AA4                       1426 00103$:
                           000446  1427 	C$stm8s_tim2.c$1087$1_0$472 ==.
                                   1428 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1087: return (FlagStatus)bitstatus;
                           000446  1429 	C$stm8s_tim2.c$1088$1_0$472 ==.
                                   1430 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1088: }
      009AA4 5B 05            [ 2] 1431 	addw	sp, #5
                           000448  1432 	C$stm8s_tim2.c$1088$1_0$472 ==.
                           000448  1433 	XG$TIM2_GetFlagStatus$0$0 ==.
      009AA6 81               [ 4] 1434 	ret
                           000449  1435 	G$TIM2_ClearFlag$0$0 ==.
                           000449  1436 	C$stm8s_tim2.c$1103$1_0$476 ==.
                                   1437 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1103: void TIM2_ClearFlag(TIM2_FLAG_TypeDef TIM2_FLAG)
                                   1438 ;	-----------------------------------------
                                   1439 ;	 function TIM2_ClearFlag
                                   1440 ;	-----------------------------------------
      009AA7                       1441 _TIM2_ClearFlag:
                           000449  1442 	C$stm8s_tim2.c$1109$1_0$476 ==.
                                   1443 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1109: TIM2->SR1 = (uint8_t)(~((uint8_t)(TIM2_FLAG)));
      009AA7 7B 04            [ 1] 1444 	ld	a, (0x04, sp)
      009AA9 43               [ 1] 1445 	cpl	a
      009AAA C7 53 02         [ 1] 1446 	ld	0x5302, a
                           00044F  1447 	C$stm8s_tim2.c$1111$1_0$476 ==.
                                   1448 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1111: TIM2->SR2 = (uint8_t)(~((uint8_t)(TIM2_FLAG >> 8))); // [Roshan, 2015-Nov-09]
      009AAD 7B 03            [ 1] 1449 	ld	a, (0x03, sp)
      009AAF 43               [ 1] 1450 	cpl	a
      009AB0 C7 53 03         [ 1] 1451 	ld	0x5303, a
                           000455  1452 	C$stm8s_tim2.c$1112$1_0$476 ==.
                                   1453 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1112: }
                           000455  1454 	C$stm8s_tim2.c$1112$1_0$476 ==.
                           000455  1455 	XG$TIM2_ClearFlag$0$0 ==.
      009AB3 81               [ 4] 1456 	ret
                           000456  1457 	G$TIM2_GetITStatus$0$0 ==.
                           000456  1458 	C$stm8s_tim2.c$1124$1_0$478 ==.
                                   1459 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1124: ITStatus TIM2_GetITStatus(TIM2_IT_TypeDef TIM2_IT)
                                   1460 ;	-----------------------------------------
                                   1461 ;	 function TIM2_GetITStatus
                                   1462 ;	-----------------------------------------
      009AB4                       1463 _TIM2_GetITStatus:
      009AB4 88               [ 1] 1464 	push	a
                           000457  1465 	C$stm8s_tim2.c$1132$1_0$478 ==.
                                   1466 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1132: TIM2_itStatus = (uint8_t)(TIM2->SR1 & TIM2_IT);
      009AB5 C6 53 02         [ 1] 1467 	ld	a, 0x5302
      009AB8 14 04            [ 1] 1468 	and	a, (0x04, sp)
      009ABA 6B 01            [ 1] 1469 	ld	(0x01, sp), a
                           00045E  1470 	C$stm8s_tim2.c$1134$1_0$478 ==.
                                   1471 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1134: TIM2_itEnable = (uint8_t)(TIM2->IER & TIM2_IT);
      009ABC C6 53 01         [ 1] 1472 	ld	a, 0x5301
      009ABF 14 04            [ 1] 1473 	and	a, (0x04, sp)
                           000463  1474 	C$stm8s_tim2.c$1136$1_0$478 ==.
                                   1475 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1136: if ((TIM2_itStatus != (uint8_t)RESET ) && (TIM2_itEnable != (uint8_t)RESET ))
      009AC1 0D 01            [ 1] 1476 	tnz	(0x01, sp)
      009AC3 27 07            [ 1] 1477 	jreq	00102$
      009AC5 4D               [ 1] 1478 	tnz	a
      009AC6 27 04            [ 1] 1479 	jreq	00102$
                           00046A  1480 	C$stm8s_tim2.c$1138$2_0$479 ==.
                                   1481 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1138: bitstatus = SET;
      009AC8 A6 01            [ 1] 1482 	ld	a, #0x01
      009ACA 20 01            [ 2] 1483 	jra	00103$
      009ACC                       1484 00102$:
                           00046E  1485 	C$stm8s_tim2.c$1142$2_0$480 ==.
                                   1486 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1142: bitstatus = RESET;
      009ACC 4F               [ 1] 1487 	clr	a
      009ACD                       1488 00103$:
                           00046F  1489 	C$stm8s_tim2.c$1144$1_0$478 ==.
                                   1490 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1144: return (ITStatus)(bitstatus);
                           00046F  1491 	C$stm8s_tim2.c$1145$1_0$478 ==.
                                   1492 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1145: }
      009ACD 5B 01            [ 2] 1493 	addw	sp, #1
                           000471  1494 	C$stm8s_tim2.c$1145$1_0$478 ==.
                           000471  1495 	XG$TIM2_GetITStatus$0$0 ==.
      009ACF 81               [ 4] 1496 	ret
                           000472  1497 	G$TIM2_ClearITPendingBit$0$0 ==.
                           000472  1498 	C$stm8s_tim2.c$1157$1_0$482 ==.
                                   1499 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1157: void TIM2_ClearITPendingBit(TIM2_IT_TypeDef TIM2_IT)
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function TIM2_ClearITPendingBit
                                   1502 ;	-----------------------------------------
      009AD0                       1503 _TIM2_ClearITPendingBit:
                           000472  1504 	C$stm8s_tim2.c$1163$1_0$482 ==.
                                   1505 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1163: TIM2->SR1 = (uint8_t)(~TIM2_IT);
      009AD0 7B 03            [ 1] 1506 	ld	a, (0x03, sp)
      009AD2 43               [ 1] 1507 	cpl	a
      009AD3 C7 53 02         [ 1] 1508 	ld	0x5302, a
                           000478  1509 	C$stm8s_tim2.c$1164$1_0$482 ==.
                                   1510 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1164: }
                           000478  1511 	C$stm8s_tim2.c$1164$1_0$482 ==.
                           000478  1512 	XG$TIM2_ClearITPendingBit$0$0 ==.
      009AD6 81               [ 4] 1513 	ret
                           000479  1514 	Fstm8s_tim2$TI1_Config$0$0 ==.
                           000479  1515 	C$stm8s_tim2.c$1182$1_0$484 ==.
                                   1516 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1182: static void TI1_Config(uint8_t TIM2_ICPolarity,
                                   1517 ;	-----------------------------------------
                                   1518 ;	 function TI1_Config
                                   1519 ;	-----------------------------------------
      009AD7                       1520 _TI1_Config:
      009AD7 88               [ 1] 1521 	push	a
                           00047A  1522 	C$stm8s_tim2.c$1187$1_0$484 ==.
                                   1523 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1187: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC1E);
      009AD8 72 11 53 08      [ 1] 1524 	bres	21256, #0
                           00047E  1525 	C$stm8s_tim2.c$1190$1_0$484 ==.
                                   1526 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1190: TIM2->CCMR1  = (uint8_t)((uint8_t)(TIM2->CCMR1 & (uint8_t)(~(uint8_t)( TIM2_CCMR_CCxS | TIM2_CCMR_ICxF )))
      009ADC C6 53 05         [ 1] 1527 	ld	a, 0x5305
      009ADF A4 0C            [ 1] 1528 	and	a, #0x0c
      009AE1 6B 01            [ 1] 1529 	ld	(0x01, sp), a
                           000485  1530 	C$stm8s_tim2.c$1191$1_0$484 ==.
                                   1531 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1191: | (uint8_t)(((TIM2_ICSelection)) | ((uint8_t)( TIM2_ICFilter << 4))));
      009AE3 7B 06            [ 1] 1532 	ld	a, (0x06, sp)
      009AE5 4E               [ 1] 1533 	swap	a
      009AE6 A4 F0            [ 1] 1534 	and	a, #0xf0
      009AE8 1A 05            [ 1] 1535 	or	a, (0x05, sp)
      009AEA 1A 01            [ 1] 1536 	or	a, (0x01, sp)
      009AEC C7 53 05         [ 1] 1537 	ld	0x5305, a
                           000491  1538 	C$stm8s_tim2.c$1194$1_0$484 ==.
                                   1539 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1194: if (TIM2_ICPolarity != TIM2_ICPOLARITY_RISING)
      009AEF 0D 04            [ 1] 1540 	tnz	(0x04, sp)
      009AF1 27 06            [ 1] 1541 	jreq	00102$
                           000495  1542 	C$stm8s_tim2.c$1196$2_0$485 ==.
                                   1543 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1196: TIM2->CCER1 |= TIM2_CCER1_CC1P;
      009AF3 72 12 53 08      [ 1] 1544 	bset	21256, #1
      009AF7 20 04            [ 2] 1545 	jra	00103$
      009AF9                       1546 00102$:
                           00049B  1547 	C$stm8s_tim2.c$1200$2_0$486 ==.
                                   1548 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1200: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC1P);
      009AF9 72 13 53 08      [ 1] 1549 	bres	21256, #1
      009AFD                       1550 00103$:
                           00049F  1551 	C$stm8s_tim2.c$1203$1_0$484 ==.
                                   1552 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1203: TIM2->CCER1 |= TIM2_CCER1_CC1E;
      009AFD 72 10 53 08      [ 1] 1553 	bset	21256, #0
                           0004A3  1554 	C$stm8s_tim2.c$1204$1_0$484 ==.
                                   1555 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1204: }
      009B01 84               [ 1] 1556 	pop	a
                           0004A4  1557 	C$stm8s_tim2.c$1204$1_0$484 ==.
                           0004A4  1558 	XFstm8s_tim2$TI1_Config$0$0 ==.
      009B02 81               [ 4] 1559 	ret
                           0004A5  1560 	Fstm8s_tim2$TI2_Config$0$0 ==.
                           0004A5  1561 	C$stm8s_tim2.c$1222$1_0$488 ==.
                                   1562 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1222: static void TI2_Config(uint8_t TIM2_ICPolarity,
                                   1563 ;	-----------------------------------------
                                   1564 ;	 function TI2_Config
                                   1565 ;	-----------------------------------------
      009B03                       1566 _TI2_Config:
      009B03 88               [ 1] 1567 	push	a
                           0004A6  1568 	C$stm8s_tim2.c$1227$1_0$488 ==.
                                   1569 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1227: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC2E);
      009B04 72 19 53 08      [ 1] 1570 	bres	21256, #4
                           0004AA  1571 	C$stm8s_tim2.c$1230$1_0$488 ==.
                                   1572 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1230: TIM2->CCMR2 = (uint8_t)((uint8_t)(TIM2->CCMR2 & (uint8_t)(~(uint8_t)( TIM2_CCMR_CCxS | TIM2_CCMR_ICxF )))
      009B08 C6 53 06         [ 1] 1573 	ld	a, 0x5306
      009B0B A4 0C            [ 1] 1574 	and	a, #0x0c
      009B0D 6B 01            [ 1] 1575 	ld	(0x01, sp), a
                           0004B1  1576 	C$stm8s_tim2.c$1231$1_0$488 ==.
                                   1577 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1231: | (uint8_t)(( (TIM2_ICSelection)) | ((uint8_t)( TIM2_ICFilter << 4))));
      009B0F 7B 06            [ 1] 1578 	ld	a, (0x06, sp)
      009B11 4E               [ 1] 1579 	swap	a
      009B12 A4 F0            [ 1] 1580 	and	a, #0xf0
      009B14 1A 05            [ 1] 1581 	or	a, (0x05, sp)
      009B16 1A 01            [ 1] 1582 	or	a, (0x01, sp)
      009B18 C7 53 06         [ 1] 1583 	ld	0x5306, a
                           0004BD  1584 	C$stm8s_tim2.c$1235$1_0$488 ==.
                                   1585 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1235: if (TIM2_ICPolarity != TIM2_ICPOLARITY_RISING)
      009B1B 0D 04            [ 1] 1586 	tnz	(0x04, sp)
      009B1D 27 06            [ 1] 1587 	jreq	00102$
                           0004C1  1588 	C$stm8s_tim2.c$1237$2_0$489 ==.
                                   1589 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1237: TIM2->CCER1 |= TIM2_CCER1_CC2P;
      009B1F 72 1A 53 08      [ 1] 1590 	bset	21256, #5
      009B23 20 04            [ 2] 1591 	jra	00103$
      009B25                       1592 00102$:
                           0004C7  1593 	C$stm8s_tim2.c$1241$2_0$490 ==.
                                   1594 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1241: TIM2->CCER1 &= (uint8_t)(~TIM2_CCER1_CC2P);
      009B25 72 1B 53 08      [ 1] 1595 	bres	21256, #5
      009B29                       1596 00103$:
                           0004CB  1597 	C$stm8s_tim2.c$1245$1_0$488 ==.
                                   1598 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1245: TIM2->CCER1 |= TIM2_CCER1_CC2E;
      009B29 72 18 53 08      [ 1] 1599 	bset	21256, #4
                           0004CF  1600 	C$stm8s_tim2.c$1246$1_0$488 ==.
                                   1601 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1246: }
      009B2D 84               [ 1] 1602 	pop	a
                           0004D0  1603 	C$stm8s_tim2.c$1246$1_0$488 ==.
                           0004D0  1604 	XFstm8s_tim2$TI2_Config$0$0 ==.
      009B2E 81               [ 4] 1605 	ret
                           0004D1  1606 	Fstm8s_tim2$TI3_Config$0$0 ==.
                           0004D1  1607 	C$stm8s_tim2.c$1262$1_0$492 ==.
                                   1608 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1262: static void TI3_Config(uint8_t TIM2_ICPolarity, uint8_t TIM2_ICSelection,
                                   1609 ;	-----------------------------------------
                                   1610 ;	 function TI3_Config
                                   1611 ;	-----------------------------------------
      009B2F                       1612 _TI3_Config:
      009B2F 88               [ 1] 1613 	push	a
                           0004D2  1614 	C$stm8s_tim2.c$1266$1_0$492 ==.
                                   1615 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1266: TIM2->CCER2 &=  (uint8_t)(~TIM2_CCER2_CC3E);
      009B30 72 11 53 09      [ 1] 1616 	bres	21257, #0
                           0004D6  1617 	C$stm8s_tim2.c$1269$1_0$492 ==.
                                   1618 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1269: TIM2->CCMR3 = (uint8_t)((uint8_t)(TIM2->CCMR3 & (uint8_t)(~( TIM2_CCMR_CCxS | TIM2_CCMR_ICxF)))
      009B34 C6 53 07         [ 1] 1619 	ld	a, 0x5307
      009B37 A4 0C            [ 1] 1620 	and	a, #0x0c
      009B39 6B 01            [ 1] 1621 	ld	(0x01, sp), a
                           0004DD  1622 	C$stm8s_tim2.c$1270$1_0$492 ==.
                                   1623 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1270: | (uint8_t)(( (TIM2_ICSelection)) | ((uint8_t)( TIM2_ICFilter << 4))));
      009B3B 7B 06            [ 1] 1624 	ld	a, (0x06, sp)
      009B3D 4E               [ 1] 1625 	swap	a
      009B3E A4 F0            [ 1] 1626 	and	a, #0xf0
      009B40 1A 05            [ 1] 1627 	or	a, (0x05, sp)
      009B42 1A 01            [ 1] 1628 	or	a, (0x01, sp)
      009B44 C7 53 07         [ 1] 1629 	ld	0x5307, a
                           0004E9  1630 	C$stm8s_tim2.c$1274$1_0$492 ==.
                                   1631 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1274: if (TIM2_ICPolarity != TIM2_ICPOLARITY_RISING)
      009B47 0D 04            [ 1] 1632 	tnz	(0x04, sp)
      009B49 27 06            [ 1] 1633 	jreq	00102$
                           0004ED  1634 	C$stm8s_tim2.c$1276$2_0$493 ==.
                                   1635 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1276: TIM2->CCER2 |= TIM2_CCER2_CC3P;
      009B4B 72 12 53 09      [ 1] 1636 	bset	21257, #1
      009B4F 20 04            [ 2] 1637 	jra	00103$
      009B51                       1638 00102$:
                           0004F3  1639 	C$stm8s_tim2.c$1280$2_0$494 ==.
                                   1640 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1280: TIM2->CCER2 &= (uint8_t)(~TIM2_CCER2_CC3P);
      009B51 72 13 53 09      [ 1] 1641 	bres	21257, #1
      009B55                       1642 00103$:
                           0004F7  1643 	C$stm8s_tim2.c$1283$1_0$492 ==.
                                   1644 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1283: TIM2->CCER2 |= TIM2_CCER2_CC3E;
      009B55 72 10 53 09      [ 1] 1645 	bset	21257, #0
                           0004FB  1646 	C$stm8s_tim2.c$1284$1_0$492 ==.
                                   1647 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_tim2.c: 1284: }
      009B59 84               [ 1] 1648 	pop	a
                           0004FC  1649 	C$stm8s_tim2.c$1284$1_0$492 ==.
                           0004FC  1650 	XFstm8s_tim2$TI3_Config$0$0 ==.
      009B5A 81               [ 4] 1651 	ret
                                   1652 	.area CODE
                                   1653 	.area CONST
                                   1654 	.area INITIALIZER
                                   1655 	.area CABS (ABS)
