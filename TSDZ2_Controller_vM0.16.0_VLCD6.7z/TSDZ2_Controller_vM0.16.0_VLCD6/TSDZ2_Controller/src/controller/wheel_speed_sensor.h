/*
 * TongSheng TSDZ2 motor controller firmware/
 *
 * Copyright (C) Casainho, 2018.
 *
 * Released under the GPL License, Version 3
 */

#ifndef _WHELL_SPEED_SENSOR_H_
#define _WHELL_SPEED_SENSOR_H_

#include "main.h"

void wheel_speed_sensor_init (void);

#endif /* _WHELL_SPEED_SENSOR_H_ */
