/*
 * TongSheng TSDZ2 motor controller firmware/
 *
 * Copyright (C) Casainho, 2018.
 *
 * Released under the GPL License, Version 3
 */

#ifndef _MAIN_H_
#define _MAIN_H_

#include "config.h"

#define ENABLE_VLCD6_COMPATIBILITY				1
#define ENABLE_BRAKE_SENSOR								0
#define ENABLE_THROTTLE										0
#define ENABLE_DEBUG_UART									0
#define ENABLE_DEBUG_FIRMWARE							0

#if ENABLE_VLCD6_COMPATIBILITY
//------------------------------------------
#define ENABLE_POWER_BOOST_FROM_VLCD6			0
#define ENABLE_OFFROAD_FROM_VLCD6					0
#define ENABLE_LIGHTS_FROM_VLCD6					1
//------------------------------------------
#define ENABLE_WALK_ASSIST_FROM_VLCD6			1
//------------------------------------------
#define ENABLE_WHEEL_PERIMETER_FROM_VLCD6	1
//------------------------------------------
#define ENABLE_WHEEL_MAX_SPEED_FROM_VLCD6	1
//------------------------------------------
#define ENABLE_BATTERY_SOC_6_LEVELS				1
//------------------------------------------
#define ENABLE_VLCD6_ALWAYS_ON						0
#if !ENABLE_VLCD6_ALWAYS_ON
#define ENABLE_MOTOR_WORKING_FLAG					1
#define ENABLE_WHEEL_TURNING_FLAG					1
#endif
//------------------------------------------
#define NO_FAULT													0
#define TEMPERATURE_PROTECTION						1
#define SHORT_CIRCUIT_PROTECTION					2
#define TURN_FAULT												3
#define MOTOR_PHASE_LOSS									4
#define TORQUE_FAULT											5
#define JAM_FAULT													6
#define EBIKE_WHEEL_BLOCKED								7
#define OVERVOLTAGE												8
//------------------------------------------
#endif

// Considering the follow voltage values for each li-ion battery cell
// State of charge 		| voltage
#if ENABLE_BATTERY_SOC_6_LEVELS
#if 1
// From Discharge graph of Samsung INR18650-25R cells
#define LI_ION_CELL_VOLTS_100   4.25
#define LI_ION_CELL_VOLTS_83    3.96
#define LI_ION_CELL_VOLTS_50    3.70
#define LI_ION_CELL_VOLTS_17    3.44
#define LI_ION_CELL_VOLTS_10    3.30
#define LI_ION_CELL_VOLTS_0     3.00
#else
#define LI_ION_CELL_VOLTS_100   4.06
#define LI_ION_CELL_VOLTS_80    3.93
#define LI_ION_CELL_VOLTS_60    3.78
#define LI_ION_CELL_VOLTS_40    3.60
#define LI_ION_CELL_VOLTS_20    3.38
#define LI_ION_CELL_VOLTS_10    3.25
#define LI_ION_CELL_VOLTS_0     3.00
#endif
#else
// This values were taken from a discharge graph of Samsung INR18650-25R cells, at almost no current discharge
// This graph: https://endless-sphere.com/forums/download/file.php?id=183920&sid=b7fd7180ef87351cabe74a22f1d162d7
#define LI_ION_CELL_VOLTS_83    3.96
#define LI_ION_CELL_VOLTS_50    3.70
#define LI_ION_CELL_VOLTS_17    3.44
#define LI_ION_CELL_VOLTS_0     3.30
#endif

#define PWM_CYCLES_COUNTER_MAX 3125 // 5 erps minimum speed; 1/5 = 200ms; 200ms/64us = 3125

#define PWM_CYCLES_SECOND 15625L // 1 / 64us(PWM period)

#define PWM_DUTY_CYCLE_MAX 254
#define PWM_DUTY_CYCLE_MIN 20
#define MIDDLE_PWM_DUTY_CYCLE_MAX (PWM_DUTY_CYCLE_MAX/2)

#define MOTOR_ROTOR_ANGLE_90    (63  + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_150   (106 + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_210   (148 + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_270   (191 + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_330   (233 + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_30    (20  + MOTOR_ROTOR_OFFSET_ANGLE)

#define MOTOR_OVER_SPEED_ERPS               520 // motor max speed, protection max value | 30 points for the sinewave at max speed
#define MOTOR_OVER_SPEED_ERPS_EXPERIMENTAL  700 // experimental max motor speed to allow a higher cadence

#define WHEEL_SPEED_PI_CONTROLLER_KP_DIVIDEND	100
#define WHEEL_SPEED_PI_CONTROLLER_KP_DIVISOR	4
#define WHEEL_SPEED_PI_CONTROLLER_KI_DIVIDEND	40
#define WHEEL_SPEED_PI_CONTROLLER_KI_DIVISOR	6

// Possible values: 0, 1, 2, 3, 4, 5, 6
// 0 equal to no filtering and no delay, higher values will increase filtering but will also add bigger delay
#define THROTTLE_FILTER_COEFFICIENT     1
#define ADC_THROTTLE_THRESHOLD          10 // value in ADC 8 bits step
#define ADC_TORQUE_SENSOR_THRESHOLD     6 // value in ADC 8 bits step

#define CRUISE_CONTROL_MIN	20

// Max voltage value for throttle, in ADC 8 bits step
// each ADC 8 bits step = (5V / 256) = 0.0195
#define ADC_THROTTLE_MIN_VALUE	47
#define ADC_THROTTLE_MAX_VALUE	176

// Configure walk assist as throttle with fix value
#if ENABLE_VLCD6_COMPATIBILITY
#define WALK_ASSIST_MIN_VALUE		0
#define WALK_ASSIST_MAX_VALUE		100
#endif

// *************************************************************************** //
// Torque sensor
// Torque (force) value found experimentaly
// measuring with a cheap digital hook scale, we found that each torque sensor unit is equal to 0.52 Nm
// using the scale, was found that each 0.33kg was measured as 1 torque sensor units
// Force (Nm) = 1Kg * 9.18 * 0.17 (arm cranks size)
#define PEDAL_TORQUE_X100 52
// *************************************************************************** //

// *************************************************************************** //
// PAS
#define PAS_NUMBER_MAGNETS 20 // PAS_NUMBER_MAGNETS = 20 was validated on August 2018 by Casainho e jbalat

// x = (1/(150RPM/60)) / (0.000064)
// PAS_ABSOLUTE_MAX_CADENCE_PWM_CYCLE_TICKS = (x / PAS_NUMBER_MAGNETS)
#define PAS_ABSOLUTE_MAX_CADENCE_PWM_CYCLE_TICKS  (6250 / PAS_NUMBER_MAGNETS) // max hard limit to 150RPM PAS cadence
#define PAS_ABSOLUTE_MIN_CADENCE_PWM_CYCLE_TICKS  (93750 / PAS_NUMBER_MAGNETS) // min hard limit to 10RPM PAS cadence
#define PAS_NUMBER_MAGNETS_X2 (PAS_NUMBER_MAGNETS * 2)
// *************************************************************************** //

// *************************************************************************** //
// Wheel speed sensor
#define WHEEL_SPEED_SENSOR_MAX_PWM_CYCLE_TICKS  135 // something like 200km/h with a 6'' wheel
#define WHEEL_SPEED_SENSOR_MIN_PWM_CYCLE_TICKS  32767 // could be a bigger number but will make slow detecting wheel stopped
// *************************************************************************** //

// *************************************************************************** //
// EEPROM memory variables default values
#define DEFAULT_VALUE_ASSIST_LEVEL_FACTOR_X10           					8   // 16%
#define DEFAULT_VALUE_CONFIG_0                          					0   // bit0 = lights; bit1 = walk assist; bit2 = offroad mode
#define DEFAULT_VALUE_BATTERY_MAX_CURRENT               					17  // 17 amps
#define DEFAULT_VALUE_MOTOR_MAX_POWER_X10      										25  // 250 watts
#define DEFAULT_VALUE_BATTERY_LOW_VOLTAGE_CUT_OFF_X10_0 					34  // 36v battery, LVC = 29.0 (2.9 * 10): (34 + (1 << 8))
#define DEFAULT_VALUE_BATTERY_LOW_VOLTAGE_CUT_OFF_X10_1 					1
#define DEFAULT_VALUE_WHEEL_PERIMETER_0                 					35  // 26x2.35 wheel: 2083mm perimeter (35 + (8 << 8))
#define DEFAULT_VALUE_WHEEL_PERIMETER_1                 					8
#define DEFAULT_VALUE_WHEEL_MAX_SPEED                   					45  // 45km/h
#define DEFAULT_VALUE_CONFIG_1                          					1   // bit0-1 motor_type: 0 = 48V, 1 = 36V; bit2: enable motor assistance start without pedal rotation; bit3: enable temperature limit feature
#define DEFAULT_VALUE_OFFROAD_CONFIG                    					0   // bit0: enable offroad, bit1: enable offroad on startup, bit2: enable offroad power limit
#define DEFAULT_VALUE_OFFROAD_SPEED_LIMIT               					25  // 25km/h
#define DEFAULT_VALUE_OFFROAD_POWER_LIMIT_DIV25         					10  // 10 * 25 = 250W
#if ENABLE_VLCD6_COMPATIBILITY
#define DEFAULT_VALUE_BATTERY_CELLS_NUMBER												10  // 10 cells = 36V
#define DEFAULT_VALUE_BATTERY_PACK_RESISTANCE_0										196	// 196 milli ohms, battery pack 36V 10S5P
#define DEFAULT_VALUE_BATTERY_PACK_RESISTANCE_1										0
#define DEFAULT_VALUE_VLCD6_WHEEL_SPEED_FACTOR_0									59  // VLCD6 wheel speed factor = 315 (59 + (1 << 8))
#define DEFAULT_VALUE_VLCD6_WHEEL_SPEED_FACTOR_1									1
#define DEFAULT_VALUE_ASSIST_LEVEL_FACTOR_1												8   // 0.8 = 16%
#define DEFAULT_VALUE_ASSIST_LEVEL_FACTOR_2												16  // 1.6 = 32%
#define DEFAULT_VALUE_ASSIST_LEVEL_FACTOR_3												30  // 3.0 = 60%
#define DEFAULT_VALUE_ASSIST_LEVEL_FACTOR_4												50  // 5.0 = 100%
#define DEFAULT_VALUE_STARTUP_MOTOR_POWER_BOOST_STATE							0   // 0 = enabled on startup when wheel speed is zero, 1 = enable always when cadence was zero
#define DEFAULT_VALUE_STARTUP_MOTOR_POWER_BOOST_FEATURE_ENABLED   0   // 0 = startup power boost disabled, 1 = startup power boost enabled
#define DEFAULT_VALUE_STARTUP_MOTOR_POWER_BOOST_ASSIST_LEVEL_1		4   // 200W
#define DEFAULT_VALUE_STARTUP_MOTOR_POWER_BOOST_ASSIST_LEVEL_2		12  // 621W
#define DEFAULT_VALUE_STARTUP_MOTOR_POWER_BOOST_ASSIST_LEVEL_3		20  // 1035W
#define DEFAULT_VALUE_STARTUP_MOTOR_POWER_BOOST_ASSIST_LEVEL_4    28  // 1450W
#define DEFAULT_VALUE_STARTUP_MOTOR_POWER_BOOST_TIME							20  // 2.0 seconds, 0 = startup power boost disabled
#define DEFAULT_VALUE_STARTUP_MOTOR_POWER_BOOST_FADE_TIME					35  // 3.5 seconds
#define DEFAULT_VALUE_STARTUP_MOTOR_POWER_BOOST_LIMIT_MAX_POWER		1   // 0 = disable boost limit max power, 1 = enable boost limit max power
#define DEFAULT_VALUE_TARGET_MAX_BATTERY_POWER_DIV25              25  // 25 = 625 watts (25 * 25), 0 is disabled
#define DEFAULT_VALUE_TEMPERATURE_LIMIT_FEATURE_ENABLED						0
#define DEFAULT_VALUE_MOTOR_TEMPERATURE_MIN_VALUE_LIMIT						75  // 75�C
#define DEFAULT_VALUE_MOTOR_TEMPERATURE_MAX_VALUE_LIMIT						85  // 85�C
#define DEFAULT_VALUE_WALK_ASSIST_PERCENTAGE_CURRENT							10  // 10% of max battery current (max = 100%)
#define DEFAULT_VALUE_WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_0					12  // 0...255
#define DEFAULT_VALUE_WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_1					18  // 0...255
#define DEFAULT_VALUE_WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_2					26  // 0...255
#define DEFAULT_VALUE_WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_3					32  // 0...255
#define DEFAULT_VALUE_WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_4					40  // 0...255
#define DEFAULT_VALUE_WALK_ASSIST_MAX_RAMP_TIME										20  // 2.0 seconds
#endif 
// *************************************************************************** //

// *************************************************************************** //
// BATTERY

// ADC Battery voltage
// 0.344 per ADC_8bits step: 17.9V --> ADC_8bits = 52; 40V --> ADC_8bits = 116; this signal atenuated by the opamp 358
#define ADC10BITS_BATTERY_VOLTAGE_PER_ADC_STEP_X512 44
#define ADC10BITS_BATTERY_VOLTAGE_PER_ADC_STEP_X256 (ADC10BITS_BATTERY_VOLTAGE_PER_ADC_STEP_X512 >> 1)
#define ADC8BITS_BATTERY_VOLTAGE_PER_ADC_STEP_INVERSE_X256 (ADC10BITS_BATTERY_VOLTAGE_PER_ADC_STEP_X256 << 2)

// ADC Battery current
// 1A per 5 steps of ADC_10bits
#define ADC_BATTERY_CURRENT_PER_ADC_STEP_X512 102

#define ADC_BATTERY_VOLTAGE_MIN   (uint8_t) ((float) (BATTERY_LI_ION_CELLS_NUMBER * LI_ION_CELL_VOLTS_0) / ADC8BITS_BATTERY_VOLTAGE_PER_ADC_STEP)

// Possible values: 0, 1, 2, 3, 4, 5, 6
// 0 equal to no filtering and no delay, higher values will increase filtering but will also add bigger delay
#define READ_BATTERY_CURRENT_FILTER_COEFFICIENT 2
#define READ_BATTERY_VOLTAGE_FILTER_COEFFICIENT 2

#if ENABLE_VLCD6_COMPATIBILITY
// Battery voltage (readed on motor controller):
#if 1
#define VLCD6_ADC_BATTERY_VOLTAGE_PER_ADC_STEP_X10000 866 // Samsung INR18650-25R cells
#else
#define VLCD6_ADC_BATTERY_VOLTAGE_PER_ADC_STEP_X10000	863
#endif
// Possible values: 0, 1, 2, 3, 4, 5, 6
// 0 equal to no filtering and no delay, higher values will increase filtering but will also add bigger delay
#define VLCD6_BATTERY_VOLTAGE_FILTER_COEFFICIENT 3
#define VLCD6_BATTERY_CURRENT_FILTER_COEFFICIENT 3
#endif
// *************************************************************************** //
#define READ_MOTOR_TEMPERATURE_FILTER_COEFFICIENT 4

#endif // _MAIN_H_
