                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 3.8.0 #10562 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module stm8s_gpio
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _GPIO_DeInit
                                     12 	.globl _GPIO_Init
                                     13 	.globl _GPIO_Write
                                     14 	.globl _GPIO_WriteHigh
                                     15 	.globl _GPIO_WriteLow
                                     16 	.globl _GPIO_WriteReverse
                                     17 	.globl _GPIO_ReadOutputData
                                     18 	.globl _GPIO_ReadInputData
                                     19 	.globl _GPIO_ReadInputPin
                                     20 	.globl _GPIO_ExternalPullUpConfig
                                     21 ;--------------------------------------------------------
                                     22 ; ram data
                                     23 ;--------------------------------------------------------
                                     24 	.area DATA
                                     25 ;--------------------------------------------------------
                                     26 ; ram data
                                     27 ;--------------------------------------------------------
                                     28 	.area INITIALIZED
                                     29 ;--------------------------------------------------------
                                     30 ; absolute external ram data
                                     31 ;--------------------------------------------------------
                                     32 	.area DABS (ABS)
                                     33 
                                     34 ; default segment ordering for linker
                                     35 	.area HOME
                                     36 	.area GSINIT
                                     37 	.area GSFINAL
                                     38 	.area CONST
                                     39 	.area INITIALIZER
                                     40 	.area CODE
                                     41 
                                     42 ;--------------------------------------------------------
                                     43 ; global & static initialisations
                                     44 ;--------------------------------------------------------
                                     45 	.area HOME
                                     46 	.area GSINIT
                                     47 	.area GSFINAL
                                     48 	.area GSINIT
                                     49 ;--------------------------------------------------------
                                     50 ; Home
                                     51 ;--------------------------------------------------------
                                     52 	.area HOME
                                     53 	.area HOME
                                     54 ;--------------------------------------------------------
                                     55 ; code
                                     56 ;--------------------------------------------------------
                                     57 	.area CODE
                           000000    58 	G$GPIO_DeInit$0$0 ==.
                           000000    59 	C$stm8s_gpio.c$53$0_0$346 ==.
                                     60 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 53: void GPIO_DeInit(GPIO_TypeDef* GPIOx)
                                     61 ;	-----------------------------------------
                                     62 ;	 function GPIO_DeInit
                                     63 ;	-----------------------------------------
      0088B6                         64 _GPIO_DeInit:
                           000000    65 	C$stm8s_gpio.c$55$1_0$346 ==.
                                     66 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 55: GPIOx->ODR = GPIO_ODR_RESET_VALUE; /* Reset Output Data Register */
      0088B6 16 03            [ 2]   67 	ldw	y, (0x03, sp)
      0088B8 90 7F            [ 1]   68 	clr	(y)
                           000004    69 	C$stm8s_gpio.c$56$1_0$346 ==.
                                     70 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 56: GPIOx->DDR = GPIO_DDR_RESET_VALUE; /* Reset Data Direction Register */
      0088BA 93               [ 1]   71 	ldw	x, y
      0088BB 5C               [ 1]   72 	incw	x
      0088BC 5C               [ 1]   73 	incw	x
      0088BD 7F               [ 1]   74 	clr	(x)
                           000008    75 	C$stm8s_gpio.c$57$1_0$346 ==.
                                     76 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 57: GPIOx->CR1 = GPIO_CR1_RESET_VALUE; /* Reset Control Register 1 */
      0088BE 93               [ 1]   77 	ldw	x, y
      0088BF 6F 03            [ 1]   78 	clr	(0x0003, x)
                           00000B    79 	C$stm8s_gpio.c$58$1_0$346 ==.
                                     80 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 58: GPIOx->CR2 = GPIO_CR2_RESET_VALUE; /* Reset Control Register 2 */
      0088C1 93               [ 1]   81 	ldw	x, y
      0088C2 6F 04            [ 1]   82 	clr	(0x0004, x)
                           00000E    83 	C$stm8s_gpio.c$59$1_0$346 ==.
                                     84 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 59: }
                           00000E    85 	C$stm8s_gpio.c$59$1_0$346 ==.
                           00000E    86 	XG$GPIO_DeInit$0$0 ==.
      0088C4 81               [ 4]   87 	ret
                           00000F    88 	G$GPIO_Init$0$0 ==.
                           00000F    89 	C$stm8s_gpio.c$71$1_0$348 ==.
                                     90 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 71: void GPIO_Init(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin, GPIO_Mode_TypeDef GPIO_Mode)
                                     91 ;	-----------------------------------------
                                     92 ;	 function GPIO_Init
                                     93 ;	-----------------------------------------
      0088C5                         94 _GPIO_Init:
      0088C5 52 07            [ 2]   95 	sub	sp, #7
                           000011    96 	C$stm8s_gpio.c$74$1_0$348 ==.
                                     97 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 74: GPIOx->CR2 &= (uint8_t)(~(GPIO_Pin));
      0088C7 16 0A            [ 2]   98 	ldw	y, (0x0a, sp)
      0088C9 93               [ 1]   99 	ldw	x, y
      0088CA 1C 00 04         [ 2]  100 	addw	x, #0x0004
      0088CD 1F 01            [ 2]  101 	ldw	(0x01, sp), x
      0088CF F6               [ 1]  102 	ld	a, (x)
      0088D0 88               [ 1]  103 	push	a
      0088D1 7B 0D            [ 1]  104 	ld	a, (0x0d, sp)
      0088D3 43               [ 1]  105 	cpl	a
      0088D4 6B 04            [ 1]  106 	ld	(0x04, sp), a
      0088D6 84               [ 1]  107 	pop	a
      0088D7 14 03            [ 1]  108 	and	a, (0x03, sp)
      0088D9 1E 01            [ 2]  109 	ldw	x, (0x01, sp)
      0088DB F7               [ 1]  110 	ld	(x), a
                           000026   111 	C$stm8s_gpio.c$80$1_0$348 ==.
                                    112 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 80: if ((((uint8_t)(GPIO_Mode)) & (uint8_t)0x80) != (uint8_t)0x00) /* Output mode */
      0088DC 0D 0D            [ 1]  113 	tnz	(0x0d, sp)
      0088DE 2A 1D            [ 1]  114 	jrpl	00105$
                           00002A   115 	C$stm8s_gpio.c$82$2_0$349 ==.
                                    116 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 82: if ((((uint8_t)(GPIO_Mode)) & (uint8_t)0x10) != (uint8_t)0x00) /* High level */
      0088E0 7B 0D            [ 1]  117 	ld	a, (0x0d, sp)
      0088E2 A5 10            [ 1]  118 	bcp	a, #0x10
      0088E4 27 08            [ 1]  119 	jreq	00102$
                           000030   120 	C$stm8s_gpio.c$84$3_0$350 ==.
                                    121 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 84: GPIOx->ODR |= (uint8_t)GPIO_Pin;
      0088E6 90 F6            [ 1]  122 	ld	a, (y)
      0088E8 1A 0C            [ 1]  123 	or	a, (0x0c, sp)
      0088EA 90 F7            [ 1]  124 	ld	(y), a
      0088EC 20 06            [ 2]  125 	jra	00103$
      0088EE                        126 00102$:
                           000038   127 	C$stm8s_gpio.c$88$3_0$351 ==.
                                    128 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 88: GPIOx->ODR &= (uint8_t)(~(GPIO_Pin));
      0088EE 90 F6            [ 1]  129 	ld	a, (y)
      0088F0 14 03            [ 1]  130 	and	a, (0x03, sp)
      0088F2 90 F7            [ 1]  131 	ld	(y), a
      0088F4                        132 00103$:
                           00003E   133 	C$stm8s_gpio.c$91$2_0$349 ==.
                                    134 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 91: GPIOx->DDR |= (uint8_t)GPIO_Pin;
      0088F4 93               [ 1]  135 	ldw	x, y
      0088F5 5C               [ 1]  136 	incw	x
      0088F6 5C               [ 1]  137 	incw	x
      0088F7 F6               [ 1]  138 	ld	a, (x)
      0088F8 1A 0C            [ 1]  139 	or	a, (0x0c, sp)
      0088FA F7               [ 1]  140 	ld	(x), a
      0088FB 20 0B            [ 2]  141 	jra	00106$
      0088FD                        142 00105$:
                           000047   143 	C$stm8s_gpio.c$96$2_0$352 ==.
                                    144 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 96: GPIOx->DDR &= (uint8_t)(~(GPIO_Pin));
      0088FD 93               [ 1]  145 	ldw	x, y
      0088FE 5C               [ 1]  146 	incw	x
      0088FF 5C               [ 1]  147 	incw	x
      008900 1F 06            [ 2]  148 	ldw	(0x06, sp), x
      008902 F6               [ 1]  149 	ld	a, (x)
      008903 14 03            [ 1]  150 	and	a, (0x03, sp)
      008905 1E 06            [ 2]  151 	ldw	x, (0x06, sp)
      008907 F7               [ 1]  152 	ld	(x), a
      008908                        153 00106$:
                           000052   154 	C$stm8s_gpio.c$103$1_0$348 ==.
                                    155 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 103: if ((((uint8_t)(GPIO_Mode)) & (uint8_t)0x40) != (uint8_t)0x00) /* Pull-Up or Push-Pull */
      008908 7B 0D            [ 1]  156 	ld	a, (0x0d, sp)
      00890A A5 40            [ 1]  157 	bcp	a, #0x40
      00890C 27 0A            [ 1]  158 	jreq	00108$
                           000058   159 	C$stm8s_gpio.c$105$2_0$353 ==.
                                    160 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 105: GPIOx->CR1 |= (uint8_t)GPIO_Pin;
      00890E 93               [ 1]  161 	ldw	x, y
      00890F 1C 00 03         [ 2]  162 	addw	x, #0x0003
      008912 F6               [ 1]  163 	ld	a, (x)
      008913 1A 0C            [ 1]  164 	or	a, (0x0c, sp)
      008915 F7               [ 1]  165 	ld	(x), a
      008916 20 0C            [ 2]  166 	jra	00109$
      008918                        167 00108$:
                           000062   168 	C$stm8s_gpio.c$109$2_0$354 ==.
                                    169 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 109: GPIOx->CR1 &= (uint8_t)(~(GPIO_Pin));
      008918 93               [ 1]  170 	ldw	x, y
      008919 1C 00 03         [ 2]  171 	addw	x, #0x0003
      00891C 1F 04            [ 2]  172 	ldw	(0x04, sp), x
      00891E F6               [ 1]  173 	ld	a, (x)
      00891F 14 03            [ 1]  174 	and	a, (0x03, sp)
      008921 1E 04            [ 2]  175 	ldw	x, (0x04, sp)
      008923 F7               [ 1]  176 	ld	(x), a
      008924                        177 00109$:
                           00006E   178 	C$stm8s_gpio.c$116$1_0$348 ==.
                                    179 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 116: if ((((uint8_t)(GPIO_Mode)) & (uint8_t)0x20) != (uint8_t)0x00) /* Interrupt or Slow slope */
      008924 7B 0D            [ 1]  180 	ld	a, (0x0d, sp)
      008926 A5 20            [ 1]  181 	bcp	a, #0x20
      008928 27 0A            [ 1]  182 	jreq	00111$
                           000074   183 	C$stm8s_gpio.c$118$2_0$355 ==.
                                    184 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 118: GPIOx->CR2 |= (uint8_t)GPIO_Pin;
      00892A 1E 01            [ 2]  185 	ldw	x, (0x01, sp)
      00892C F6               [ 1]  186 	ld	a, (x)
      00892D 1A 0C            [ 1]  187 	or	a, (0x0c, sp)
      00892F 1E 01            [ 2]  188 	ldw	x, (0x01, sp)
      008931 F7               [ 1]  189 	ld	(x), a
      008932 20 08            [ 2]  190 	jra	00113$
      008934                        191 00111$:
                           00007E   192 	C$stm8s_gpio.c$122$2_0$356 ==.
                                    193 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 122: GPIOx->CR2 &= (uint8_t)(~(GPIO_Pin));
      008934 1E 01            [ 2]  194 	ldw	x, (0x01, sp)
      008936 F6               [ 1]  195 	ld	a, (x)
      008937 14 03            [ 1]  196 	and	a, (0x03, sp)
      008939 1E 01            [ 2]  197 	ldw	x, (0x01, sp)
      00893B F7               [ 1]  198 	ld	(x), a
      00893C                        199 00113$:
                           000086   200 	C$stm8s_gpio.c$124$1_0$348 ==.
                                    201 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 124: }
      00893C 5B 07            [ 2]  202 	addw	sp, #7
                           000088   203 	C$stm8s_gpio.c$124$1_0$348 ==.
                           000088   204 	XG$GPIO_Init$0$0 ==.
      00893E 81               [ 4]  205 	ret
                           000089   206 	G$GPIO_Write$0$0 ==.
                           000089   207 	C$stm8s_gpio.c$134$1_0$358 ==.
                                    208 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 134: void GPIO_Write(GPIO_TypeDef* GPIOx, uint8_t PortVal)
                                    209 ;	-----------------------------------------
                                    210 ;	 function GPIO_Write
                                    211 ;	-----------------------------------------
      00893F                        212 _GPIO_Write:
                           000089   213 	C$stm8s_gpio.c$136$1_0$358 ==.
                                    214 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 136: GPIOx->ODR = PortVal;
      00893F 1E 03            [ 2]  215 	ldw	x, (0x03, sp)
      008941 7B 05            [ 1]  216 	ld	a, (0x05, sp)
      008943 F7               [ 1]  217 	ld	(x), a
                           00008E   218 	C$stm8s_gpio.c$137$1_0$358 ==.
                                    219 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 137: }
                           00008E   220 	C$stm8s_gpio.c$137$1_0$358 ==.
                           00008E   221 	XG$GPIO_Write$0$0 ==.
      008944 81               [ 4]  222 	ret
                           00008F   223 	G$GPIO_WriteHigh$0$0 ==.
                           00008F   224 	C$stm8s_gpio.c$147$1_0$360 ==.
                                    225 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 147: void GPIO_WriteHigh(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef PortPins)
                                    226 ;	-----------------------------------------
                                    227 ;	 function GPIO_WriteHigh
                                    228 ;	-----------------------------------------
      008945                        229 _GPIO_WriteHigh:
                           00008F   230 	C$stm8s_gpio.c$149$1_0$360 ==.
                                    231 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 149: GPIOx->ODR |= (uint8_t)PortPins;
      008945 1E 03            [ 2]  232 	ldw	x, (0x03, sp)
      008947 F6               [ 1]  233 	ld	a, (x)
      008948 1A 05            [ 1]  234 	or	a, (0x05, sp)
      00894A F7               [ 1]  235 	ld	(x), a
                           000095   236 	C$stm8s_gpio.c$150$1_0$360 ==.
                                    237 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 150: }
                           000095   238 	C$stm8s_gpio.c$150$1_0$360 ==.
                           000095   239 	XG$GPIO_WriteHigh$0$0 ==.
      00894B 81               [ 4]  240 	ret
                           000096   241 	G$GPIO_WriteLow$0$0 ==.
                           000096   242 	C$stm8s_gpio.c$160$1_0$362 ==.
                                    243 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 160: void GPIO_WriteLow(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef PortPins)
                                    244 ;	-----------------------------------------
                                    245 ;	 function GPIO_WriteLow
                                    246 ;	-----------------------------------------
      00894C                        247 _GPIO_WriteLow:
      00894C 88               [ 1]  248 	push	a
                           000097   249 	C$stm8s_gpio.c$162$1_0$362 ==.
                                    250 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 162: GPIOx->ODR &= (uint8_t)(~PortPins);
      00894D 1E 04            [ 2]  251 	ldw	x, (0x04, sp)
      00894F F6               [ 1]  252 	ld	a, (x)
      008950 6B 01            [ 1]  253 	ld	(0x01, sp), a
      008952 7B 06            [ 1]  254 	ld	a, (0x06, sp)
      008954 43               [ 1]  255 	cpl	a
      008955 14 01            [ 1]  256 	and	a, (0x01, sp)
      008957 F7               [ 1]  257 	ld	(x), a
                           0000A2   258 	C$stm8s_gpio.c$163$1_0$362 ==.
                                    259 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 163: }
      008958 84               [ 1]  260 	pop	a
                           0000A3   261 	C$stm8s_gpio.c$163$1_0$362 ==.
                           0000A3   262 	XG$GPIO_WriteLow$0$0 ==.
      008959 81               [ 4]  263 	ret
                           0000A4   264 	G$GPIO_WriteReverse$0$0 ==.
                           0000A4   265 	C$stm8s_gpio.c$173$1_0$364 ==.
                                    266 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 173: void GPIO_WriteReverse(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef PortPins)
                                    267 ;	-----------------------------------------
                                    268 ;	 function GPIO_WriteReverse
                                    269 ;	-----------------------------------------
      00895A                        270 _GPIO_WriteReverse:
                           0000A4   271 	C$stm8s_gpio.c$175$1_0$364 ==.
                                    272 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 175: GPIOx->ODR ^= (uint8_t)PortPins;
      00895A 1E 03            [ 2]  273 	ldw	x, (0x03, sp)
      00895C F6               [ 1]  274 	ld	a, (x)
      00895D 18 05            [ 1]  275 	xor	a, (0x05, sp)
      00895F F7               [ 1]  276 	ld	(x), a
                           0000AA   277 	C$stm8s_gpio.c$176$1_0$364 ==.
                                    278 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 176: }
                           0000AA   279 	C$stm8s_gpio.c$176$1_0$364 ==.
                           0000AA   280 	XG$GPIO_WriteReverse$0$0 ==.
      008960 81               [ 4]  281 	ret
                           0000AB   282 	G$GPIO_ReadOutputData$0$0 ==.
                           0000AB   283 	C$stm8s_gpio.c$184$1_0$366 ==.
                                    284 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 184: uint8_t GPIO_ReadOutputData(GPIO_TypeDef* GPIOx)
                                    285 ;	-----------------------------------------
                                    286 ;	 function GPIO_ReadOutputData
                                    287 ;	-----------------------------------------
      008961                        288 _GPIO_ReadOutputData:
                           0000AB   289 	C$stm8s_gpio.c$186$1_0$366 ==.
                                    290 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 186: return ((uint8_t)GPIOx->ODR);
      008961 1E 03            [ 2]  291 	ldw	x, (0x03, sp)
      008963 F6               [ 1]  292 	ld	a, (x)
                           0000AE   293 	C$stm8s_gpio.c$187$1_0$366 ==.
                                    294 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 187: }
                           0000AE   295 	C$stm8s_gpio.c$187$1_0$366 ==.
                           0000AE   296 	XG$GPIO_ReadOutputData$0$0 ==.
      008964 81               [ 4]  297 	ret
                           0000AF   298 	G$GPIO_ReadInputData$0$0 ==.
                           0000AF   299 	C$stm8s_gpio.c$195$1_0$368 ==.
                                    300 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 195: uint8_t GPIO_ReadInputData(GPIO_TypeDef* GPIOx)
                                    301 ;	-----------------------------------------
                                    302 ;	 function GPIO_ReadInputData
                                    303 ;	-----------------------------------------
      008965                        304 _GPIO_ReadInputData:
                           0000AF   305 	C$stm8s_gpio.c$197$1_0$368 ==.
                                    306 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 197: return ((uint8_t)GPIOx->IDR);
      008965 1E 03            [ 2]  307 	ldw	x, (0x03, sp)
      008967 E6 01            [ 1]  308 	ld	a, (0x1, x)
                           0000B3   309 	C$stm8s_gpio.c$198$1_0$368 ==.
                                    310 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 198: }
                           0000B3   311 	C$stm8s_gpio.c$198$1_0$368 ==.
                           0000B3   312 	XG$GPIO_ReadInputData$0$0 ==.
      008969 81               [ 4]  313 	ret
                           0000B4   314 	G$GPIO_ReadInputPin$0$0 ==.
                           0000B4   315 	C$stm8s_gpio.c$206$1_0$370 ==.
                                    316 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 206: BitStatus GPIO_ReadInputPin(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin)
                                    317 ;	-----------------------------------------
                                    318 ;	 function GPIO_ReadInputPin
                                    319 ;	-----------------------------------------
      00896A                        320 _GPIO_ReadInputPin:
                           0000B4   321 	C$stm8s_gpio.c$208$1_0$370 ==.
                                    322 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 208: return ((BitStatus)(GPIOx->IDR & (uint8_t)GPIO_Pin));
      00896A 1E 03            [ 2]  323 	ldw	x, (0x03, sp)
      00896C E6 01            [ 1]  324 	ld	a, (0x1, x)
      00896E 14 05            [ 1]  325 	and	a, (0x05, sp)
                           0000BA   326 	C$stm8s_gpio.c$209$1_0$370 ==.
                                    327 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 209: }
                           0000BA   328 	C$stm8s_gpio.c$209$1_0$370 ==.
                           0000BA   329 	XG$GPIO_ReadInputPin$0$0 ==.
      008970 81               [ 4]  330 	ret
                           0000BB   331 	G$GPIO_ExternalPullUpConfig$0$0 ==.
                           0000BB   332 	C$stm8s_gpio.c$218$1_0$372 ==.
                                    333 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 218: void GPIO_ExternalPullUpConfig(GPIO_TypeDef* GPIOx, GPIO_Pin_TypeDef GPIO_Pin, FunctionalState NewState)
                                    334 ;	-----------------------------------------
                                    335 ;	 function GPIO_ExternalPullUpConfig
                                    336 ;	-----------------------------------------
      008971                        337 _GPIO_ExternalPullUpConfig:
      008971 88               [ 1]  338 	push	a
                           0000BC   339 	C$stm8s_gpio.c$224$1_0$372 ==.
                                    340 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 224: if (NewState != DISABLE) /* External Pull-Up Set*/
      008972 0D 07            [ 1]  341 	tnz	(0x07, sp)
      008974 27 0B            [ 1]  342 	jreq	00102$
                           0000C0   343 	C$stm8s_gpio.c$226$2_0$373 ==.
                                    344 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 226: GPIOx->CR1 |= (uint8_t)GPIO_Pin;
      008976 1E 04            [ 2]  345 	ldw	x, (0x04, sp)
      008978 1C 00 03         [ 2]  346 	addw	x, #0x0003
      00897B F6               [ 1]  347 	ld	a, (x)
      00897C 1A 06            [ 1]  348 	or	a, (0x06, sp)
      00897E F7               [ 1]  349 	ld	(x), a
      00897F 20 0E            [ 2]  350 	jra	00104$
      008981                        351 00102$:
                           0000CB   352 	C$stm8s_gpio.c$229$2_0$374 ==.
                                    353 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 229: GPIOx->CR1 &= (uint8_t)(~(GPIO_Pin));
      008981 1E 04            [ 2]  354 	ldw	x, (0x04, sp)
      008983 1C 00 03         [ 2]  355 	addw	x, #0x0003
      008986 F6               [ 1]  356 	ld	a, (x)
      008987 6B 01            [ 1]  357 	ld	(0x01, sp), a
      008989 7B 06            [ 1]  358 	ld	a, (0x06, sp)
      00898B 43               [ 1]  359 	cpl	a
      00898C 14 01            [ 1]  360 	and	a, (0x01, sp)
      00898E F7               [ 1]  361 	ld	(x), a
      00898F                        362 00104$:
                           0000D9   363 	C$stm8s_gpio.c$231$1_0$372 ==.
                                    364 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_gpio.c: 231: }
      00898F 84               [ 1]  365 	pop	a
                           0000DA   366 	C$stm8s_gpio.c$231$1_0$372 ==.
                           0000DA   367 	XG$GPIO_ExternalPullUpConfig$0$0 ==.
      008990 81               [ 4]  368 	ret
                                    369 	.area CODE
                                    370 	.area CONST
                                    371 	.area INITIALIZER
                                    372 	.area CABS (ABS)
