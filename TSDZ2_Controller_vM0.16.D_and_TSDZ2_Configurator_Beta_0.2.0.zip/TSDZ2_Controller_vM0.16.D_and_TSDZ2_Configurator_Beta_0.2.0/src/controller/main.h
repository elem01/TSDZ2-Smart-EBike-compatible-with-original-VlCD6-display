/*
 * TongSheng TSDZ2 motor controller firmware/
 *
 * Copyright (C) Casainho, 2018.
 *
 * Released under the GPL License, Version 3
 */

#ifndef _MAIN_H_
#define _MAIN_H_

#include "config.h"

//=================================================================================================
// ENABLES
//=================================================================================================
#if ENABLE_VLCD6
#define ENABLE_VLCD6_COMPATIBILITY				1
#define ENABLE_KTLCD3_COMPATIBILITY				0
#define ENABLE_BLUETOOTH_COMPATIBILITY		0
#elif ENABLE_KTLCD3
#define ENABLE_KTLCD3_COMPATIBILITY				1
#define ENABLE_VLCD6_COMPATIBILITY				0
#define ENABLE_BLUETOOTH_COMPATIBILITY		0
#elif ENABLE_BLUETOOTH
#define ENABLE_BLUETOOTH_COMPATIBILITY		1
#define ENABLE_VLCD6_COMPATIBILITY				0
#define ENABLE_KTLCD3_COMPATIBILITY				0
#else
#define ENABLE_VLCD6_COMPATIBILITY				1
#define ENABLE_KTLCD3_COMPATIBILITY				0
#define ENABLE_BLUETOOTH_COMPATIBILITY		0
#endif 
//---------------------------------------------------------
#define ENABLE_DEBUG_UART									0
#define ENABLE_DEBUG_FIRMWARE							0
//---------------------------------------------------------
#if ENABLE_VLCD6_ALWAYS_ON
#define ENABLE_MOTOR_WORKING_FLAG					0
#define ENABLE_WHEEL_TURNING_FLAG					0
#endif
/**********************************************************
#define NO_FAULT
#define TEMPERATURE_PROTECTION
#define SHORT_CIRCUIT_PROTECTION
#define TURN_FAULT
#define MOTOR_PHASE_LOSS
#define TORQUE_FAULT
#define JAM_FAULT
#define EBIKE_WHEEL_BLOCKED
#define OVERVOLTAGE
***********************************************************/
#define NO_FAULT													0
#define TEMPERATURE_PROTECTION						6
#define EBIKE_WHEEL_BLOCKED								7
#define OVERVOLTAGE												8
//---------------------------------------------------------
#define NO_FUNCTION												0
#define PENDING_FUNCTION_ABORTED					0
#define DEFAULT_FUNCTION_ENABLED					0
#define DEFAULT_ENABLED_ON_VLCD6					2
#define OFFROAD_FUNCTION_ENABLED					0
#define STREET_FUNCTION_ENABLED						0
#define STREET_ENABLED_ON_VLCD6						3
#define OFFROAD_ENABLED_ON_VLCD6					4
#define BOOST_FUNCTION_ENABLED						0
#define BOOST_FUNCTION_DISABLED						0
#define BOOST_DISABLED_ON_VLCD6						1
#define BOOST_ENABLED_ON_VLCD6						5
//=================================================================================================
// GENERAL CONFIG
//=================================================================================================
#define LIGHTS_ACTIVATED																		0	// lights activated (CONFIG_0 bit0)
#define WALK_ASSIST_ACTIVATED																0	// walk assist activated (CONFIG_0 bit1)
#define OFFROAD_MODE_ACTIVATED															0	// offroad mode activated (CONFIG_0 bit2)
#define CONFIG_0																						(uint8_t) ((LIGHTS_ACTIVATED)|(WALK_ASSIST_ACTIVATED << 1)|(OFFROAD_MODE_ACTIVATED << 2))

#if MOTOR_TYPE_36V
#define MOTOR_TYPE	1
#elif MOTOR_TYPE_48V
#define MOTOR_TYPE	0
#else
#define MOTOR_TYPE	1
#endif
#define CONFIG_1																						(uint8_t) ((MOTOR_TYPE)|(EXPERIMENTAL_HIGH_CADENCE_MODE << 1)|(MOTOR_ASSISTANCE_WITHOUT_PEDAL_ROTATION << 2))

//=================================================================================================
// OFFROAD CONFIG
//=================================================================================================
#define OFFROAD_ON_STARTUP_ENABLED													0 // not used
#define OFFROAD_CONFIG																			(uint8_t) ((OFFROAD_FEATURE_ENABLED)|(OFFROAD_ON_STARTUP_ENABLED << 1)|(OFFROAD_POWER_LIMIT_ENABLED << 2))
#define OFFROAD_POWER_LIMIT_DIV25         									(uint8_t) (OFFROAD_POWER_LIMIT / 25)

//=================================================================================================
// BATTERY CONFIG
//=================================================================================================
// This is the current that motor will draw from the battery
// Higher value will give higher torque and the limit of the controller is 16 amps
#define ADC_BATTERY_CURRENT_MAX															(uint8_t) (ADC_BATTERY_CURRENT_MAX_LIMIT / 0.625)

#define BATTERY_MAX_CURRENT																	(uint8_t) (BATTERY_MAX_CURRENT_FLOAT)

// Battery low voltage cut off
#define BATTERY_LOW_VOLTAGE_CUT_OFF_X10_0										(uint8_t) ((uint16_t)(BATTERY_LOW_VOLTAGE_CUT_OFF_DIV10 * 10) & 0x00FF)
#define BATTERY_LOW_VOLTAGE_CUT_OFF_X10_1										(uint8_t) (((uint16_t)(BATTERY_LOW_VOLTAGE_CUT_OFF_DIV10 * 10) >> 8) & 0x00FF)

// Battery pack resistance
#define BATTERY_PACK_RESISTANCE_0														(uint8_t) (BATTERY_PACK_RESISTANCE & 0x00FF)
#define BATTERY_PACK_RESISTANCE_1														(uint8_t) ((BATTERY_PACK_RESISTANCE >> 8) & 0x00FF)

// Max battery power
#define TARGET_MAX_BATTERY_POWER_DIV25      								(uint8_t) (TARGET_MAX_BATTERY_POWER / 25)

// ADC Battery voltage
#define ADC10BITS_BATTERY_VOLTAGE_PER_ADC_STEP_X512					(uint16_t) (DIVISOR_FOR_CUTOFF_CALC)
#define ADC10BITS_BATTERY_VOLTAGE_PER_ADC_STEP_X256 				(ADC10BITS_BATTERY_VOLTAGE_PER_ADC_STEP_X512 >> 1)
#define ADC8BITS_BATTERY_VOLTAGE_PER_ADC_STEP_INVERSE_X256	(ADC10BITS_BATTERY_VOLTAGE_PER_ADC_STEP_X256 << 2)

// ADC Battery current
// 1A per 5 steps of ADC_10bits
#define ADC_BATTERY_CURRENT_PER_ADC_STEP_X512								102

// ADC Battery SOC voltage per ADC step (x10000)
#define SOC_ADC_BATTERY_VOLTAGE_PER_ADC_STEP_X10000 				(uint16_t) (SOC_ADC_BATTERY_VOLTAGE_PER_ADC_STEP * 10000)	// Samsung INR18650-25R cells

//=================================================================================================
// WHEEL CONFIG
//=================================================================================================
#define WHEEL_PERIMETER_0																		(uint8_t) (WHEEL_PERIMETER & 0x00FF)
#define WHEEL_PERIMETER_1																		(uint8_t) ((WHEEL_PERIMETER >> 8) & 0x00FF)
#define VLCD6_WHEEL_SPEED_DIVISOR_0													(uint8_t) (VLCD6_WHEEL_SPEED_DIVISOR & 0x00FF)
#define VLCD6_WHEEL_SPEED_DIVISOR_1													(uint8_t) ((VLCD6_WHEEL_SPEED_DIVISOR >> 8) & 0x00FF)

//=================================================================================================
// ASSIST LEVELS CONFIG
//=================================================================================================
#define ASSIST_LEVEL_FACTOR_X10															(uint8_t) (ASSIST_LEVEL_FACTOR / 10)
#define ASSIST_LEVEL_FACTOR_1																(uint8_t) (ASSIST_LEVEL_FACTOR_X10_1 / 10)
#define ASSIST_LEVEL_FACTOR_2																(uint8_t) (ASSIST_LEVEL_FACTOR_X10_2 / 10)
#define ASSIST_LEVEL_FACTOR_3																(uint8_t) (ASSIST_LEVEL_FACTOR_X10_3 / 10)
#define ASSIST_LEVEL_FACTOR_4																(uint8_t) (ASSIST_LEVEL_FACTOR_X10_4 / 10)

//=================================================================================================
// BOOST ASSIST CONFIG
//=================================================================================================
#define STARTUP_MOTOR_POWER_BOOST_FEATURE_ENABLED   				0	// startup power boost enabled only from display
#define STARTUP_MOTOR_POWER_BOOST_ASSIST_LEVEL_1						(uint8_t) ((STARTUP_MOTOR_BOOST_ASSIST_LEVEL_PERCENT_1 * 28) / 100)
#define STARTUP_MOTOR_POWER_BOOST_ASSIST_LEVEL_2						(uint8_t) ((STARTUP_MOTOR_BOOST_ASSIST_LEVEL_PERCENT_2 * 28) / 100)
#define STARTUP_MOTOR_POWER_BOOST_ASSIST_LEVEL_3						(uint8_t) ((STARTUP_MOTOR_BOOST_ASSIST_LEVEL_PERCENT_3 * 28) / 100)
#define STARTUP_MOTOR_POWER_BOOST_ASSIST_LEVEL_4  					(uint8_t) ((STARTUP_MOTOR_BOOST_ASSIST_LEVEL_PERCENT_4 * 28) / 100)
#define STARTUP_MOTOR_POWER_BOOST_TIME											(uint8_t) (STARTUP_MOTOR_POWER_BOOST_TIME_DIV10 * 10)
#define STARTUP_MOTOR_POWER_BOOST_FADE_TIME									(uint8_t) (STARTUP_MOTOR_POWER_BOOST_FADE_TIME_DIV10 * 10)
#if STARTUP_BOOST_WHEN_SPEED_IS_ZERO
#define STARTUP_MOTOR_POWER_BOOST_STATE	0
#elif STARTUP_BOOST_WHEN_CADENCE_IS_ZERO
#define STARTUP_MOTOR_POWER_BOOST_STATE	1
#else
#define STARTUP_MOTOR_POWER_BOOST_STATE	0
#endif

//=================================================================================================
// WALK ASSIST LEVELS CONFIG
//=================================================================================================
#define WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_0									(uint8_t) ((WALK_ASSIST_PWM_LEVEL_0 * 255) / 100)
#define WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_1 									(uint8_t) ((WALK_ASSIST_PWM_LEVEL_1 * 255) / 100)
#define WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_2									(uint8_t) ((WALK_ASSIST_PWM_LEVEL_2 * 255) / 100)
#define WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_3									(uint8_t) ((WALK_ASSIST_PWM_LEVEL_3 * 255) / 100)
#define WALK_ASSIST_PWM_DUTY_CYCLE_LEVEL_4									(uint8_t) ((WALK_ASSIST_PWM_LEVEL_4 * 255) / 100)
#define WALK_ASSIST_MAX_RAMP_TIME														(uint8_t) (WALK_ASSIST_MAX_RAMP_TIME_DIV10 * 10)
#define WALK_ASSIST_OFF_DELAY_PWM														(uint8_t) ((WALK_ASSIST_OFF_DELAY_PWM_DIV10 * 255) / 100)
#define WALK_ASSIST_OFF_DELAY_TIME_0												(uint8_t) ((uint16_t)(WALK_ASSIST_OFF_DELAY_TIME_DIV10 * 10) & 0x00FF)
#define WALK_ASSIST_OFF_DELAY_TIME_1												(uint8_t) (((uint16_t)(WALK_ASSIST_OFF_DELAY_TIME_DIV10 * 10) >> 8) & 0x00FF)
#define WALK_ASSIST_MIN_VALUE																(uint8_t) 0
#define WALK_ASSIST_MAX_VALUE																(uint8_t) 100

//=================================================================================================
// MOTOR CONFIG
//=================================================================================================
#define MOTOR_MAX_POWER																			250
#define MOTOR_MAX_POWER_DIV10																(uint8_t) (MOTOR_MAX_POWER / 10)

//=================================================================================================
// MOTOR PWM DUTY CYCLE
//=================================================================================================
// 5 erps minimum speed; 1/5 = 200ms; 200ms/64us = 3125
#define PWM_CYCLES_COUNTER_MAX															(uint16_t) (PWM_CYCLES_SECOND / 5)

// Target: ramp 5 amps per second
// every second has 15625 PWM cycles interrupts
// 1 ADC battery current step --> 0.625 amps
// 5 / 0.625 = 8 (we need to do 8 steps ramp up per second)
// 15625 / 8 = 1953
#define ADC_BATTERY_CURRENT_RAMP_UP_INVERSE_STEP						(uint16_t) (PWM_CYCLES_SECOND / (CURRENT_RAMP / 0.625))

// Middle PWM duty cycle max
#define MIDDLE_PWM_DUTY_CYCLE_MAX														(uint8_t) (PWM_DUTY_CYCLE_MAX / 2)

// Duty cycle ramp (up/down)
#define PWM_DUTY_CYCLE_RAMP_UP_INVERSE_STEP									(uint16_t) ((PWM_DUTY_CYCLE_RAMP_UP_DIV1000 * 1000) / (1000000 / PWM_CYCLES_SECOND))
#define PWM_DUTY_CYCLE_RAMP_DOWN_INVERSE_STEP								(uint16_t) ((PWM_DUTY_CYCLE_RAMP_DOWN_DIV1000 * 1000) / (1000000 / PWM_CYCLES_SECOND))

//=================================================================================================
// MOTOR ROTOR CONFIG
//=================================================================================================
// 0.625 amps each unit
#define ADC_MOTOR_PHASE_CURRENT_MAX													(uint8_t) (MOTOR_PHASE_CURRENT_MAX_AMP / 0.625)

#define MOTOR_ROTOR_ANGLE_90    														(63  + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_150   														(106 + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_210   														(148 + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_270   														(191 + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_330   														(233 + MOTOR_ROTOR_OFFSET_ANGLE)
#define MOTOR_ROTOR_ANGLE_30    														(20  + MOTOR_ROTOR_OFFSET_ANGLE)

//=================================================================================================
// PAS
//=================================================================================================
// x = (1/(150RPM/60)) / (0.000064)
// PAS_ABSOLUTE_MAX_CADENCE_PWM_CYCLE_TICKS = (x / PAS_NUMBER_MAGNETS)
#define PAS_ABSOLUTE_MAX_CADENCE_PWM_CYCLE_TICKS  					(uint16_t) (6250 / PAS_NUMBER_MAGNETS)		// max hard limit to 150RPM PAS cadence
#define PAS_ABSOLUTE_MIN_CADENCE_PWM_CYCLE_TICKS  					(uint16_t) (93750 / PAS_NUMBER_MAGNETS)	// min hard limit to 10RPM PAS cadence
#define PAS_NUMBER_MAGNETS_X2 															(uint8_t) (PAS_NUMBER_MAGNETS * 2)

//=================================================================================================
// TORQUE SENSOR
//=================================================================================================
// Pedal torque sensor X100
#define PEDAL_TORQUE_X100																		(uint8_t) (PEDAL_TORQUE_SENSOR_UNIT * 100)

//=================================================================================================
// LIGHTS TIMING
//=================================================================================================
#define DELAY_LIGHTS_ON																			50 // x0.1 seconds

#endif // _MAIN_H_
