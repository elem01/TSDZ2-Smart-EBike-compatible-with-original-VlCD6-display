                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 3.8.0 #10562 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module stm8s_itc
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ITC_GetCPUCC
                                     12 	.globl _ITC_DeInit
                                     13 	.globl _ITC_GetSoftIntStatus
                                     14 	.globl _ITC_GetSoftwarePriority
                                     15 	.globl _ITC_SetSoftwarePriority
                                     16 ;--------------------------------------------------------
                                     17 ; ram data
                                     18 ;--------------------------------------------------------
                                     19 	.area DATA
                                     20 ;--------------------------------------------------------
                                     21 ; ram data
                                     22 ;--------------------------------------------------------
                                     23 	.area INITIALIZED
                                     24 ;--------------------------------------------------------
                                     25 ; absolute external ram data
                                     26 ;--------------------------------------------------------
                                     27 	.area DABS (ABS)
                                     28 
                                     29 ; default segment ordering for linker
                                     30 	.area HOME
                                     31 	.area GSINIT
                                     32 	.area GSFINAL
                                     33 	.area CONST
                                     34 	.area INITIALIZER
                                     35 	.area CODE
                                     36 
                                     37 ;--------------------------------------------------------
                                     38 ; global & static initialisations
                                     39 ;--------------------------------------------------------
                                     40 	.area HOME
                                     41 	.area GSINIT
                                     42 	.area GSFINAL
                                     43 	.area GSINIT
                                     44 ;--------------------------------------------------------
                                     45 ; Home
                                     46 ;--------------------------------------------------------
                                     47 	.area HOME
                                     48 	.area HOME
                                     49 ;--------------------------------------------------------
                                     50 ; code
                                     51 ;--------------------------------------------------------
                                     52 	.area CODE
                           000000    53 	G$ITC_GetCPUCC$0$0 ==.
                           000000    54 	C$stm8s_itc.c$54$0_0$346 ==.
                                     55 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 54: uint8_t ITC_GetCPUCC(void)
                                     56 ;	-----------------------------------------
                                     57 ;	 function ITC_GetCPUCC
                                     58 ;	-----------------------------------------
      0083A2                         59 _ITC_GetCPUCC:
                           000000    60 	C$stm8s_itc.c$63$1_0$346 ==.
                                     61 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 63: __asm__("push cc");
      0083A2 8A               [ 1]   62 	push	cc
                           000001    63 	C$stm8s_itc.c$64$1_0$346 ==.
                                     64 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 64: __asm__("pop a"); /* Ignore compiler warning, the returned value is in A register */
      0083A3 84               [ 1]   65 	pop	a
                           000002    66 	C$stm8s_itc.c$69$1_0$346 ==.
                                     67 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 69: }
                           000002    68 	C$stm8s_itc.c$69$1_0$346 ==.
                           000002    69 	XG$ITC_GetCPUCC$0$0 ==.
      0083A4 81               [ 4]   70 	ret
                           000003    71 	G$ITC_DeInit$0$0 ==.
                           000003    72 	C$stm8s_itc.c$90$1_0$348 ==.
                                     73 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 90: void ITC_DeInit(void)
                                     74 ;	-----------------------------------------
                                     75 ;	 function ITC_DeInit
                                     76 ;	-----------------------------------------
      0083A5                         77 _ITC_DeInit:
                           000003    78 	C$stm8s_itc.c$92$1_0$348 ==.
                                     79 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 92: ITC->ISPR1 = ITC_SPRX_RESET_VALUE;
      0083A5 35 FF 7F 70      [ 1]   80 	mov	0x7f70+0, #0xff
                           000007    81 	C$stm8s_itc.c$93$1_0$348 ==.
                                     82 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 93: ITC->ISPR2 = ITC_SPRX_RESET_VALUE;
      0083A9 35 FF 7F 71      [ 1]   83 	mov	0x7f71+0, #0xff
                           00000B    84 	C$stm8s_itc.c$94$1_0$348 ==.
                                     85 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 94: ITC->ISPR3 = ITC_SPRX_RESET_VALUE;
      0083AD 35 FF 7F 72      [ 1]   86 	mov	0x7f72+0, #0xff
                           00000F    87 	C$stm8s_itc.c$95$1_0$348 ==.
                                     88 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 95: ITC->ISPR4 = ITC_SPRX_RESET_VALUE;
      0083B1 35 FF 7F 73      [ 1]   89 	mov	0x7f73+0, #0xff
                           000013    90 	C$stm8s_itc.c$96$1_0$348 ==.
                                     91 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 96: ITC->ISPR5 = ITC_SPRX_RESET_VALUE;
      0083B5 35 FF 7F 74      [ 1]   92 	mov	0x7f74+0, #0xff
                           000017    93 	C$stm8s_itc.c$97$1_0$348 ==.
                                     94 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 97: ITC->ISPR6 = ITC_SPRX_RESET_VALUE;
      0083B9 35 FF 7F 75      [ 1]   95 	mov	0x7f75+0, #0xff
                           00001B    96 	C$stm8s_itc.c$98$1_0$348 ==.
                                     97 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 98: ITC->ISPR7 = ITC_SPRX_RESET_VALUE;
      0083BD 35 FF 7F 76      [ 1]   98 	mov	0x7f76+0, #0xff
                           00001F    99 	C$stm8s_itc.c$99$1_0$348 ==.
                                    100 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 99: ITC->ISPR8 = ITC_SPRX_RESET_VALUE;
      0083C1 35 FF 7F 77      [ 1]  101 	mov	0x7f77+0, #0xff
                           000023   102 	C$stm8s_itc.c$100$1_0$348 ==.
                                    103 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 100: }
                           000023   104 	C$stm8s_itc.c$100$1_0$348 ==.
                           000023   105 	XG$ITC_DeInit$0$0 ==.
      0083C5 81               [ 4]  106 	ret
                           000024   107 	G$ITC_GetSoftIntStatus$0$0 ==.
                           000024   108 	C$stm8s_itc.c$107$1_0$350 ==.
                                    109 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 107: uint8_t ITC_GetSoftIntStatus(void)
                                    110 ;	-----------------------------------------
                                    111 ;	 function ITC_GetSoftIntStatus
                                    112 ;	-----------------------------------------
      0083C6                        113 _ITC_GetSoftIntStatus:
                           000024   114 	C$stm8s_itc.c$109$1_0$350 ==.
                                    115 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 109: return (uint8_t)(ITC_GetCPUCC() & CPU_CC_I1I0);
      0083C6 CD 83 A2         [ 4]  116 	call	_ITC_GetCPUCC
      0083C9 A4 28            [ 1]  117 	and	a, #0x28
                           000029   118 	C$stm8s_itc.c$110$1_0$350 ==.
                                    119 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 110: }
                           000029   120 	C$stm8s_itc.c$110$1_0$350 ==.
                           000029   121 	XG$ITC_GetSoftIntStatus$0$0 ==.
      0083CB 81               [ 4]  122 	ret
                           00002A   123 	G$ITC_GetSoftwarePriority$0$0 ==.
                           00002A   124 	C$stm8s_itc.c$117$1_0$352 ==.
                                    125 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 117: ITC_PriorityLevel_TypeDef ITC_GetSoftwarePriority(ITC_Irq_TypeDef IrqNum)
                                    126 ;	-----------------------------------------
                                    127 ;	 function ITC_GetSoftwarePriority
                                    128 ;	-----------------------------------------
      0083CC                        129 _ITC_GetSoftwarePriority:
      0083CC 52 03            [ 2]  130 	sub	sp, #3
                           00002C   131 	C$stm8s_itc.c$119$2_0$352 ==.
                                    132 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 119: uint8_t Value = 0;
      0083CE 0F 01            [ 1]  133 	clr	(0x01, sp)
                           00002E   134 	C$stm8s_itc.c$126$1_0$352 ==.
                                    135 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 126: Mask = (uint8_t)(0x03U << (((uint8_t)IrqNum % 4U) * 2U));
      0083D0 7B 06            [ 1]  136 	ld	a, (0x06, sp)
      0083D2 90 5F            [ 1]  137 	clrw	y
      0083D4 A4 03            [ 1]  138 	and	a, #0x03
      0083D6 48               [ 1]  139 	sll	a
      0083D7 6B 02            [ 1]  140 	ld	(0x02, sp), a
      0083D9 A6 03            [ 1]  141 	ld	a, #0x03
      0083DB 6B 03            [ 1]  142 	ld	(0x03, sp), a
      0083DD 7B 02            [ 1]  143 	ld	a, (0x02, sp)
      0083DF 27 05            [ 1]  144 	jreq	00132$
      0083E1                        145 00131$:
      0083E1 08 03            [ 1]  146 	sll	(0x03, sp)
      0083E3 4A               [ 1]  147 	dec	a
      0083E4 26 FB            [ 1]  148 	jrne	00131$
      0083E6                        149 00132$:
                           000044   150 	C$stm8s_itc.c$128$1_0$352 ==.
                                    151 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 128: switch (IrqNum)
      0083E6 7B 06            [ 1]  152 	ld	a, (0x06, sp)
      0083E8 A1 18            [ 1]  153 	cp	a, #0x18
      0083EA 23 03            [ 2]  154 	jrule	00133$
      0083EC CC 84 68         [ 2]  155 	jp	00123$
      0083EF                        156 00133$:
      0083EF 5F               [ 1]  157 	clrw	x
      0083F0 7B 06            [ 1]  158 	ld	a, (0x06, sp)
      0083F2 97               [ 1]  159 	ld	xl, a
      0083F3 58               [ 2]  160 	sllw	x
      0083F4 DE 83 F8         [ 2]  161 	ldw	x, (#00134$, x)
      0083F7 FC               [ 2]  162 	jp	(x)
      0083F8                        163 00134$:
      0083F8 84 2A                  164 	.dw	#00104$
      0083FA 84 2A                  165 	.dw	#00104$
      0083FC 84 2A                  166 	.dw	#00104$
      0083FE 84 2A                  167 	.dw	#00104$
      008400 84 34                  168 	.dw	#00108$
      008402 84 34                  169 	.dw	#00108$
      008404 84 34                  170 	.dw	#00108$
      008406 84 34                  171 	.dw	#00108$
      008408 84 68                  172 	.dw	#00123$
      00840A 84 68                  173 	.dw	#00123$
      00840C 84 3D                  174 	.dw	#00110$
      00840E 84 3D                  175 	.dw	#00110$
      008410 84 46                  176 	.dw	#00114$
      008412 84 46                  177 	.dw	#00114$
      008414 84 46                  178 	.dw	#00114$
      008416 84 46                  179 	.dw	#00114$
      008418 84 4F                  180 	.dw	#00116$
      00841A 84 68                  181 	.dw	#00123$
      00841C 84 68                  182 	.dw	#00123$
      00841E 84 4F                  183 	.dw	#00116$
      008420 84 58                  184 	.dw	#00120$
      008422 84 58                  185 	.dw	#00120$
      008424 84 58                  186 	.dw	#00120$
      008426 84 58                  187 	.dw	#00120$
      008428 84 61                  188 	.dw	#00121$
                           000088   189 	C$stm8s_itc.c$133$2_0$353 ==.
                                    190 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 133: case ITC_IRQ_PORTA:
      00842A                        191 00104$:
                           000088   192 	C$stm8s_itc.c$134$2_0$353 ==.
                                    193 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 134: Value = (uint8_t)(ITC->ISPR1 & Mask); /* Read software priority */
      00842A C6 7F 70         [ 1]  194 	ld	a, 0x7f70
      00842D 14 03            [ 1]  195 	and	a, (0x03, sp)
      00842F 6B 01            [ 1]  196 	ld	(0x01, sp), a
                           00008F   197 	C$stm8s_itc.c$135$2_0$353 ==.
                                    198 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 135: break;
      008431 CC 84 68         [ 2]  199 	jp	00123$
                           000092   200 	C$stm8s_itc.c$140$2_0$353 ==.
                                    201 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 140: case ITC_IRQ_PORTE:
      008434                        202 00108$:
                           000092   203 	C$stm8s_itc.c$141$2_0$353 ==.
                                    204 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 141: Value = (uint8_t)(ITC->ISPR2 & Mask); /* Read software priority */
      008434 C6 7F 71         [ 1]  205 	ld	a, 0x7f71
      008437 14 03            [ 1]  206 	and	a, (0x03, sp)
      008439 6B 01            [ 1]  207 	ld	(0x01, sp), a
                           000099   208 	C$stm8s_itc.c$142$2_0$353 ==.
                                    209 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 142: break;
      00843B 20 2B            [ 2]  210 	jra	00123$
                           00009B   211 	C$stm8s_itc.c$152$2_0$353 ==.
                                    212 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 152: case ITC_IRQ_TIM1_OVF:
      00843D                        213 00110$:
                           00009B   214 	C$stm8s_itc.c$153$2_0$353 ==.
                                    215 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 153: Value = (uint8_t)(ITC->ISPR3 & Mask); /* Read software priority */
      00843D C6 7F 72         [ 1]  216 	ld	a, 0x7f72
      008440 14 03            [ 1]  217 	and	a, (0x03, sp)
      008442 6B 01            [ 1]  218 	ld	(0x01, sp), a
                           0000A2   219 	C$stm8s_itc.c$154$2_0$353 ==.
                                    220 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 154: break;
      008444 20 22            [ 2]  221 	jra	00123$
                           0000A4   222 	C$stm8s_itc.c$164$2_0$353 ==.
                                    223 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 164: case ITC_IRQ_TIM3_OVF:
      008446                        224 00114$:
                           0000A4   225 	C$stm8s_itc.c$165$2_0$353 ==.
                                    226 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 165: Value = (uint8_t)(ITC->ISPR4 & Mask); /* Read software priority */
      008446 C6 7F 73         [ 1]  227 	ld	a, 0x7f73
      008449 14 03            [ 1]  228 	and	a, (0x03, sp)
      00844B 6B 01            [ 1]  229 	ld	(0x01, sp), a
                           0000AB   230 	C$stm8s_itc.c$166$2_0$353 ==.
                                    231 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 166: break;
      00844D 20 19            [ 2]  232 	jra	00123$
                           0000AD   233 	C$stm8s_itc.c$178$2_0$353 ==.
                                    234 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 178: case ITC_IRQ_I2C:
      00844F                        235 00116$:
                           0000AD   236 	C$stm8s_itc.c$179$2_0$353 ==.
                                    237 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 179: Value = (uint8_t)(ITC->ISPR5 & Mask); /* Read software priority */
      00844F C6 7F 74         [ 1]  238 	ld	a, 0x7f74
      008452 14 03            [ 1]  239 	and	a, (0x03, sp)
      008454 6B 01            [ 1]  240 	ld	(0x01, sp), a
                           0000B4   241 	C$stm8s_itc.c$180$2_0$353 ==.
                                    242 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 180: break;
      008456 20 10            [ 2]  243 	jra	00123$
                           0000B6   244 	C$stm8s_itc.c$199$2_0$353 ==.
                                    245 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 199: case ITC_IRQ_TIM4_OVF:
      008458                        246 00120$:
                           0000B6   247 	C$stm8s_itc.c$201$2_0$353 ==.
                                    248 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 201: Value = (uint8_t)(ITC->ISPR6 & Mask); /* Read software priority */
      008458 C6 7F 75         [ 1]  249 	ld	a, 0x7f75
      00845B 14 03            [ 1]  250 	and	a, (0x03, sp)
      00845D 6B 01            [ 1]  251 	ld	(0x01, sp), a
                           0000BD   252 	C$stm8s_itc.c$202$2_0$353 ==.
                                    253 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 202: break;
      00845F 20 07            [ 2]  254 	jra	00123$
                           0000BF   255 	C$stm8s_itc.c$204$2_0$353 ==.
                                    256 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 204: case ITC_IRQ_EEPROM_EEC:
      008461                        257 00121$:
                           0000BF   258 	C$stm8s_itc.c$205$2_0$353 ==.
                                    259 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 205: Value = (uint8_t)(ITC->ISPR7 & Mask); /* Read software priority */
      008461 C6 7F 76         [ 1]  260 	ld	a, 0x7f76
      008464 14 03            [ 1]  261 	and	a, (0x03, sp)
      008466 6B 01            [ 1]  262 	ld	(0x01, sp), a
                           0000C6   263 	C$stm8s_itc.c$210$1_0$352 ==.
                                    264 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 210: }
      008468                        265 00123$:
                           0000C6   266 	C$stm8s_itc.c$212$1_0$352 ==.
                                    267 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 212: Value >>= (uint8_t)(((uint8_t)IrqNum % 4u) * 2u);
      008468 7B 01            [ 1]  268 	ld	a, (0x01, sp)
      00846A 88               [ 1]  269 	push	a
      00846B 7B 03            [ 1]  270 	ld	a, (0x03, sp)
      00846D 27 05            [ 1]  271 	jreq	00136$
      00846F                        272 00135$:
      00846F 04 01            [ 1]  273 	srl	(1, sp)
      008471 4A               [ 1]  274 	dec	a
      008472 26 FB            [ 1]  275 	jrne	00135$
      008474                        276 00136$:
      008474 84               [ 1]  277 	pop	a
                           0000D3   278 	C$stm8s_itc.c$214$1_0$352 ==.
                                    279 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 214: return((ITC_PriorityLevel_TypeDef)Value);
                           0000D3   280 	C$stm8s_itc.c$215$1_0$352 ==.
                                    281 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 215: }
      008475 5B 03            [ 2]  282 	addw	sp, #3
                           0000D5   283 	C$stm8s_itc.c$215$1_0$352 ==.
                           0000D5   284 	XG$ITC_GetSoftwarePriority$0$0 ==.
      008477 81               [ 4]  285 	ret
                           0000D6   286 	G$ITC_SetSoftwarePriority$0$0 ==.
                           0000D6   287 	C$stm8s_itc.c$230$1_0$355 ==.
                                    288 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 230: void ITC_SetSoftwarePriority(ITC_Irq_TypeDef IrqNum, ITC_PriorityLevel_TypeDef PriorityValue)
                                    289 ;	-----------------------------------------
                                    290 ;	 function ITC_SetSoftwarePriority
                                    291 ;	-----------------------------------------
      008478                        292 _ITC_SetSoftwarePriority:
      008478 52 02            [ 2]  293 	sub	sp, #2
                           0000D8   294 	C$stm8s_itc.c$244$1_0$355 ==.
                                    295 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 244: Mask = (uint8_t)(~(uint8_t)(0x03U << (((uint8_t)IrqNum % 4U) * 2U)));
      00847A 7B 05            [ 1]  296 	ld	a, (0x05, sp)
      00847C 90 5F            [ 1]  297 	clrw	y
      00847E A4 03            [ 1]  298 	and	a, #0x03
      008480 97               [ 1]  299 	ld	xl, a
      008481 58               [ 2]  300 	sllw	x
      008482 A6 03            [ 1]  301 	ld	a, #0x03
      008484 88               [ 1]  302 	push	a
      008485 9F               [ 1]  303 	ld	a, xl
      008486 4D               [ 1]  304 	tnz	a
      008487 27 05            [ 1]  305 	jreq	00131$
      008489                        306 00130$:
      008489 08 01            [ 1]  307 	sll	(1, sp)
      00848B 4A               [ 1]  308 	dec	a
      00848C 26 FB            [ 1]  309 	jrne	00130$
      00848E                        310 00131$:
      00848E 84               [ 1]  311 	pop	a
      00848F 43               [ 1]  312 	cpl	a
      008490 6B 01            [ 1]  313 	ld	(0x01, sp), a
                           0000F0   314 	C$stm8s_itc.c$247$1_0$355 ==.
                                    315 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 247: NewPriority = (uint8_t)((uint8_t)(PriorityValue) << (((uint8_t)IrqNum % 4U) * 2U));
      008492 7B 06            [ 1]  316 	ld	a, (0x06, sp)
      008494 88               [ 1]  317 	push	a
      008495 9F               [ 1]  318 	ld	a, xl
      008496 4D               [ 1]  319 	tnz	a
      008497 27 05            [ 1]  320 	jreq	00133$
      008499                        321 00132$:
      008499 08 01            [ 1]  322 	sll	(1, sp)
      00849B 4A               [ 1]  323 	dec	a
      00849C 26 FB            [ 1]  324 	jrne	00132$
      00849E                        325 00133$:
      00849E 84               [ 1]  326 	pop	a
      00849F 6B 02            [ 1]  327 	ld	(0x02, sp), a
                           0000FF   328 	C$stm8s_itc.c$249$1_0$355 ==.
                                    329 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 249: switch (IrqNum)
      0084A1 7B 05            [ 1]  330 	ld	a, (0x05, sp)
      0084A3 A1 18            [ 1]  331 	cp	a, #0x18
      0084A5 23 03            [ 2]  332 	jrule	00134$
      0084A7 CC 85 64         [ 2]  333 	jp	00124$
      0084AA                        334 00134$:
      0084AA 5F               [ 1]  335 	clrw	x
      0084AB 7B 05            [ 1]  336 	ld	a, (0x05, sp)
      0084AD 97               [ 1]  337 	ld	xl, a
      0084AE 58               [ 2]  338 	sllw	x
      0084AF DE 84 B3         [ 2]  339 	ldw	x, (#00135$, x)
      0084B2 FC               [ 2]  340 	jp	(x)
      0084B3                        341 00135$:
      0084B3 84 E5                  342 	.dw	#00104$
      0084B5 84 E5                  343 	.dw	#00104$
      0084B7 84 E5                  344 	.dw	#00104$
      0084B9 84 E5                  345 	.dw	#00104$
      0084BB 84 F8                  346 	.dw	#00108$
      0084BD 84 F8                  347 	.dw	#00108$
      0084BF 84 F8                  348 	.dw	#00108$
      0084C1 84 F8                  349 	.dw	#00108$
      0084C3 85 64                  350 	.dw	#00124$
      0084C5 85 64                  351 	.dw	#00124$
      0084C7 85 0B                  352 	.dw	#00110$
      0084C9 85 0B                  353 	.dw	#00110$
      0084CB 85 1E                  354 	.dw	#00114$
      0084CD 85 1E                  355 	.dw	#00114$
      0084CF 85 1E                  356 	.dw	#00114$
      0084D1 85 1E                  357 	.dw	#00114$
      0084D3 85 30                  358 	.dw	#00116$
      0084D5 85 64                  359 	.dw	#00124$
      0084D7 85 64                  360 	.dw	#00124$
      0084D9 85 30                  361 	.dw	#00116$
      0084DB 85 42                  362 	.dw	#00120$
      0084DD 85 42                  363 	.dw	#00120$
      0084DF 85 42                  364 	.dw	#00120$
      0084E1 85 42                  365 	.dw	#00120$
      0084E3 85 54                  366 	.dw	#00121$
                           000143   367 	C$stm8s_itc.c$254$2_0$356 ==.
                                    368 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 254: case ITC_IRQ_PORTA:
      0084E5                        369 00104$:
                           000143   370 	C$stm8s_itc.c$255$2_0$356 ==.
                                    371 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 255: ITC->ISPR1 &= Mask;
      0084E5 C6 7F 70         [ 1]  372 	ld	a, 0x7f70
      0084E8 14 01            [ 1]  373 	and	a, (0x01, sp)
      0084EA C7 7F 70         [ 1]  374 	ld	0x7f70, a
                           00014B   375 	C$stm8s_itc.c$256$2_0$356 ==.
                                    376 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 256: ITC->ISPR1 |= NewPriority;
      0084ED C6 7F 70         [ 1]  377 	ld	a, 0x7f70
      0084F0 1A 02            [ 1]  378 	or	a, (0x02, sp)
      0084F2 C7 7F 70         [ 1]  379 	ld	0x7f70, a
                           000153   380 	C$stm8s_itc.c$257$2_0$356 ==.
                                    381 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 257: break;
      0084F5 CC 85 64         [ 2]  382 	jp	00124$
                           000156   383 	C$stm8s_itc.c$262$2_0$356 ==.
                                    384 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 262: case ITC_IRQ_PORTE:
      0084F8                        385 00108$:
                           000156   386 	C$stm8s_itc.c$263$2_0$356 ==.
                                    387 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 263: ITC->ISPR2 &= Mask;
      0084F8 C6 7F 71         [ 1]  388 	ld	a, 0x7f71
      0084FB 14 01            [ 1]  389 	and	a, (0x01, sp)
      0084FD C7 7F 71         [ 1]  390 	ld	0x7f71, a
                           00015E   391 	C$stm8s_itc.c$264$2_0$356 ==.
                                    392 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 264: ITC->ISPR2 |= NewPriority;
      008500 C6 7F 71         [ 1]  393 	ld	a, 0x7f71
      008503 1A 02            [ 1]  394 	or	a, (0x02, sp)
      008505 C7 7F 71         [ 1]  395 	ld	0x7f71, a
                           000166   396 	C$stm8s_itc.c$265$2_0$356 ==.
                                    397 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 265: break;
      008508 CC 85 64         [ 2]  398 	jp	00124$
                           000169   399 	C$stm8s_itc.c$275$2_0$356 ==.
                                    400 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 275: case ITC_IRQ_TIM1_OVF:
      00850B                        401 00110$:
                           000169   402 	C$stm8s_itc.c$276$2_0$356 ==.
                                    403 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 276: ITC->ISPR3 &= Mask;
      00850B C6 7F 72         [ 1]  404 	ld	a, 0x7f72
      00850E 14 01            [ 1]  405 	and	a, (0x01, sp)
      008510 C7 7F 72         [ 1]  406 	ld	0x7f72, a
                           000171   407 	C$stm8s_itc.c$277$2_0$356 ==.
                                    408 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 277: ITC->ISPR3 |= NewPriority;
      008513 C6 7F 72         [ 1]  409 	ld	a, 0x7f72
      008516 1A 02            [ 1]  410 	or	a, (0x02, sp)
      008518 C7 7F 72         [ 1]  411 	ld	0x7f72, a
                           000179   412 	C$stm8s_itc.c$278$2_0$356 ==.
                                    413 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 278: break;
      00851B CC 85 64         [ 2]  414 	jp	00124$
                           00017C   415 	C$stm8s_itc.c$288$2_0$356 ==.
                                    416 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 288: case ITC_IRQ_TIM3_OVF:
      00851E                        417 00114$:
                           00017C   418 	C$stm8s_itc.c$289$2_0$356 ==.
                                    419 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 289: ITC->ISPR4 &= Mask;
      00851E C6 7F 73         [ 1]  420 	ld	a, 0x7f73
      008521 14 01            [ 1]  421 	and	a, (0x01, sp)
      008523 C7 7F 73         [ 1]  422 	ld	0x7f73, a
                           000184   423 	C$stm8s_itc.c$290$2_0$356 ==.
                                    424 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 290: ITC->ISPR4 |= NewPriority;
      008526 C6 7F 73         [ 1]  425 	ld	a, 0x7f73
      008529 1A 02            [ 1]  426 	or	a, (0x02, sp)
      00852B C7 7F 73         [ 1]  427 	ld	0x7f73, a
                           00018C   428 	C$stm8s_itc.c$291$2_0$356 ==.
                                    429 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 291: break;
      00852E 20 34            [ 2]  430 	jra	00124$
                           00018E   431 	C$stm8s_itc.c$303$2_0$356 ==.
                                    432 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 303: case ITC_IRQ_I2C:
      008530                        433 00116$:
                           00018E   434 	C$stm8s_itc.c$304$2_0$356 ==.
                                    435 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 304: ITC->ISPR5 &= Mask;
      008530 C6 7F 74         [ 1]  436 	ld	a, 0x7f74
      008533 14 01            [ 1]  437 	and	a, (0x01, sp)
      008535 C7 7F 74         [ 1]  438 	ld	0x7f74, a
                           000196   439 	C$stm8s_itc.c$305$2_0$356 ==.
                                    440 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 305: ITC->ISPR5 |= NewPriority;
      008538 C6 7F 74         [ 1]  441 	ld	a, 0x7f74
      00853B 1A 02            [ 1]  442 	or	a, (0x02, sp)
      00853D C7 7F 74         [ 1]  443 	ld	0x7f74, a
                           00019E   444 	C$stm8s_itc.c$306$2_0$356 ==.
                                    445 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 306: break;
      008540 20 22            [ 2]  446 	jra	00124$
                           0001A0   447 	C$stm8s_itc.c$328$2_0$356 ==.
                                    448 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 328: case ITC_IRQ_TIM4_OVF:
      008542                        449 00120$:
                           0001A0   450 	C$stm8s_itc.c$330$2_0$356 ==.
                                    451 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 330: ITC->ISPR6 &= Mask;
      008542 C6 7F 75         [ 1]  452 	ld	a, 0x7f75
      008545 14 01            [ 1]  453 	and	a, (0x01, sp)
      008547 C7 7F 75         [ 1]  454 	ld	0x7f75, a
                           0001A8   455 	C$stm8s_itc.c$331$2_0$356 ==.
                                    456 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 331: ITC->ISPR6 |= NewPriority;
      00854A C6 7F 75         [ 1]  457 	ld	a, 0x7f75
      00854D 1A 02            [ 1]  458 	or	a, (0x02, sp)
      00854F C7 7F 75         [ 1]  459 	ld	0x7f75, a
                           0001B0   460 	C$stm8s_itc.c$332$2_0$356 ==.
                                    461 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 332: break;
      008552 20 10            [ 2]  462 	jra	00124$
                           0001B2   463 	C$stm8s_itc.c$334$2_0$356 ==.
                                    464 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 334: case ITC_IRQ_EEPROM_EEC:
      008554                        465 00121$:
                           0001B2   466 	C$stm8s_itc.c$335$2_0$356 ==.
                                    467 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 335: ITC->ISPR7 &= Mask;
      008554 C6 7F 76         [ 1]  468 	ld	a, 0x7f76
      008557 14 01            [ 1]  469 	and	a, (0x01, sp)
      008559 C7 7F 76         [ 1]  470 	ld	0x7f76, a
                           0001BA   471 	C$stm8s_itc.c$336$2_0$356 ==.
                                    472 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 336: ITC->ISPR7 |= NewPriority;
      00855C C6 7F 76         [ 1]  473 	ld	a, 0x7f76
      00855F 1A 02            [ 1]  474 	or	a, (0x02, sp)
      008561 C7 7F 76         [ 1]  475 	ld	0x7f76, a
                           0001C2   476 	C$stm8s_itc.c$341$1_0$355 ==.
                                    477 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 341: }
      008564                        478 00124$:
                           0001C2   479 	C$stm8s_itc.c$342$1_0$355 ==.
                                    480 ;	../common/STM8S_StdPeriph_Lib/src/stm8s_itc.c: 342: }
      008564 5B 02            [ 2]  481 	addw	sp, #2
                           0001C4   482 	C$stm8s_itc.c$342$1_0$355 ==.
                           0001C4   483 	XG$ITC_SetSoftwarePriority$0$0 ==.
      008566 81               [ 4]  484 	ret
                                    485 	.area CODE
                                    486 	.area CONST
                                    487 	.area INITIALIZER
                                    488 	.area CABS (ABS)
